from .notification import NotificationHandler, JobStatusHandler
from mroi.config import json_config, ENV, APP, RECEIVERS, AIDE_ID, COUNTRY, BRAND, SUB_BRAND, SEGMENT, SUB_SEGMENT

default_notification_handler = NotificationHandler(APP, ENV, RECEIVERS, AIDE_ID, COUNTRY, BRAND, SUB_BRAND, SEGMENT, SUB_SEGMENT)
default_jobstatus_handler = JobStatusHandler(json_config["metadata"].get("env", ""), AIDE_ID)