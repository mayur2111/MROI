import json
from typing import Union

import google.auth
from google.cloud import pubsub_v1

from mroi.config import NOTIFICATION_TOPIC, JOBSTATUS_TOPIC

class NotificationHandler(object):
    def __init__(self, 
        app_name: str, 
        env: str, 
        receivers: Union[str, list, tuple], 
        aide_id: str, 
        country: str, 
        brand: str, 
        sub_brand: Union[str, list, tuple], 
        segment: Union[str, list, tuple],
        sub_segment: Union[str, list, tuple]
    ):
        self.app_name = app_name
        self.env = env
        self.receivers = [receivers] if type(receivers) == str else list(receivers)
        self.aide_id = aide_id
        self.country = country
        self.brand = brand
        self.sub_brand = ', '.join([sub_brand] if type(sub_brand) == str else list(sub_brand))
        self.segment = ', '.join([segment] if type(segment) == str else list(segment))
        self.sub_segment = ', '.join([sub_segment] if type(sub_segment) == str else list(sub_segment))
        self._publisher = pubsub_v1.PublisherClient()
        _, project_id = google.auth.default()
        self._notification_topic_path = self._publisher.topic_path(project_id, NOTIFICATION_TOPIC)

    def _get_default_meta(self) -> dict:
        meta = {"AIDE ID": self.aide_id}
        if self.country:
            meta["COUNTRY"] = self.country
        if self.brand:
            meta["BRAND"] = self.brand
        if self.sub_brand:
            meta["SUB_BRAND"] = self.sub_brand
        if self.segment:
            meta["SEGMENT"] = self.segment
        if self.sub_segment:
            meta["SUB_SEGMENT"] = self.sub_segment
        return meta

    def _build_notification_json(self, meta: dict=None, success: bool=True):
        return {
            "success": success,
            "email": self.receivers,
            "appType": self.app_name,
            "env": self.env,
            "meta": meta
        }
    
    # def send_success_email(self, meta=None):
    #     if not meta:
    #         meta = self._get_default_meta()
    #     else:
    #         meta = {
    #             **self._get_default_meta(),
    #             **meta
    #         }
    #     notification_json = json.dumps(
    #         self._build_notification_json(meta, success=True)
    #     ).encode('utf-8')
    #     future = self._publisher.publish(self._notification_topic_path, notification_json)
    #     future.result()

    def send_failure_email(self, error_message:str):
        meta = {
            **self._get_default_meta(),
            **{"ERROR_MESSAGE": error_message}
        }
        notification_json = json.dumps(
            self._build_notification_json(meta, success=False)
        ).encode('utf-8')
        future = self._publisher.publish(self._notification_topic_path, notification_json)
        future.result()

class JobStatusHandler(object):
    def __init__(self, 
        env: str, 
        aide_id: str
    ):
        self.env = env.lower()
        self.aide_id = aide_id
        self._publisher = pubsub_v1.PublisherClient()
        _, project_id = google.auth.default()
        self._jobstatus_topic_path = self._publisher.topic_path(project_id, JOBSTATUS_TOPIC)

    def _build_jobstatus_json(self, message: str, code: str=""):
        return {
            "env": self.env,
            "aide_id": self.aide_id,
            "message": message,
            "code": code
        }
    
    def update_jobstatus(self, message: str, code: str="failure"):
        jobstatus_json = json.dumps(
            self._build_jobstatus_json(message, code)
        ).encode('utf-8')
        future = self._publisher.publish(self._jobstatus_topic_path, jobstatus_json)
        future.result()        
