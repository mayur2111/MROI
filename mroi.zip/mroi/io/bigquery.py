from mroi.data_models.outputs import (
    AutoMLResultsTable, AutoMLBudgetResultsTable,
    RBTResultsTable, SUResultsTable,
    DnDResultsTable, MMTResultsTable
)

class ModelResultsFactory(object):
    RESULTS_TABLE = {
        "AUTOML" : AutoMLResultsTable,
        "AUTOML_BUDGET" : AutoMLBudgetResultsTable,
        "REGRESSION_BUDGET" : RBTResultsTable,
        "SALES_UPLIFT" : SUResultsTable,
        "DIFF&DIFF" : DnDResultsTable,
        "MMT" : MMTResultsTable
    }

    @classmethod
    def get_results_table(cls, model):
        if model in cls.RESULTS_TABLE:
            return cls.RESULTS_TABLE[model]()
        else:
            raise ValueError(f"Unsupported model: {model}. Expected one of {cls.RESULTS_TABLE.keys()}")
