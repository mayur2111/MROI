"""Define your exceptions here. An sample is shown below. 
Leave a docstring to describe your exception. 
The name of your exception class should end with Error 
and the doc string should start with the string Raise when"""

class DataNotFoundError(Exception):
    """Raise when BigQuery returns 0 rows for applied filters"""

class TooManyTargetsError(Exception):
    """Raise when BigQuery returns 0 rows for applied filters"""

class AdstockFeatureMismatchError(Exception):
    "Raise when there is a mismatch between the adstock features in regression file vs adstock features in media file"

class InvalidMediaKPIsError(Exception):
    """Raise when there is not even one media kpi with variance in the values"""

class DriverGroupNotFoundError(Exception):
    """Raise when previous or current nested drivers are not present in variable mapping"""

class MissingPrePilotDataError(Exception):
    """Raise when pre pilot data is not available for AutoML Budget"""

class InadequateMediaError(Exception):
    """Raise when media features do not appear to be important in the model"""
    
class InSufficientDataPointsError(Exception):
    """Raise when available data points are not enough to run the model"""