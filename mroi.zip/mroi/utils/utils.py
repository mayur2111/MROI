from datetime import datetime, timedelta
from functools import wraps
import os
import io
import time
from urllib.parse import urlparse

import pandas as pd

from google.cloud import secretmanager
from google.cloud import storage

# from h2oai_client import Client
from driverlessai import Client

from mroi.logging import getLogger



def gcs_join(*args):
    paths = [arg.strip('/') for arg in args]
    return '/'.join(paths)

def retry(exceptions, tries=4, delay=5, backoff=2, logger=None):
    def deco_retry(f):
        @wraps(f)
        def f_retry(*args, **kwargs):
            mtries, mdelay = tries, delay
            while mtries > 1:
                try:
                    return f(*args, **kwargs)
                except exceptions as e:
                    msg = f"{e}, Retrying in {mdelay} seconds ..."
                    if logger:
                        logger.warn(msg)
                    else:
                        print(msg)
                    time.sleep(mdelay)
                    mtries -= 1
                    mdelay *= backoff
            return f(*args, **kwargs)
        return f_retry
    return deco_retry

def access_secret_version(project_id, secret_id, version_id="latest"):
    """
    Access the payload for the given secret version if one exists. The version
    can be a version number as a string (e.g. "5") or an alias (e.g. "latest").
    """
    # Create the Secret Manager client.
    client = secretmanager.SecretManagerServiceClient()
    # Build the resource name of the secret version.
    name = f"projects/{project_id}/secrets/{secret_id}/versions/{version_id}"
    # Access the secret version.
    response = client.access_secret_version(request={"name": name})
    payload = response.payload.data.decode("UTF-8")
    return payload

class GCSUrl(object):
    def __init__(self, url: str):
        """GCS url

        Args:
            url (str): Fully qualified gsc url
        """
        self._parsed = urlparse(url, allow_fragments=False)

    @property
    def bucket(self) -> str:
        """Get bucket name

        Returns:
            str: Bucket name
        """
        return self._parsed.netloc

    @property
    def path(self) -> str:
        """Blob file path

        Returns:
            str: File path
        """
        if self._parsed.query:
            return self._parsed.path.lstrip('/') + '?' + self._parsed.query
        else:
            return self._parsed.path.lstrip('/')

    @property
    def url(self) -> str:
        """Fully qualified GCS url

        Returns:
            str: GCS url
        """
        return self._parsed.geturl()

    def __repr__(self):
        return f'GCSUrl({self.url})'

    def __str__(self):
        return self.url
    
class PuddleDAIVM:
    def __init__(self, project_id, puddle_server_address, puddle_vm_name, puddle_api_key_secret, puddle_api_secret_key_secret):
        import urllib3
        from puddle.client import SystemsClient
        from puddle.client.cloud import CLOUD_GCP
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        self.logger = getLogger(self.__class__.__name__)
        self.project_id = project_id
        self.puddle_server_address = puddle_server_address
        self.puddle_vm_name = puddle_vm_name
        self.puddle_api_key_secret = puddle_api_key_secret
        self.puddle_api_secret_key_secret = puddle_api_secret_key_secret
        self.set_puddle_env()
        self.systems_client = SystemsClient(cloud=CLOUD_GCP, verify=False)
        
    def set_puddle_env(self):
        """Sets puddle server address, api_key_id and api_secret_key as environment variables."""
        # Set environment variables.
        _puddle_api_key_id = access_secret_version(self.project_id, self.puddle_api_key_secret)
        _puddle_api_secret_key = access_secret_version(self.project_id, self.puddle_api_secret_key_secret)
        os.environ["PUDDLE_server_address"] = self.puddle_server_address
        os.environ["PUDDLE_api_key_id"] = _puddle_api_key_id.strip()
        os.environ["PUDDLE_api_secret_key"] = _puddle_api_secret_key.strip()

    @retry(Exception)
    def start_dai_vm(self):
        """
        Start DAI VM corresponding to pm-mroi if not started already.
        """
        system = self.systems_client.find_by_name(self.puddle_vm_name)
        #system = self.systems_client.find_by_name(self.puddle_vm_name)
        # Check system status and start if needed.
        if system.status_text == 'stopped' or system.status_text == 'stopping...':
            # Wait for VM to stop
            #systems_client.start(system.id)
            #systems_client.wait_for_system_started(system.id)
            #system = systems_client.get(system.id)
            self.systems_client.wait_for_system_stopped(system.id)
            self.logger.info('Starting DAI VM.')
            # Start VM
            self.systems_client.start(system.id)
            # Wait for VM to start
            self.systems_client.wait_for_system_started(system.id)
            system = self.systems_client.get(system.id)
            self.logger.info('DAI VM started.')
            self.logger.info(f'Status of DAI VM: {system.status}')
        elif system.status_text == 'starting...':
            self.logger.info('DAI VM  is starting.')
            # Wait for VM to start
            self.systems_client.wait_for_system_started(system.id)
            system = self.systems_client.get(system.id)
            self.logger.info('DAI VM started.')
            self.logger.info(f'Status of DAI VM: {system.status}')
        if system.status == -1000:
            self.logger.info('DAI VM failed, restarting VM.')
            self.stop_dai_vm()
            self.systems_client.start(system.id)
            self.systems_client.wait_for_system_started(system.id)
            system = self.systems_client.get(system.id)
            self.logger.info('DAI VM started.')
            self.logger.info(f'Status of DAI VM: {system.status}')
        return system
  
    @retry(Exception)
    def stop_dai_vm(self):
        """
        Turn off DAI VM corresponding to vm name.
        """
        system = self.systems_client.find_by_name(self.puddle_vm_name)
        exp_length = len(system.models)
        exp_running = False
        for i in range(exp_length):
            # print(system.models[i],system.models[i].progress)
            if system.models[i].progress < 1:
                exp_running = True
                self.logger.info('Other experiment(s) still running in the DAI VM. Allowing other scripts that initiated experiment to stop VM instead.')
                break
        if not exp_running:
            # Stop DAI VM
            if system.status_text == 'stopped' or system.status_text == 'stopping...':
                self.logger.info('DAI VM already stopping or stopped.')
            else:
                self.systems_client.stop(system.id)
                self.logger.info('Stopping DAI VM.')
                # Wait for VM to stop
                self.systems_client.wait_for_system_stopped(system.id)
                self.logger.info('DAI VM stopped.')
                        
    def clean_dai(self, days_before=3):
        """
        Remove data from VM if experiment is older than days_before.

        Keyword arguments:
        days_before -- most recent # days to retain data for
        """
        # Get DAI credentials
        system = self.systems_client.find_by_name(self.puddle_vm_name)

        dai = Client(address=system.default_url, username=system.username, password=system.password)
        #h2oai = Client(address=system.default_url, username=system.username, password=system.password)

        # Create dataset with DAI experiments details
        experiments_names = []
        experiments_keys = []
        experiments_datetime = []
        experiments_dataset = []
        experiments_validset = []
        experiments_testset = []
        self.logger.info("Obtaining list of all models.")
        for e in dai.experiments.list():
            experiments_names.append(e.name)
            experiments_keys.append(e.key)
            experiments_dataset.append(e.datasets['train_dataset'].key)
            try:
                experiments_validset.append(e.datasets['validation_dataset'].key)
            except:
                experiments_validset.append('')
            try:
                experiments_testset.append(e.datasets['test_dataset'].key)
            except:
                experiments_testset.append('')
            try:
                experiments_datetime.append(pd.to_datetime(e._get_raw_info().created,unit='s'))
            except IndexError:
                experiments_datetime.append('')

        experiments = pd.DataFrame({'description': experiments_names,
                                    'datetime': experiments_datetime,
                                    'key': experiments_keys,
                                    'test_dataset': experiments_dataset,
                                    'validset': experiments_validset,
                                    'testset': experiments_testset})
        experiments['datetime'] = pd.to_datetime(experiments['datetime'])
        #self.logger.info("Obtained experiment details.")
        # Create dataset with DAI datasets details
        datasets_names = []
        datasets_keys = []
        datasets_datetime = []
        for d in dai.datasets.list():
            datasets_names.append(d.name)
            datasets_keys.append(d.key)
            datasets_datetime.append(datetime.utcfromtimestamp(int(d._get_raw_info().dump()['file_path'].split('.')[-3])).strftime('%Y-%m-%d %H:%M'))
        self.logger.info("Obtained dataset details.")
        datasets = pd.DataFrame({'description': datasets_names,
                                 'datetime': datasets_datetime,
                                 'key': datasets_keys})
        datasets['datetime'] = pd.to_datetime(datasets['datetime'])

        # Set date that datasets and experiment will be delete before that
        date_to_delete = datetime.now() - timedelta(days=days_before)
        self.logger.info(f"Deleting experiments and relevant datasets prior to {date_to_delete}.")
        self.delete_experiments(dai, experiments, date_to_delete)
        self.delete_datasets(dai, datasets, experiments, date_to_delete)
    
    def delete_experiments(self, dai, experiments, date_to_delete):
        """
        Delete experiments older than given date.

        Keyword arguments:
        h2oai -- H2O ai client object
        experiments -- df containing experiment info
        date_to_delete -- date before which experiments/datasets are to be deleted
        """
        # Select experiments to be deleted
        experiments.sort_values(['datetime'],ascending=True, inplace=True)
        experiments_to_delete = experiments[(experiments['datetime'] < date_to_delete) | (experiments['datetime'].isna())]
        #display(experiments,date_to_delete,experiments_to_delete)
        experiments_to_delete_keys = experiments_to_delete['key']
        self.logger.info(f"Deleting experiments.")
        for e_k in experiments_to_delete_keys:
            #dai.experiments.get(e_k).delete()
            #display(e_k)
            try:
                dai.experiments.get(e_k).delete()
            except:
                pass
        self.logger.info(f"Successfully deleted {len(experiments_to_delete_keys)} experiments.")
    
    def delete_datasets(self, dai, datasets, experiments, date_to_delete):
        """
        Delete datasets older than given date. If dataset is needed for any newer experiment, retain it.

        Keyword arguments:
        h2oai -- H2O ai client object
        datasets -- df containing dataset info
        experiments -- df containing experiment info
        date_to_delete -- date before which experiments/datasets are to be deleted
        """
        experiments_to_keep = experiments[(experiments['datetime'] >= date_to_delete)]
        # Find datasets which are used by experiments that will not be deleted
        datasets_to_keep_keys = list(experiments_to_keep['test_dataset'].values)+list(experiments_to_keep['validset'].values)+list(experiments_to_keep['testset'].values)
        # Select datasets to be deleted
        datasets_to_delete = datasets[(datasets['datetime'] < date_to_delete)]
        datasets_to_delete_keys = datasets_to_delete['key']
        self.logger.info("Identified datasets to delete.")
        self.logger.info("Deleting datasets....")
        n_deleted_datasets = 0
        for d_k in datasets_to_delete_keys:
            if not(d_k in datasets_to_keep_keys):
                n_deleted_datasets += 1
                dai.datasets.get(d_k).delete()
        self.logger.info(f"Successfully deleted {n_deleted_datasets} datasets.")

def upload_to_gcs(url: str, data: bytes, content_type='text/plain'):
        """
        Upload bytes data to gcs

        Args:
            url (str): file path to upload the data
            data (bytes): data frame or data object to upload to gcs
            content_type (str, optional): Type of file to upload. Defaults to 'text/plain'.
        """
        url = GCSUrl(url)
        storage_client = storage.Client()
        bucket = storage_client.bucket(url.bucket)
        blob = bucket.blob(url.path)
        if type(data) == io.BytesIO:
            blob.upload_from_file(data, content_type=content_type)
        else:
            blob.upload_from_string(data, content_type=content_type)

def download_from_gcs(url: str) -> bytes:
        """
        Download file as bytes data from gcs.

        Args:
            url (str): qualified gcs file path

        Returns:
            bytes: file downloaded as bytes in-memory
        """
        url = GCSUrl(url)
        storage_client = storage.Client()
        bucket = storage_client.bucket(url.bucket)
        blob = bucket.blob(url.path)
        content = blob.download_as_bytes()
        return content
