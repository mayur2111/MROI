import io

import pandas as pd
from pandas.api.types import is_numeric_dtype, is_integer_dtype

from google.cloud import bigquery
import google.auth

from mroi.config import PROJECT_ID

_bigquery_client = bigquery.Client()

class DataFrameWriterMixin(object):
    BIGQUERY_PYTHON_MAPPING = {
        'FLOAT': float,
        'INTEGER': int,
        'BOOLEAN': bool,
        'STRING': str,
        'DATE': 'datetime64[ns]',
        'DATETIME': 'datetime64[ns]'
    }

    @staticmethod
    def _get_default_value(col_type: str) -> object:
        """Get default value based on data type of the column

        Args:
            col_type (str): string representation of the data type

        Returns:
            object: default value
        """
        return False if col_type == "BOOLEAN" else None

    def _get_column_names(self) -> list:
        """Get column names of the bigquery table

        Returns:
            list: List of column name strings
        """
        return [field.name for field in self.SCHEMA]

    def _get_empty_dataframe(self):
        """Create an empty dataframe with schema matching the bigquery table

        Returns:
            pd.DataFrame: 0 row dataframe with schema matching the bigquery table
        """
        df = pd.read_csv(io.StringIO(""), names=self._get_column_names())
        for field in self.SCHEMA:
            df[field.name] = df[field.name].astype(self.BIGQUERY_PYTHON_MAPPING[field.field_type])
        return df
    
    def _impute_columns(self, df: pd.DataFrame):
        """Impute missing columns with default values

        Args:
            df (pd.DataFrame): DataFrame to impute with missing columns

        Returns:
            pd.DataFrame: Imputed dataframe
        """
        missing_columns = list(set(self._get_column_names()) - set(df.columns))
        missing_columns_schema = [field for field in self.SCHEMA if field.name in missing_columns]
        for field in missing_columns_schema:
            df[field.name] = self._get_default_value(field.field_type)
        for field in self.SCHEMA:
            if is_numeric_dtype(self.BIGQUERY_PYTHON_MAPPING[field.field_type]):
                if is_integer_dtype(self.BIGQUERY_PYTHON_MAPPING[field.field_type]):
                    df[field.name] = df[field.name].apply(lambda x: int(float(x)))
                df[field.name] = df[field.name].astype(self.BIGQUERY_PYTHON_MAPPING[field.field_type])
        return df[self._get_column_names()]
    
    def delete(self, predicate: str):
        query = f"""DELETE FROM `{self.DATABASE}.{self.TABLE}` WHERE {predicate}"""
        job = _bigquery_client.query(query, job_id_prefix=f"DELETE_{self.__class__.__name__}", project=PROJECT_ID)
        job.result()

    def write(self, df: pd.DataFrame = None):
        """Replace existing frame file with df

        Args:
            df (pd.DataFrame): Dataframe to persist
        """
        df = self._impute_columns(df)
        df.to_gbq(f"{self.DATABASE}.{self.TABLE}", project_id=PROJECT_ID, if_exists="append", credentials=google.auth.default()[0])

class ResultsTable:
    DATABASE = "AIDE_Results"
    TABLE = None
    SCHEMA = []

class AutoMLResultsTable(ResultsTable, DataFrameWriterMixin):
    TABLE = "AutoML"
    try:
        SCHEMA = _bigquery_client.get_table(f"{ResultsTable.DATABASE}.{TABLE}").schema
    except:
        SCHEMA = None

class AutoMLBudgetResultsTable(ResultsTable, DataFrameWriterMixin):
    TABLE = "AutoML_Budget"
    try:
        SCHEMA = _bigquery_client.get_table(f"{ResultsTable.DATABASE}.{TABLE}").schema
    except:
        SCHEMA = None

class RBTResultsTable(ResultsTable, DataFrameWriterMixin):
    TABLE = "Regression_Budget"
    try:
        SCHEMA = _bigquery_client.get_table(f"{ResultsTable.DATABASE}.{TABLE}").schema
    except:
        SCHEMA = None

class SUResultsTable(ResultsTable, DataFrameWriterMixin):
    TABLE = "Sales_Uplift"
    try:
        SCHEMA = _bigquery_client.get_table(f"{ResultsTable.DATABASE}.{TABLE}").schema
    except:
        SCHEMA = None

class DnDResultsTable(ResultsTable, DataFrameWriterMixin):
    TABLE = "Diff_and_Diff"
    try:
        SCHEMA = _bigquery_client.get_table(f"{ResultsTable.DATABASE}.{TABLE}").schema
    except:
        SCHEMA = None

class MMTResultsTable(ResultsTable, DataFrameWriterMixin):
    TABLE = "MMT"
    try:
        SCHEMA = _bigquery_client.get_table(f"{ResultsTable.DATABASE}.{TABLE}").schema
    except:
        SCHEMA = None