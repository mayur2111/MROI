import re
import logging
from ntpath import basename
from typing import List, Tuple, Iterable

import random
import pandas as pd
import numpy as np
import datetime as dt

from itertools import accumulate, combinations
from dateutil.relativedelta import relativedelta
from scipy.stats import spearmanr
from prophet import Prophet
import neuralprophet
from neuralprophet import set_random_seed 
from neuralprophet.df_utils import init_data_params, normalize

import mroi.logging as mroi_logging
from mroi.exceptions import TooManyTargetsError, AdstockFeatureMismatchError, DriverGroupNotFoundError, MissingPrePilotDataError

class RegressionTemplate(object):
    
    def __init__(self, template_df: pd.DataFrame, adstock_df: pd.DataFrame, sales_df: pd.DataFrame, target: str = "DIST_SELLOUT_VOL"):
        self.logger = mroi_logging.getLogger(self.__class__.__name__)
        self.template_df = template_df.copy()
        self.adstock_df = adstock_df.copy()
        self.sales_df = sales_df.copy()
        self.target = target 
        
        self.template_df = self.template_df[(self.template_df['Mandatory'] != 'ignore')]
        if len(self.template_df.loc[self.template_df['Mandatory'] == 'target', 'Driver'].tolist()) != 1:
            raise TooManyTargetsError('There should be exactly 1 target in the template file')
        
        self.template_df["Feature_index"] = self.template_df["Driver"]
        
        self.template_df.loc[self.template_df['Mandatory'] == "target", 'Control_Y_N'] = 'base'
        if self.template_df.loc[self.template_df['Feature_index'] == "avgPrice", 'Control_Y_N'].values[0] == 'N':
            self.template_df.loc[self.template_df['Feature_index'] == "avgPrice", 'Control_Y_N'] = 'base'
        
        self._product_columns = ['Market', 'Region', 'Subregion', 'Brand', 'SubBrand', 'Segment', 'SubSegment', 'Product', 'Channel', 'Bucket_1', 'Bucket_2']
        self._template_columns = ['Market', 'Region', 'Subregion', 'Brand', 'SubBrand', 'Segment', 'SubSegment', 'Product',
                                  'PBI Group', 'Channel', 'Bucket_1', 'Bucket_2', 'Driver', 'Driver.Classification',
                                  'Metric', 'Media', 'Hierarchical_Y_N', 'Control_Y_N', 'Adstock_Y_N', 'Monotonic', 'Mandatory']
        self._date_columns = [col for col in self.template_df.columns if re.search(r"\d{4}-\d{2}-\d{2}", col)]

        self.template_df = self.template_df[self._template_columns + self._date_columns + ["Feature_index"]]

    @property
    def product_columns(self):
        return self._product_columns
    
    def pre_pilot_data_check(self, pilot_start_date: str, pilot_end_date: str):
        """
        Validates data availability pre pilot.
    
        Args:
            pilot_start_date (str): Pilot Start date
            pilot_end_date (str): Pilot End date
        """
        if pilot_start_date != '':
        #if pilot_start_date != '' and pilot_end_date != '':
            date_cols = [dt.datetime.strptime(date, '%Y-%m-%d') for date in list(np.setdiff1d(list(self.template_df.columns),self._template_columns+['Feature_index']))]
            pre_pilot_date_cols = [date for date in date_cols if date < dt.datetime.strptime(pilot_start_date, '%Y-%m-%d')]
            if pre_pilot_date_cols != []:
                self.logger.info("Pre pilot data available with pilot start date set as: {}".format(pilot_start_date))
                pre_pilot_cols = self._template_columns + [dt.datetime.strftime(date, '%Y-%m-%d') for date in pre_pilot_date_cols] + ['Feature_index']
                self.logger.info("Filtering data to keep only pre-pilot data")
                self.template_df = self.template_df[pre_pilot_cols]
            else:
                raise MissingPrePilotDataError("No pre-pilot data available to run the model on.")
        else:
            self.logger.info("Pilot start and end dates unavailable, assuming the data to be pre pilot")

    def add_seasonality_driver(self):
        def get_seasonality_df():
            #seasonality_df = self.template_df[self.template_df['Driver'] == self.target][[col for col in self.template_df.columns if col not in self._template_columns + ['Feature_index']]].T.reset_index()
            if self.sales_df.empty:
                self.logger.info("Using the data from the regression file as historical sales data was not found")
                seasonality_df = self.training_data[['DATE', self.target]]
            else:
                seasonality_df = self.sales_df[['Week_id', 'target']]
            seasonality_df.columns = ['ds', 'y']
            seasonality_df['ds'] = pd.to_datetime(seasonality_df['ds'], format='%Y-%m-%d')
            seasonality_df.sort_values('ds', inplace=True)
            seasonality_df = seasonality_df.reset_index().drop(columns=['index'])
            return seasonality_df
        
        seasonality_df = get_seasonality_df()
        if relativedelta(seasonality_df['ds'][len(seasonality_df)-1], seasonality_df['ds'][0]).years >= 2 or abs(seasonality_df['ds'][len(seasonality_df)-1]-seasonality_df['ds'][0]).days/7 >= 81:
            seasonality_component_nonsmooth = self._get_seasonality(seasonality_df, seasonality_df['ds'].nunique(), False)
        
        seasonality_df = get_seasonality_df()
        yearly_df = pd.DataFrame()
        date = seasonality_df['ds'][0]
        count = 0
        if relativedelta(seasonality_df['ds'][len(seasonality_df)-1], seasonality_df['ds'][0]).years >= 2:
            self.logger.info('There are more than 2 years of data so checking for seasonality in data.')
            add_seasonality = True
            for i in range(0, relativedelta(seasonality_df['ds'][len(seasonality_df)-1], seasonality_df['ds'][0]).years):
                yearly_df[f'year_{i}'] = seasonality_component_nonsmooth[(seasonality_component_nonsmooth['date'] >= date + relativedelta(years=0)) & (seasonality_component_nonsmooth['date'] <= date + relativedelta(years=1))].reset_index()['seasonality']
                count += len(yearly_df[f'year_{i}'])-1
                date = seasonality_component_nonsmooth['date'][count]
        elif abs(seasonality_df['ds'][len(seasonality_df)-1]-seasonality_df['ds'][0]).days/7 >= 81:
            self.logger.info('There are more than 1.5 years of data so checking for seasonality in data.')
            add_seasonality = True
            year_0 = seasonality_component_nonsmooth[seasonality_component_nonsmooth['date'] <= date + relativedelta(years=1)].reset_index()[['seasonality']]
            year_0.columns = ['year_0']
            year_1 = seasonality_component_nonsmooth[seasonality_component_nonsmooth['date'] >= date + relativedelta(years=1)].reset_index()[['seasonality']]
            year_1.columns = ['year_1']

            yearly_df = pd.merge(year_0, year_1, left_index=True, right_index=True)
        else:
            self.logger.warn('No seasonality added since we have less than 1.5 years of data.')
            add_seasonality = False
           
        if add_seasonality:
            correlations = {}
            for col_a, col_b in combinations(yearly_df.columns, 2):
                correlations[col_a + '__' + col_b] = spearmanr(yearly_df.loc[:, col_a], yearly_df.loc[:, col_b])


            sales_correlation = pd.DataFrame.from_dict(correlations, orient='index')
            sales_correlation.columns = ['correlation', 'p-value']

            lower_threshold = 0.7
            upper_threshold = 1

            len_high_correlation = len(sales_correlation[(sales_correlation['correlation'] >= lower_threshold) & (sales_correlation['correlation'] <= upper_threshold)])
            if len_high_correlation >= len(sales_correlation)/2:
                self.logger.info('include non-smooth seasonality')
                if len_high_correlation != len(sales_correlation):
                    self.logger.warn('Seasonality exists but some years have exceptions.')
                
                self.logger.info('Seasonality exists, hence seasonality added.')
                seasonality_df = get_seasonality_df()
                seasonality_component_smooth = self._get_seasonality(seasonality_df, seasonality_df['ds'].nunique(), True)

                seasonality_row_dict = {'Market': self.template_df['Market'][0], 'Region': self.template_df['Region'][0], 'Subregion': self.template_df['Subregion'][0],
                                        'Brand': self.template_df['Brand'][0], 'SubBrand': self.template_df['SubBrand'][0], 'Segment': self.template_df['Segment'][0],
                                        'SubSegment': self.template_df['SubSegment'][0], 'Product': self.template_df['Product'][0], 'PBI Group': self.template_df['PBI Group'][0],
                                        'Channel': 'OFFLINE', 'Bucket_1': '', 'Bucket_2': self.template_df['Bucket_2'][0], 'Driver': 'seasonality', 'Driver.Classification': 'seasonality', 'Metric': '', 
                                        'Media': '', 'Hierarchical_Y_N': '', 'Control_Y_N': 'base', 'Adstock_Y_N': '', 'Monotonic': 'up', 'Mandatory': 'Y'}
                seasonality_row_dict.update(dict(seasonality_component_smooth.values))
                seasonality_row_dict.update({'Feature_index': 'seasonality'})
                seasonality_row_dict_filtered = {your_key: seasonality_row_dict[your_key] for your_key in self.template_df.columns }
                self.template_df = self.template_df.append(pd.DataFrame(seasonality_row_dict_filtered, index=[0,]), ignore_index=True)
            else:
                include_seasonality = False
                self.logger.info('Seasonality does not exist, hence seasonality not added.')

    @staticmethod
    def _get_seasonality(df: pd.DataFrame, no_of_weeks: int, smooth: bool):
        if no_of_weeks <= 100:
            #m = Prophet(interval_width=0.95, yearly_seasonality=True, weekly_seasonality=True)
            if smooth:
                m = Prophet(interval_width=0.95, yearly_seasonality=no_of_weeks/20, weekly_seasonality=True)
            else:
                m = Prophet(interval_width=0.95, yearly_seasonality=True, weekly_seasonality=True)
            #m.add_regressor('holidays_count',standardize=False)
            #Fitting on data
            m.fit(df)
            data_to_forecast=df[['ds']]
            forecast=m.predict(data_to_forecast)
            #forecast['seasonality_holidays']=forecast['yearly']+forecast['holidays_count']
            seasonality_component=forecast[['ds','yearly']]
            seasonality_component.rename(columns={'ds':'date', 'yearly': 'seasonality'}, inplace=True)
            if smooth:
                seasonality_component['date']=pd.to_datetime(seasonality_component['date']).dt.strftime('%Y-%m-%d')
        else:
            set_random_seed(1234)
            get_data_params = lambda df, model: init_data_params(
                df=df, 
                normalize=model.normalize, covariates_config=model.config_covar, regressor_config=model.regressors_config, events_config=model.events_config
            )
            if smooth:
                m = neuralprophet.NeuralProphet(
                        #n_forecasts=10,
                        yearly_seasonality=no_of_weeks/20
                    )
            else:
                m = neuralprophet.NeuralProphet(
                        #n_forecasts=10,
                        yearly_seasonality=True
                    )
            neuralprophet.forecaster.log.setLevel(logging.WARNING)
            m.fit(df, freq="W", use_tqdm=False)
            data_params = get_data_params(df, m)
            df_for_forecast = normalize(df, data_params)
            forecast = m.predict(df=df_for_forecast)
            seasonality_component = forecast[['ds', 'season_yearly']]
            seasonality_component.rename(columns={'ds': 'date', 'season_yearly': 'seasonality'}, inplace=True)
            if smooth:
                seasonality_component['date']=pd.to_datetime(seasonality_component['date']).dt.strftime('%Y-%m-%d')
        return seasonality_component

    @property
    def training_data(self):
        # filtered_template = self.template_df[(self.template_df['Control_Y_N'].isin(["Y", "base"])) | (~self.template_df['Adstock_Y_N'].isnull()) | (self.template_df['Mandatory'].isin(["Y", 'target']))]
        filtered_template = self.template_df.copy()
        data = filtered_template[self._date_columns].T
        # Use feature index to get list of columns
        data.columns = filtered_template['Feature_index']
        data = data.astype('float')
        data.reset_index(inplace=True)
        data.rename(columns={'index': 'DATE'}, inplace=True)
        # No of folds can be defined. It is 4
        data['fold'] = data.groupby(data.index // 4).cumcount() + 1
        return data

    @property
    def target_feature_name(self):
        return self.template_df.loc[self.template_df['Mandatory'] == 'target', 'Feature_index'].tolist()[0]

    @staticmethod
    def _calculate_adstock(feature: np.ndarray, decay: float, factor: int, epsilon=1) -> np.ndarray:
        """
        Generate adstock based on given feature, decay and saturation.
    
        Args:
            feature (np.ndarray):  model adstock feature 
            decay (float): decay for the given feature
            factor (int): factor
            epsilon (float, optional): [description]. Defaults to 0.0001.
    
        Returns:
            np.ndarray: accumulated media KPI
        """
        accum1 = np.array(list(accumulate(feature, lambda bal, pmt: bal * decay + pmt)))
        accum2 = accum1/factor
        accum2[accum2 < epsilon] = 0
        return accum2

    @staticmethod
    def _maximize_corr(target: np.ndarray, feature: np.ndarray, factor: int, lower_saturation: float, upper_saturation: float, decay_step=0.01, saturation_step=0.05) -> Tuple[np.ndarray, float, float, float]:
        """
        Generate the best adstock by calculating correlation with target and selecting the adstock with max correlation
        Returns best adstock, best decay, best saturation and correlation of best adstock with target
    
        Args:
            target (np.ndarray): model target field
            feature (np.ndarray): model adstock feature
            factor (int): factor
            lower_saturation (float): minimum saturation
            upper_saturation (float): maximum saturation
            decay_step (float, optional): increase in decay per step . Defaults to 0.01
            saturation_step (float, optional): increase in saturation per step. Defaults to 0.05
    
        Returns:
            Tuple[np.ndarray, float, float, float]: Best adstocked array and corresponding decay, saturation, correlation
        """
        best_corr = -1
        best_decay = (2 ** (-1/lower_saturation))
        best_saturation = lower_saturation
        best_adstock = RegressionTemplate._calculate_adstock(feature, best_decay, factor)
        for saturation in np.arange(lower_saturation + 0.000001, upper_saturation + 0.000001, saturation_step):
            lower_decay = (2 ** (-1/saturation))
            upper_decay = (2 ** (-1/(upper_saturation+0.000001)))
            for decay in np.arange(lower_decay, upper_decay + 0.000001, decay_step):
                
                adstock = RegressionTemplate._calculate_adstock(feature, decay, factor)
                corr = abs(np.corrcoef(adstock, target)[0, 1])
                if corr > best_corr:
                    best_corr = corr
                    best_decay = decay
                    best_saturation = saturation
                    best_adstock = adstock
        return best_adstock, best_decay, best_saturation, best_corr

    def get_optimal_adstock(self):
        optimal_adstock = pd.DataFrame()
        template_adstock_features = pd.DataFrame()

        adstock_from_template = self.template_df.loc[self.template_df["Adstock_Y_N"] == "Y", :]
        if adstock_from_template.empty:
            return template_adstock_features, optimal_adstock
        
        if set(adstock_from_template["Driver"].tolist()) != set(self.adstock_df["KPI"].tolist()):
            raise AdstockFeatureMismatchError("Adstock features in template and adstock are different")
        
        raw_data = self.training_data
        # For each feature, get the best Adstock
        for _, row in adstock_from_template.iterrows():
            feature_index = row["Feature_index"]
            driver = row["Driver"]
            adstock_row = self.adstock_df[self.adstock_df['KPI'] == driver]
            if adstock_row['SaturationFlag'].values[0] == "T":
                #sl = adstock_row['Limit'].values[0] / row[self._date_columns].max()
                #su = sl
                sl = adstock_row['SL_Limit'].values[0]
                su = adstock_row['SU_Limit'].values[0]
            else:
                sl = adstock_row['SL_Limit'].values[0]
                su = adstock_row['SU_Limit'].values[0]
            
            res = self._maximize_corr(raw_data[self.target_feature_name].values, raw_data[feature_index].values, 
                adstock_row['Factor'].values[0], sl, su)
            
            self.logger.info(f"Generated best Adstock for feature: {feature_index} with maximum correlation with target: {self.target_feature_name}")
            feature_adstock = feature_index + "_adstock"
            
            # create new features with adstock
            new_adstock_feature = row.copy()
            new_adstock_feature[self._date_columns] = res[0]
            new_adstock_feature['Feature_index'] = feature_adstock
            template_adstock_features = template_adstock_features.append(new_adstock_feature, ignore_index=True)
            
            optimal_adstock = optimal_adstock.append(pd.DataFrame({"Feature_index": feature_adstock, "Adstock": feature_index, "Decay": res[1],
                                                         "Saturation": res[2], "Factor": adstock_row['Factor'].values[0],
                                                         "Limit": adstock_row['Limit'].values[0],
                                                         "SaturationFlag": adstock_row['SaturationFlag'].values[0]},
                                                        index=[0]), ignore_index=True)
        return template_adstock_features, optimal_adstock

    def update_template_with_adstock(self, adstock_features_df: pd.DataFrame):
        # Replace features to adstock with the adstock df
        features_to_replace = adstock_features_df["Driver"].tolist()
        self.template_df = self.template_df.loc[~self.template_df["Driver"].isin(features_to_replace), :].append(adstock_features_df)

    def add_group_id(self):
        group_id = "Driver.Group.Number"
        self.template_df.loc[:, group_id] = self.template_df["Driver.Classification"].astype("category").cat.codes
        self._template_columns.insert(self._template_columns.index("Driver.Classification")+1, group_id)
        self.template_df = self.template_df[self._template_columns + self._date_columns + ["Feature_index"]]
    
    @staticmethod
    def _explain_outlier(feature: pd.Series, peaks: list, valleys: list):
        if len(peaks)!=0:
            sorted(peaks)

            i = 0
            while i<len(peaks):
                subset = [peaks[i]]
                for j in range(i+1,len(peaks)):
                    if peaks[j] - subset[-1]==1:
                        subset.append(peaks[j])
                    else:
                        break
                if subset[0]!=0 and subset[-1]!=(len(feature)-1):
                    start = feature.loc[subset[0]-1]
                    end = feature.loc[subset[-1]+1]
                    for k in subset:
                        if feature.loc[k]<start or feature.loc[k]<end:
                            return False
                elif subset[0]==0:
                    end = feature.loc[subset[-1]+1]
                    for k in subset:
                        if feature.loc[k]<end:
                            return False
                elif subset[-1]==(len(feature)-1):
                    start = feature.loc[subset[0]-1]
                    for k in subset:
                        if feature.loc[k]<start:
                            return False
                if len(subset)==1:
                    i = i+1
                else:
                    i = subset[-1]

        if len(valleys)!=0:
            sorted(valleys)

            i = 0
            while i<len(valleys):
                subset = [valleys[i]]
                for j in range(i+1,len(valleys)):
                    if valleys[j] - subset[-1]==1:
                        subset.append(valleys[j])
                    else:
                        break
                if subset[0]!=0 and subset[-1]!=(len(feature)-1):
                    start = feature.loc[subset[0]-1]
                    end = feature.loc[subset[-1]+1]
                    for k in subset:
                        if feature.loc[k]>start or feature.loc[k]>end:
                            return False
                elif subset[0]==0:
                    end = feature.loc[subset[-1]+1]
                    for k in subset:
                        if feature.loc[k]>end:
                            return False
                elif subset[-1]==(len(feature)-1):
                    start = feature.loc[subset[0]-1]
                    for k in subset:
                        if feature.loc[k]>start:
                            return False
                if len(subset)==1:
                    i = i+1
                else:
                    i = subset[-1]
        return True
    
    def add_outlier_drivers(self):
        target = self.target_feature_name
        self.template_df = self.template_df.reset_index(drop=True)

        def get_outlier_df(input_df = self.template_df):
            mask = input_df.loc[(input_df['Control_Y_N'].isnull())&(input_df['Media'].isnull())&(input_df['Adstock_Y_N'].isnull())&(input_df['Monotonic'].isnull())&(~input_df['Mandatory'].isin(['Y','target']))].index.values
            outlier_df = input_df.drop(mask, axis=0)
            outlier_df = outlier_df[[col for col in self._date_columns+['Feature_index']]].T
            outlier_df.rename(columns=outlier_df.loc['Feature_index'],inplace=True)
            outlier_df.drop('Feature_index',axis=0,inplace=True)
            date_val = outlier_df.index.to_list()
            outlier_df = outlier_df.apply(pd.to_numeric)
            outlier_df.reset_index(inplace=True,drop=True)
            return outlier_df, date_val

        outlier_df, date_val = get_outlier_df()

        # function to get index of the outlier
        def get_outlier_index(df: pd.DataFrame, target: str):
            target_series = df[target].to_list()
            q1 = np.percentile(target_series, 25)
            q3 = np.percentile(target_series, 75)

            peaks = list(df[df[target]>=(q3+1.5*(q3-q1))].index.values)
            valleys = list(df[df[target]<=(q1-1.5*(q3-q1))].index.values)
            if peaks or valleys:
                flag = True
            else:
                flag = False
            return peaks, valleys, flag

        #function to get all features with correlation greater than 0.85
        def get_correlated_features(df: pd.DataFrame, target:str):
            res = []
            for col in [col for col in df.drop([target],axis=1).columns if 'revenue' not in str.lower(col)]:
                corr = np.corrcoef(df[col].to_list(), df[target].to_list())
                if corr[0,1]>0.80:
                    res.append(col)
            return res

        #function to generate dummy variable
        def generate_dummy(peaks: list, valleys: list, target_list: np.ndarray):
            res = []
            for i in range(len(target_list)):
                if i in peaks+valleys:
                    res.append(target_list[i])
                else:
                    res.append(0)
            return res

        #function to generate sales lag variable
        def generate_sales_diff(peaks: list, valleys: list, target_list: np.ndarray):
            res = []
            for i in range(len(target_list)):
                if i in peaks+valleys and i!=0:
                    lag_val = (target_list[i]-target_list[i-1])/target_list[i-1]
                    res.append(lag_val)
                else:
                    res.append(0)
            if 0 in peaks+valleys:
                res[0] = sum(res)/len(res)
            return res

        #get outlier index
        peaks, valleys, flag = get_outlier_index(outlier_df, target)

        if flag==True:
            self.logger.info("Outliers found in target variable")
            #get list of correlated features
            corr_features = get_correlated_features(outlier_df, target)
            self.logger.info("Correlated drivers found are :-")
            self.logger.info(f'{corr_features}')
            check = False
            for feat in corr_features:
                if self._explain_outlier(outlier_df[feat],peaks,valleys):
                    check = True
                    break
            if check==False:
                self.logger.info("Outlier behaviour cannot be explained by any driver")
                self.logger.info("Adding Dummy and Sales Difference as base variable")
                #add dummy
                dummy_df = pd.DataFrame({'date':date_val,
                                         'Dummy':generate_dummy(peaks,valleys, outlier_df[target].values)})
                dummy_row_dict = {'Market': self.template_df['Market'][0], 'Region': self.template_df['Region'][0], 'Subregion': self.template_df['Subregion'][0],
                                  'Brand': self.template_df['Brand'][0], 'SubBrand': self.template_df['SubBrand'][0], 'Segment': self.template_df['Segment'][0],
                                  'SubSegment': self.template_df['SubSegment'][0], 'Product': self.template_df['Product'][0], 'PBI Group': self.template_df['PBI Group'][0],
                                  'Channel': 'OFFLINE', 'Bucket_1': '', 'Bucket_2': self.template_df['Bucket_2'][0], 'Driver': 'Dummy', 'Driver.Classification': 'Dummy', 'Metric': '', 
                                  'Media': '', 'Hierarchical_Y_N': '', 'Control_Y_N': 'base', 'Adstock_Y_N': '', 'Monotonic': '', 'Mandatory': 'Y'}
                dummy_row_dict.update(dict(dummy_df.values))
                dummy_row_dict.update({'Feature_index':'Dummy'})
                dummy_df = pd.DataFrame(dummy_row_dict, index=[0,])
                self.template_df = self.template_df.append(dummy_df, ignore_index=True)

                sales_diff_df = pd.DataFrame({'date':date_val,
                                              'Sales_Difference':generate_sales_diff(peaks,valleys, outlier_df[target].values)})
                sales_diff_dict = {'Market': self.template_df['Market'][0], 'Region': self.template_df['Region'][0], 'Subregion': self.template_df['Subregion'][0],
                                  'Brand': self.template_df['Brand'][0], 'SubBrand': self.template_df['SubBrand'][0], 'Segment': self.template_df['Segment'][0],
                                  'SubSegment': self.template_df['SubSegment'][0], 'Product': self.template_df['Product'][0], 'PBI Group': self.template_df['PBI Group'][0],
                                  'Channel': 'OFFLINE', 'Bucket_1': '', 'Bucket_2': self.template_df['Bucket_2'][0], 'Driver': 'Sales_Difference', 'Driver.Classification': 'Sales_Difference', 'Metric': '', 
                                  'Media': '', 'Hierarchical_Y_N': '', 'Control_Y_N': 'base', 'Adstock_Y_N': '', 'Monotonic': '', 'Mandatory': 'Y'}
                sales_diff_dict.update(dict(sales_diff_df.values))
                sales_diff_dict.update({'Feature_index':'Sales_Difference'})
                sales_diff_df = pd.DataFrame(sales_diff_dict, index=[0,])
                self.template_df = self.template_df.append(sales_diff_df, ignore_index=True)
            else:
                self.logger.info("Outlier behaviour already explained by a driver")
        else:
            self.logger.info("No outliers present in target variable")

class VariableMapping(object):
    def __init__(self, template_df: pd.DataFrame):
        self.logger = mroi_logging.getLogger(self.__class__.__name__)
        self.template_df = template_df

        self._mapfile = self.template_df[['Feature_index', 'Driver.Classification', 'Control_Y_N', 'Metric', 'Driver', 'Mandatory', 'Monotonic']]
        self._mapfile.loc[:, 'Group_id'] = self._mapfile['Driver.Classification'].astype('category').cat.codes

    def add_spends(self):
        self._mapfile.loc[:, "Spending"] = "take last available"
    
    def add_adstock(self, adstock_data: pd.DataFrame):
        if adstock_data.shape[0] > 0:
            self._mapfile = pd.merge(self._mapfile, adstock_data, how="left", on="Feature_index")
            self._mapfile.rename(columns={'Feature_index': 'Feature'}, inplace=True)
        
    @property
    def mapfile(self):
        try:
            self._mapfile = self._mapfile[(self._mapfile['Control_Y_N'].isin(["Y", "base"])) | (~self._mapfile['Adstock'].isnull()) | (self._mapfile['Mandatory'].isin(["Y", 'target']))]
            return self._mapfile
        except:
            return self._mapfile

class NestedVariables(object):
    def __init__(self, nested_drivers: list):
        self.nested_drivers = nested_drivers
        self.current_driver = str(self.nested_drivers[-1]).strip()
        self.prev_drivers = self.nested_drivers[:-1]
        self.prev_prefix = '-'.join([driver.strip() for driver in self.prev_drivers[::-1]]) # reverse the list before concatenating
        self.new_prefix = f'{self.current_driver}-{self.prev_prefix}' if self.prev_prefix else self.current_driver

    def get_new_path(self, file_path: str):
        return file_path.replace(basename(file_path), f'{self.current_driver}-{basename(file_path)}')

class DataPreparationNested(NestedVariables):
    def __init__(self, training_data: pd.DataFrame, variable_mapping: pd.DataFrame, contributions: pd.DataFrame, nested_drivers: list, target="DIST_SELLOUT_VOL"):
        super().__init__(nested_drivers)

        self._training_data = training_data
        self._variable_mapping = variable_mapping
        # Previous nested output or pilot output in case of first nested run
        # Should have a DATE index
        self.contributions = contributions 

        self.target = target

    @property
    def nested_training_data(self):
        # self._training_data['DATE'] = pd.to_datetime(self._training_data['DATE'], format="%Y-%m-%d")
        self._training_data.sort_values(['DATE'], inplace=True)
        self._training_data['fold'] = self._training_data.groupby(self._training_data.index // 4).cumcount() + 1
        
        features_to_drop = self._variable_mapping.loc[self._variable_mapping["Driver"].isin(self.nested_drivers), 'Feature'].tolist()
        # Drop features from the training data that belong to the all the previous and current nested groups
        nested_training_data = self._training_data.drop(columns=features_to_drop)
        # Set date index so that we can modify the target
        nested_training_data.set_index("DATE", inplace=True)
        # Set target to the total contributions
        nested_target_contribution = self.contributions[[col for col in self.contributions.columns if self.current_driver in col]].sum(axis=1)
        #nested_target_contribution = self.contributions[[f"{self.current_driver}_direct", f"{self.current_driver}_indirect"]].sum(axis=1)
        # Make sure both the index have the same data type so that assignment works as expected
        # nested_target_contribution.index = pd.to_datetime(nested_target_contribution.index, format="%Y-%m-%d")
        nested_training_data[self.target] = nested_target_contribution
        nested_training_data.reset_index(inplace=True)
        return nested_training_data

    @property
    def nested_variable_mapping(self):
        #if not any(self.current_driver in driver for driver in list(self._variable_mapping['Feature'])):
        if not set([self.current_driver]).issubset(self._variable_mapping["Driver"].values):
            raise DriverGroupNotFoundError(f"The current driver {self.current_driver} was not found in mapping")
        
        mapfile = self._variable_mapping[(~self._variable_mapping["Driver"].isin(self.nested_drivers)) & (self._variable_mapping["Driver"].isin(list(self.contributions.columns) + [self.target]))].copy()
        mapfile['Group_id'] = mapfile['Driver.Classification'].astype('category').cat.codes
        return mapfile

class SyntheticData(object):
    def __init__(self, training_data: pd.DataFrame, variable_mapping: pd.DataFrame):
        self.logger = mroi_logging.getLogger(self.__class__.__name__)
        self.training_data = training_data
        self.variable_mapping = variable_mapping
        
        # set date 
        self.raw_data = self._set_date_index(training_data)
        self.raw_data = self.raw_data[self.variable_mapping["Feature"].tolist()]

    @classmethod
    def _set_date_index(cls, df: pd.DataFrame):
        if df.index.name == "DATE":
            return df
        else:
            return df.set_index("DATE")

    @staticmethod
    def power_set(array: Iterable) -> List[List[int]]:
        """
        Return a power set of combinations of given list

        Args:
            combine_items (list): list of range of values upto number of groups

        Returns:
            list: power set of all combinations as a list
        """
        power_set = [list(j) for i in range(len(array)) for j in combinations(array, i + 1)]
        # important to insert the empty list at the end, as further implementation is tied to this position
        power_set.append([])
        return power_set

    @property
    def feature_group_map(self) -> dict:
        filtered_df = self.variable_mapping.query("Control_Y_N != 'base'")
        filtered_df = filtered_df[["Feature", "Driver.Classification"]].set_index("Feature").dropna()
        return filtered_df.to_dict()['Driver.Classification']

    @staticmethod
    def binarize_df(bin_df: pd.DataFrame) -> pd.DataFrame:
        """
        Converts a df of binary columns into a Series of integers.
        
        Args:
            bin_df (pd.DataFrame): binary dataframe to be converted to a series

        Returns:
            pd.DataFrame: converted to integers
        """
        bin_df['as_int'] = (bin_df * (2 ** np.arange(bin_df.shape[1] - 1, -1, -1))).sum(axis=1)
        return bin_df
    
    def generate_switch_pairs(self, binary_df: pd.DataFrame) -> pd.DataFrame:
        """
        Build a list of pairs of otherwise identical rows just with a feature on/off.

        Args:
            binary_df (pd.DataFrame): 1-hot combinations dataframe

        Returns:
            pd.DataFrame: on/off pairs generated for each combination
        """
        ON_OFF = ['on', 'off']
        self.logger.info('Generating on/off pairs.')
        combi_rows = int(binary_df.shape[0] / 2)
    
        # df structure: multiindex [col.number --> on/off
        pairs = pd.DataFrame(data=np.zeros([combi_rows, binary_df.shape[1] * 2], dtype=np.uint64),
                             columns=pd.MultiIndex.from_product([binary_df.columns, ON_OFF], names=['group', 'onoff']))
    
        for feat in binary_df.columns.tolist():  # np.arange(0, binary_df.shape[1]):
            # make temp df of 'other' features, binarize, and sort by binarized #s
            ordered_df = binary_df.sort_values(by=[feat], ascending=False)
            temp_bin = self.binarize_df(ordered_df.loc[:, ordered_df.columns != feat])
            temp_bin['on_off'] = binary_df[feat]
            # sort by binarization to ensure that the pairs of rows where only the
            # feature 'bit' is different are contiguous; sort by on_off to ensure that
            # the 'on' and 'off' bits are always in the same order
            temp_bin.sort_values(by=['as_int', 'on_off'], ascending=[False, False], inplace=True)
            for oo in range(len(ON_OFF)):
                pairs.loc[:, (feat, ON_OFF[oo])] = temp_bin.loc[temp_bin.on_off != oo, :].index.values
        return pairs

    def generate_combinations(self) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """
        Generate combinations from group schema.
        
        Returns:
            Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]: combinations dataframes
        """
        group_combins_1hot = self.generate_group_combinations()
        feature_comb_mask = self.generate_feature_mask(group_combins_1hot)

        self.logger.info('Generated combinations.')
        # Get the on/off location pairs in the cube for the different features
        paired_combins = self.generate_switch_pairs(group_combins_1hot)
        self.logger.info('Fetched ON/OFF location pairs.')
        return group_combins_1hot, feature_comb_mask, paired_combins

    def generate_group_combinations(self) -> pd.DataFrame:
        self.logger.info('Generating group combinations')
        unique_groups = list(set(self.feature_group_map.values()))
        num_groups = len(unique_groups)

        combins = self.power_set(range(num_groups))
        num_combins = len(combins)
        # Build a dataframe where each combination of n columns has one row of 1-hot
        # reserve row 0 for 'nothing switched on'
        group_combins_1hot = pd.DataFrame(np.zeros([num_combins, num_groups], dtype=np.int8), columns=unique_groups)
        for i in range(num_combins):
            group_combins_1hot.iloc[i, combins[i]] = 1
        return group_combins_1hot

    def generate_feature_mask(self, group_combinations: pd.DataFrame) -> pd.DataFrame:
        features = [feature for feature, group in self.feature_group_map.items() if group in group_combinations.columns]
        feature_comb_mask = pd.DataFrame(np.ones([len(group_combinations), len(features)], dtype=np.int8), columns=features)
        # Apply relevant column from combinations mask to each column
        for feature, group in self.feature_group_map.items():
            feature_comb_mask[feature] = group_combinations.loc[:, group]
        feature_comb_mask.index.rename('combin', inplace=True)
        return feature_comb_mask

    def generate_synthetic_data(self, include_base=True) -> pd.DataFrame:
        """
        Create synthetic data from combination maks through matrix multiplication. 
        Convert the DFs to np arrays and then do matrix multiplication to get the synthetic input data we need to get predictions.

        Returns:
            pd.DataFrame: combinations dataframe
        """
        feature_data = self.raw_data.loc[:, self.feature_group_map.keys()]

        self.logger.info('Generating synthetic data.')
        # Transpose the matrices so that they align on the _first_ dimension.
        data_mc_mtrx = feature_data.T.values

        feature_comb_mask = self.generate_feature_mask(self.generate_group_combinations())
        
        mask_mtrx = feature_comb_mask.T.values
        cube = np.matmul(data_mc_mtrx[:, :, np.newaxis], mask_mtrx[:, np.newaxis, :])
        cube = pd.DataFrame(cube.reshape(cube.shape[0], -1)).T.values

        cube_df = pd.DataFrame(data=cube, 
                               index=pd.MultiIndex.from_product([self.raw_data.index, feature_comb_mask.index], names=['DATE', 'combin']),
                               columns=feature_comb_mask.columns)

        if include_base:
            synth_data = cube_df.join(self.raw_data.loc[:, self.raw_data.columns.difference(cube_df.columns)])
        else:
            synth_data = cube_df
        self.logger.info('Generated synthetic data.')
        return synth_data
