import json
import time
from typing import Tuple, List
from zipfile import ZipFile
from ntpath import basename
import io
import os
import shutil
from pathlib import Path

import pandas as pd
import driverlessai

from google.cloud import storage

from mroi.config import PROJECT_ID, PUDDLE_SERVER_ADDRESS, PUDDLE_VM_NAME_AUTOMLBUDGET,PUDDLE_VM_NAME_AUTOML, PUDDLE_API_KEY_SECRET, PUDDLE_API_SECRET_KEY_SECRET
import mroi.logging as mroi_logging
from mroi.exceptions import InadequateMediaError
from mroi.utils import PuddleDAIVM, retry, gcs_join, upload_to_gcs, GCSUrl, download_from_gcs

class DecompositionModel(object):
    def __init__(self, project_name: str, training_data: pd.DataFrame, variable_mapping: pd.DataFrame, experiment_results_folder: str, template_path: str, target: str = "DIST_SELLOUT_VOL", model_id: str = "AUTOML"):
        self.logger = mroi_logging.getLogger(self.__class__.__name__)
        
        self.project_name = project_name
        self.experiment_results_folder = experiment_results_folder
        self._training_data_staging_path = gcs_join(experiment_results_folder, 'Data_DAI.csv')
        self.training_data = training_data
        self.variable_mapping = variable_mapping
        self.template_path = template_path
        self.target = target
        self.model_id = model_id
        
        if self.model_id == "AUTOML":
            PUDDLE_VM_NAME = PUDDLE_VM_NAME_AUTOML
        elif self.model_id == "AUTOML_BUDGET":
            PUDDLE_VM_NAME = PUDDLE_VM_NAME_AUTOMLBUDGET
        self.puddle_vm = PuddleDAIVM(PROJECT_ID, PUDDLE_SERVER_ADDRESS, PUDDLE_VM_NAME, PUDDLE_API_KEY_SECRET, PUDDLE_API_SECRET_KEY_SECRET)
        self._experiment_folder_template = gcs_join(self.experiment_results_folder, 'experiment_results_{}')

        self._h2o_train_dataset = self.create_h2o_dataset(self.training_data)

        self._train_experiment_key = None
        self._predict_experiment_key = None
        
        self.storage_client = storage.Client()
           
    def model_config(self, mandatory: bool=False) -> Tuple[str, list]:
        """
        Defines and returns config for experiment based on mandatory requirements when features
        are added from get_missing_features_dai().
        
        Args:
            mandatory (bool): boolean value based on requirement

        Returns:
            Tuple[str, list]: Model config as string and list of columns to drop
        """
        # Get features monotonic to generate config
        features_mono = {feature: -1 for feature, direction in zip(self.variable_mapping.Feature, self.variable_mapping.Monotonic) if direction == 'down'}
        features_mono.update({feature: 1 for feature, direction in zip(self.variable_mapping.Feature, self.variable_mapping.Monotonic) if direction == 'up'})
        config = """included_models = ['LIGHTGBM', 'XGBOOSTGBM'] \n
                    feature_brain_level = 0 \n 
                    seed = 1729 \n
                    enable_lightgbm = "on" \n
                    lightgbm_reg_objectives = ['mse'] \n
                    enable_xgboost_gbm = "on" \n
                    monotonicity_constraints_dict = \""""+str(features_mono)+"""\" \n
                    included_transformers = "['OriginalTransformer']" \n
                    target_transformer = "identity_noclip" \n
                    make_mojo_scoring_pipeline = "off" \n
                    make_python_scoring_pipeline = "off" \n
                    autodoc_pd_max_runtime=-1 \n 
                    enable_genetic_algorithm = "auto" \n
                    enable_wide_rules = "off" \n
                    min_num_rows=25 """
                    
        if mandatory:
            config += """\n 
                    features_cost_per_interp = 0.0 \n
                    lowest_nonzero_varimp = -1.0 \n
                    no_drop_features = true """
        
        return config
        
    def run_training_experiment(self, config_overrides: str, scorer: str='MAPE', columns_to_drop: List[str]=[]) -> str:
        """Build model and run experiment. Returns the experiment key
        
        Args:
            config_overrides (str): TOML config
            scorer (str, optional): Scorer used to for model evaluation. Defaults to 'MAPE'.
            columns_to_drop (List[str], optional): List of features to drop from the data. Defaults to [].

        Returns:
            str: The experiment key
        """
        # Start experiment
        self.logger.info("Running experiment")
        experiment_mono = self.h2o_client.experiments.create_async(
                train_dataset=self._h2o_train_dataset,
                target_column=self.target,
                task='regression',
                accuracy=9,
                time=2,
                interpretability=1,
                fold_column='fold',
                scorer=scorer,
                reproducible=True,
                drop_columns=columns_to_drop,
                config_overrides=config_overrides,
                name=self.project_name,
                force=True
        ).result(silent=True)
        exp_key = experiment_mono.key
        self.logger.info(f'Successfully executed experiment with ID: {exp_key}')
        self.download_experiment(exp_key, self.get_experiment_staging_folder(exp_key))
        return exp_key
        
    def get_features_used(self, experiment_key: str) -> list:
        """
        Download experiment summary files and upload to GCS. Return dataframe containing features used in experiment.

        Args:
            experiment_key (str): experiment ID

        Returns:
            list: list of features
        """
        try:
            features = pd.read_table(gcs_join(self.get_experiment_staging_folder(experiment_key), 'ensemble_features.txt'), sep=',', skipinitialspace=True)
        except:
            self.download_experiment(experiment_key, self.get_experiment_staging_folder(experiment_key))
            self.get_features_used(experiment_key)
        return features['Feature'].replace(regex="^.*?[?=_]", value='').tolist()
    
    def _stage_input(self):
        self.training_data.to_csv(self._training_data_staging_path, index=False)
        self.logger.info(f'Uploaded file successfully to {self._training_data_staging_path}')

    def get_experiment_staging_folder(self, experiment_key: str) -> str:
        return self._experiment_folder_template.format(experiment_key)

    @retry(Exception)
    def download_experiment(self, experiment_key: str, location: str):
        with self.h2o_client._get_file(self.h2o_client.experiments.get(experiment_key)._get_raw_info().entity.summary_path) as response:
            summary_zip = ZipFile(io.BytesIO(response.content))
            self.logger.info(f'Uploading experiment output to {location}/')
            for file_name in summary_zip.namelist():
                upload_to_gcs(gcs_join(location, file_name), summary_zip.read(file_name))

    def download_model(self, experiment_key: str, location: str, model_type: str = 'mojo'):
        # Create a clean directory for staging the download
        if model_type == 'mojo':
            folder = f"mojo_{experiment_key}"
        else:
            folder = f"python_{experiment_key}"
        folder_path = Path(folder)
        if folder_path.exists():
            shutil.rmtree(folder_path)
        else:
            folder_path.mkdir()
        
        # Download mojo zip to local folder
        experiment = self.get_model(experiment_key)
        if model_type == 'mojo':
            pipeline_type = 'mojo_pipeline'
        else:
            pipeline_type = 'python_pipeline'
        self.logger.info("Building the model artifact")
        experiment.artifacts.create(pipeline_type)
        experiment.artifacts.download(only=pipeline_type, dst_dir=folder_path, overwrite=True)

        try:
            zip_file = [file for file in os.listdir(folder_path) if file.endswith(".zip")][0]
        except IndexError:
            self.logger.warn("Could not find the model object. Something went wrong while downloading the file from h2o")
            return

        self.logger.info("Writing the model object to the output location")
        # Upload the file to the blob location
        location_url = GCSUrl(location)
        bucket = self.storage_client.bucket(location_url.bucket)
        blob = bucket.blob(location_url.path)
        blob.upload_from_filename(folder_path.joinpath(zip_file).as_posix())

        # Delete the local folder
        shutil.rmtree(folder_path)
    
    @retry(Exception, tries=7)
    def download_pdp_data(self, pdp_file_path: str, location: str):
        with self.h2o_client._get_file(pdp_file_path) as response:
            upload_to_gcs(gcs_join(location, basename(pdp_file_path)), response.text)
            
    def download_pdp_files(self, experiment_key: str, regression_data: pd.DataFrame()):
        """Downloads PDP files for the experiment and stores the paths to target campaigns(channels) in dictionary for use in budget module
        
        Args:
            experiment_key (str): experiment ID
            regression_data (pd.DataFrame()): Regression template file after transformations

        Returns:
            dict: PDP target campaign(channels) paths on GCS
        """
        pdp_target_paths = {}   

        target_campaign_channels = list(regression_data.loc[(regression_data['Bucket_1'] == 'Target') & (regression_data['Adstock_Y_N'] == 'Y')]['Driver'].str.replace("SEf.", ""))
        
        self.logger.info("Target Campaign Channel")
        self.logger.info(f"{target_campaign_channels}")
        features = self.get_features_used(experiment_key)
        for feature in features:
            if feature.replace('_adstock', '') in target_campaign_channels:
                feature_cleaned = feature.replace(" ", "_")
                
                if self.h2o_client.server.version == '1.8.7.1':
                    pdp_file_path = f"h2oai_experiment_{experiment_key}/pdp_dai_{feature_cleaned}.json"
                else:
                    pdp_file_path = f"h2oai/h2oai_experiment_{experiment_key}/pdp_dai_{feature_cleaned}.json"
                results_location = self.get_experiment_staging_folder(experiment_key)
                try:
                    self.download_pdp_data(pdp_file_path, results_location)
                except:
                    raise InadequateMediaError("WARNING: Media features do not appear to be important in the model, hence run Regression Budget instead.")
                self.logger.info(f'Successfully downloaded file: {basename(pdp_file_path)} to response.')
                
                pdp_target_paths[feature.replace('_adstock', '')] = gcs_join(results_location, basename(pdp_file_path))
        return pdp_target_paths
        
    @property
    def h2o_client(self) -> driverlessai.Client:
        system = self.puddle_vm.start_dai_vm()
        h2oai_client = driverlessai.Client(address=system.default_url, username=system.username, password=system.password, verify=False)
        return h2oai_client

    @retry(Exception)
    def create_h2o_dataset(self, data):
        """Create a dataset on the driverless ai server using the gcs method. 
        Implicitly stages the raw data into gcs first before creating a dataset on h2o

        Returns:
            driverlessai.Client.Dataset: H2O Dataset object reference
        """
        # self._stage_input()
        dataset = self.h2o_client.datasets.create(data=data, name='Data_DAI_'+time.strftime("%Y%m%d-%H%M%S"))
        return dataset

    def train(self, scorer: str="RMSE") -> str:
        """Train model runnnig multiple experiments if required and return the latest experiment key

        Args:
            scorer (str, optional): scoring metric to use in experiment. Defaults to "RMSE".

        Returns:
            str: H2O Experiment ID
        """
        if self._train_experiment_key:
            return self._train_experiment_key

        self.logger.info(f'Starting project {self.project_name}')
        toml_config = self.model_config(mandatory=False)
        experiment_key = self.run_training_experiment(toml_config, scorer)
        
        all_features = self.training_data.columns.tolist()
        # Get list of features used in experiment
        features_used = self.get_features_used(experiment_key)
        features_to_use = set(features_used.copy())
        # Get list of mandatory features
        mandatory_features = self.variable_mapping.loc[self.variable_mapping['Mandatory'] == 'Y', 'Feature'].tolist()
        
        weak_driver_features = list(set(mandatory_features) - set(features_used))
        weak_driver_features = [sub.replace('_adstock', '') for sub in weak_driver_features]
        template_df = pd.read_csv(self.template_path)
        weak_features = list(template_df[template_df['Driver'].isin(weak_driver_features)]['Driver.Classification'])
        
        # add missing mandatory features
        features_to_use = features_to_use.union(set(mandatory_features) - set(features_used))
        features_to_use.add('fold')
        
        retrain = len(features_used) != len(features_to_use)
        features_to_drop = [feature for feature in all_features if feature not in features_to_use]
        
        if retrain:
            self.logger.info(f'Running experiment again with updated config and columns to drop')
            toml_config = self.model_config(mandatory=True)
            self.project_name = self.project_name + '_mand'
            experiment_key = self.run_training_experiment(toml_config, scorer, columns_to_drop=features_to_drop)
        
        self.logger.info(f'Finished execution of experiment with ID: {experiment_key}')
        self._train_experiment_key = experiment_key
        return experiment_key, weak_features, features_to_drop

    def metrics(self, experiment_key=None):
        """
        Fetches metrics like R2, MAPE, RMSE etc. using experiment ID from model summary.json

        Args:
            experiment_key (str): experiment ID

        Returns:
            dict: dictionary of metrics
        """
        list_of_metrics = ["GINI", "MAE", "MAPE", "MER", "MSE", "R2", "R2COD", "RMSE", "RMSLE", "RMSPE", "SMAPE"]
        if not experiment_key:
            experiment_key = self._train_experiment_key
        summary = json.loads(download_from_gcs(gcs_join(self.get_experiment_staging_folder(experiment_key), "summary.json")))

        metrics = {metric: summary[metric] for metric in list_of_metrics if metric in summary}
        return metrics

    @property
    def model(self):
        if self._train_experiment_key:
            return self.h2o_client.experiments.get(self._train_experiment_key)

    def get_model(self, experiment_key):
        return self.h2o_client.experiments.get(experiment_key)

    def predict(self, data, experiment_key=None):
        self._h2o_predict_dataset = self.create_h2o_dataset(data)
        self.logger.info("Obtaining predictions")
        prediction = self.get_model(experiment_key).predict(self._h2o_predict_dataset, include_shap_values_for_transformed_features=True) if experiment_key else self.model.predict(self._h2o_predict_dataset, include_shap_values_for_transformed_features=True)
        with self.h2o_client._get_file(prediction.file_paths[0]) as response:
            predictions = pd.read_csv(io.BytesIO(response.content))
        if self.h2o_client.server.version == '1.8.7.1':
            predictions.columns = ['prediction']
        else:
            predictions.columns.values[0] = 'prediction'
            predictions = predictions[['prediction']]

        with self.h2o_client._get_file(prediction.file_paths[1]) as response:
            shapley = pd.read_csv(io.BytesIO(response.content))
        return predictions, shapley
