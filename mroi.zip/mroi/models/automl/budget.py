"""Gets Budget for each target campaign/channel"""
# Import libraries
import google.auth
import re

import pandas as pd

from ntpath import basename

# Import dependencies
from mroi.config import PROJECT_ID, json_config
from mroi.utils import gcs_join
from mroi.logging import getLogger

from mroi.exceptions import InadequateMediaError

# Budget class
class Budget:
    """
    Class used to get Budget for each target campaign/channel

    Args:
        pdp_dai_target_paths: dictionary showing paths of pdp files of target channels/campaigns
        
    """
    def __init__(self, pdp_dai_target_paths, contribution_df, template_df, adstock_df):
        self.logger = getLogger(self.__class__.__name__)
        
        self.pdp_dai_target_paths = pdp_dai_target_paths
        self.template_df = template_df.copy()
        self.adstock_df = adstock_df.copy()
        self.contribution_df = contribution_df
        
        self._template_columns = ['Market', 'Region', 'Subregion', 'Brand', 'SubBrand', 'Segment', 'SubSegment', 'Product',
                                  "PBI Group", 'Channel', 'Bucket_1', 'Bucket_2', 'Driver', 'Driver.Classification',
                                  'Metric', 'Media', 'Hierarchical_Y_N', 'Control_Y_N', 'Adstock_Y_N', 'Monotonic',
                                  'Mandatory', 'Feature_index']
    
    def get_target_media_budget(self, target_media: str, max_sales_contribution: float):
        """Calculates budget for each individual target media driver.
        
        Args:
            target_media (str): target media driver
            max_sales_contribution (float): max sales contribution for the target media driver
            
        Returns:
            pd.DataFrame: budget dataframe for the target media driver
        """
        def calculate_sales_budget(target_pdp_df: pd.DataFrame, threshold: float=1):
            sales_budget_df = target_pdp_df[target_pdp_df['uplift'] >= threshold].reset_index().loc[0, :]
            reach = sales_budget_df[f'{target_media}_reach']
            sales_contribution = sales_budget_df[f'{target_media}_sales_contribution']
            budget = sales_budget_df[f'{target_media}_cost']
            return reach, sales_contribution, budget
            
        self.logger.info(f'Generating upper and lower budget for {target_media}.')
        pdp = pd.read_json(self.pdp_dai_target_paths[target_media])
        target_pdp_df = pdp[pdp['oor'] == False]
        target_pdp_df['uplift'] = (target_pdp_df['mean'] - target_pdp_df['mean'].min()) / (target_pdp_df['mean'].max() - target_pdp_df['mean'].min())

        target_pdp_df[f'{target_media}_sales_contribution'] = target_pdp_df['uplift']*max_sales_contribution

        # Get impressions
        template_df_target_impr = self.template_df.loc[(self.template_df['Driver'] == target_media) & (self.template_df['Media'] == 'Y')]
        template_df_target_impr = template_df_target_impr[[col for col in template_df_target_impr.columns if col not in self._template_columns]]
        
        # Get spend
        drivers_split = {}
        for spend_driver in self.template_df.loc[(self.template_df['Metric'] == 'Spends')]['Driver'].unique():
            drivers_split[spend_driver] = spend_driver.split('_')
        channel_campaign_spend_driver = []
        for driver in drivers_split:
            drivers_split[driver].remove('spend')
            if all(elem in target_media.split('_')  for elem in drivers_split[driver]):
                channel_campaign_spend_driver.append(driver)
        template_df_target_spend = self.template_df.loc[self.template_df['Driver'].isin(channel_campaign_spend_driver)]
        template_df_target_spend = template_df_target_spend[[col for col in template_df_target_spend.columns if col not in self._template_columns]]
        
        # Get CPM
        media_df_target = self.adstock_df.loc[self.adstock_df['KPI'] == target_media].reset_index()
        cost_per_impr = template_df_target_spend.sum().sum()/template_df_target_impr.sum().sum()
        
        adstock_col = [col for col in target_pdp_df.columns if 'adstock' in col]

        # Get Reach
        target_pdp_df[f'{target_media}_reach'] = target_pdp_df[adstock_col[0]] * media_df_target['Factor'][0]

        # Get Cost/Budget
        target_pdp_df[f'{target_media}_cost'] = target_pdp_df[adstock_col[0]] * media_df_target['Factor'][0] * cost_per_impr
        
        if target_pdp_df['uplift'].isnull().values.any():
            raise InadequateMediaError("WARNING: Media features do not appear to be important in the model, hence run Regression Budget instead.")
    
        reach_lower, sales_contr_lower, budget_lower = calculate_sales_budget(target_pdp_df, 0.68)
        reach_upper, sales_contr_upper, budget_upper = calculate_sales_budget(target_pdp_df, 1)
        
        new_budget_df = pd.DataFrame({'channel/campaign': [target_media], 'reach_lower': reach_lower, 'sales_contribution_lower': sales_contr_lower, 'budget_lower': budget_lower, 'reach_upper': reach_upper, 'sales_contribution_upper': sales_contr_upper, 'budget_upper': budget_upper})
        return new_budget_df
            
    def get_budget(self):

        budget_df = pd.DataFrame(columns=['channel/campaign', 'reach_lower', 'sales_contribution_lower', 'budget_lower', 'reach_upper', 'sales_contribution_upper', 'budget_upper'])
        for target_media in self.pdp_dai_target_paths:
            max_sales_contribution = self.contribution_df[[col for col in self.contribution_df.columns if target_media in col]].sum(axis=1).max()
            budget_df = budget_df.append(self.get_target_media_budget(target_media, max_sales_contribution))
        
        self.logger.info(f'Successfully generated upper and lower budget for all channels/campaigns.')
        return budget_df

    