import pandas as pd

import mroi.logging as mroi_logging

class Shapley(object):
    def __init__(self, predictions: pd.DataFrame, shapley: pd.DataFrame, template_file_path: str, raw_file_path: str, target: str = "DIST_SELLOUT_VOL"):
        self.logger = mroi_logging.getLogger(self.__class__.__name__)

        self.predictions_df = predictions
        self.shapley_df = shapley
        self.target = target
        
        self._non_date_columns = ['Market', 'Region', 'Subregion', 'Brand', 'SubBrand', 'Segment', 'SubSegment', 'Product',
                    'PBI Group', 'Channel', 'Bucket_1', 'Bucket_2', 'Driver', 'Driver.Classification',
                    'Metric', 'Media', 'Hierarchical_Y_N', 'Control_Y_N', 'Adstock_Y_N', 'Monotonic', 'Mandatory', 'Feature_index']
        
        self.template_file_path = template_file_path
        self.raw_file_path = raw_file_path
        self.template_df = pd.read_csv(self.template_file_path)
        self.raw_df = pd.read_csv(self.raw_file_path)

    def apply_no_campaign_alignment(self, contributions):
        raw_df = pd.read_csv(self.raw_file_path)
        raw_df.columns = [col.replace('_adstock', '') for col in raw_df.columns]
        #raw_df = raw_df.loc[(raw_df['DATE'] > global_config["contributions_start_date"]) & (raw_df['DATE'] < global_config["contributions_end_date"])].reset_index().drop(columns=['index'])
        contributions = contributions.reset_index().drop(columns=['index'])
        for driver in contributions.columns:
            if driver not in ['base', 'actual', 'raw_predn']:
                contributions['bias_bc_no_campaign'] = 0
                no_campaign_indexes = list(raw_df[raw_df[driver] == 0].index)
                for index in no_campaign_indexes:
                    if contributions[driver][index] != 0:
                        contributions.loc[index, 'bias_bc_no_campaign'] = contributions[driver][index]
                        contributions.loc[index, driver] = 0
                contributions['base'] = contributions['base'] + contributions['bias_bc_no_campaign']
                contributions = contributions.drop(['bias_bc_no_campaign'], axis=1)
                contributions = contributions.reset_index().drop(columns=['index'])
        return contributions

    def apply_adstock_alignment(self, contributions, nested_fields):
        def split_list(n):
            """will return the list index"""
            return [(x+1) for x,y in zip(n, n[1:]) if y-x != 1]

        def get_sub_list(my_list):
            """will split the list base on the index"""
            my_index = split_list(my_list)
            output = list()
            prev = 0
            for index in my_index:
                new_list = [ x for x in my_list[prev:] if x < index]
                output.append(new_list)
                prev += len(new_list)
            output.append([ x for x in my_list[prev:]])
            return output
        
        def adstock_period_manipulations(manipulations, raw_df, adstock_indexes, adstock_driver_cols):
            manipulations += 1
            adstock_actual = raw_df[raw_df.index.isin(adstock_indexes)][[adstock_driver_var + '_adstock']]
            adstock_ratio = adstock_actual[[adstock_driver_var + '_adstock']].div(adstock_actual.shift(1))
            adstock_ratio.columns = ['adstock_ratio']
            adstock_ratio = adstock_ratio.reset_index()
            adstock_contributions_actual = contributions[contributions.reset_index().index.isin(adstock_indexes)][[adstock_driver_cols[0]]].reset_index()
            adstock_contributions_actual = adstock_contributions_actual.rename(columns = {'index': 'date'})
            contributions_manipulated_df = adstock_ratio.join(adstock_contributions_actual)
            contributions_manipulated_df[adstock_driver_cols[0] + '_manip'] = 0
            contribution_manipulated = contributions_manipulated_df['adstock_ratio'][1] * contributions_manipulated_df[adstock_driver_cols[0]][0]
            contributions_manipulated_df.loc[contributions_manipulated_df.index == 1, adstock_driver_cols[0] + '_manip'] = contribution_manipulated
            for j in range(1, len(contributions_manipulated_df)-1):
                contribution_manipulated = contributions_manipulated_df[adstock_driver_cols[0] + '_manip'][j] * contributions_manipulated_df['adstock_ratio'][j+1]
                contributions_manipulated_df.loc[contributions_manipulated_df.index == j+1, adstock_driver_cols[0] + '_manip'] = contribution_manipulated
            contributions_manipulated_df = contributions_manipulated_df.iloc[1: , :]
            contributions_manipulated_df = contributions_manipulated_df.set_index('date')
            return manipulations, contributions_manipulated_df
        
        adstock_driver_vars = list(self.template_df[self.template_df['Adstock_Y_N'] == 'Y']['Driver'].unique())
        adstock_driver_vars = [adstock_driver_var for adstock_driver_var in adstock_driver_vars if adstock_driver_var not in nested_fields]
        for adstock_driver_var in adstock_driver_vars:
            manipulations = 0
            actual = self.template_df[self.template_df['Driver'] == adstock_driver_var][[col for col in self.template_df.columns if col not in self._non_date_columns]].T.reset_index()
            actual.columns = ['date', 'impressions']
            adstock_indexes = list(self.raw_df[(self.raw_df.index.isin(list(actual[actual['impressions'] == 0].index.unique()))) & (self.raw_df[adstock_driver_var + '_adstock'] != 0)].index)
            if adstock_indexes != []:
                adstock_indexes_separate = get_sub_list(adstock_indexes)
    
                for elem in adstock_indexes_separate:
                    elem.append(min(elem)-1)
                contributions_manipulated_all_df = pd.DataFrame()
                for adstock_indexes in adstock_indexes_separate:
                    adstock_driver_cols = [col for col in contributions.columns if adstock_driver_var in col] 
                    if adstock_driver_cols != []:
                        adstock_actual = self.raw_df[self.raw_df.index.isin(adstock_indexes)][[adstock_driver_var + '_adstock']]
                        adstock_ratio = adstock_actual[adstock_driver_var + '_adstock'].iloc[-1]/adstock_actual[adstock_driver_var + '_adstock'].iloc[0]
                        #print(adstock_ratio)

                        adstock_contributions = contributions[contributions.reset_index().index.isin(adstock_indexes)][adstock_driver_cols[0]]
                        #print(type(adstock_contributions))
                        contrib_ratio = adstock_contributions.iloc[-1]/adstock_contributions.iloc[0]
                        #print(adstock_contributions.head())
                        #print(contrib_ratio)
                        if not adstock_contributions.is_monotonic_decreasing:
                            manipulations, contributions_manipulated_df = adstock_period_manipulations(manipulations,self.raw_df, adstock_indexes,adstock_driver_cols)
                            if not contributions_manipulated_all_df.empty:
                                contributions_manipulated_all_df = contributions_manipulated_all_df.append(contributions_manipulated_df)
                            else:
                                contributions_manipulated_all_df = contributions_manipulated_df
                        elif contrib_ratio - adstock_ratio >= 0.10:
                            manipulations, contributions_manipulated_df = adstock_period_manipulations(manipulations,self.raw_df, adstock_indexes,adstock_driver_cols)
                            if not contributions_manipulated_all_df.empty:
                                contributions_manipulated_all_df = contributions_manipulated_all_df.append(contributions_manipulated_df)
                            else:
                                contributions_manipulated_all_df = contributions_manipulated_df
            if manipulations > 0:
                contributions = contributions.join(contributions_manipulated_all_df[[adstock_driver_cols[0] + '_manip']], how='left')
                contributions.loc[contributions[adstock_driver_cols[0] + '_manip'].isnull(),adstock_driver_cols[0] + '_manip'] = contributions[adstock_driver_cols[0]]
                contributions['base'] = contributions['base'] + contributions[adstock_driver_cols[0]] - contributions[adstock_driver_cols[0] + '_manip']
                contributions = contributions.drop(columns=[adstock_driver_cols[0]])
                contributions = contributions.rename(columns = {adstock_driver_cols[0] + '_manip': adstock_driver_cols[0]})
        return contributions
    
    def transform_contributions(self):
        up_drivers = list(self.template_df[self.template_df['Monotonic'] == 'up']['Driver'].unique())
        if 'seasonality' in self.shapley_df.columns:
            up_drivers.append('seasonality')

        down_drivers = list(self.template_df[self.template_df['Monotonic'] == 'down']['Driver'].unique())

        base_drivers = list(self.template_df[self.template_df['Control_Y_N'] == 'base']['Driver'].unique())
        if 'seasonality' in self.shapley_df.columns:
            base_drivers.append('seasonality')

        max_df = pd.DataFrame(self.shapley_df.max())
        max_df.columns = ['max']
        min_df = pd.DataFrame(self.shapley_df.min())
        min_df.columns = ['min']

        max_min_df = max_df.merge(min_df, left_index=True, right_index=True).reset_index()
        
        self.logger.info(f'up drivers: {up_drivers}')
        for up_driver in up_drivers:
            shapley_df_up_driver_cols = [col for col in self.shapley_df.columns if up_driver == col] 
            if shapley_df_up_driver_cols != []:
                #shapley_df_up_drivers_dict = {}
                #for shapley_df_up_driver_col in shapley_df_up_driver_cols:
                 #   col_proc = shapley_df_up_driver_col.replace('_adstock', '').replace('contrib_', '')
                  #  col_proc = col_proc[col_proc.find('_') + 1:]
                   # shapley_df_up_drivers_dict[shapley_df_up_driver_col] = col_proc
                #shapley_df_col = [k for k,v in shapley_df_up_drivers_dict.items() if v == up_driver]
                #if shapley_df_col != []:
                if max_min_df[max_min_df['index'] == shapley_df_up_driver_cols[0]]['min'].reset_index()['min'][0] < 0:
                    self.logger.info(f'up driver transf: {up_driver}')
                    self.shapley_df[shapley_df_up_driver_cols] = self.shapley_df[shapley_df_up_driver_cols] - max_min_df[max_min_df['index'] == shapley_df_up_driver_cols[0]]['min'].reset_index()['min'][0]
                    self.shapley_df[[col for col in self.shapley_df.columns if 'bias' in col]] = self.shapley_df[[col for col in self.shapley_df.columns if 'bias' in col]] + max_min_df[max_min_df['index'] == shapley_df_up_driver_cols[0]]['min'].reset_index()['min'][0]
        
        self.logger.info(f'down drivers: {down_drivers}')
        for down_driver in down_drivers:
            shapley_df_down_driver_cols = [col for col in self.shapley_df.columns if down_driver == col] 
            if shapley_df_down_driver_cols != []:
                #shapley_df_down_drivers_dict = {}
                #for shapley_df_down_driver_col in shapley_df_down_driver_cols:
                 #   col_proc = shapley_df_down_driver_col.replace('_adstock', '').replace('contrib_', '')
                  #  col_proc = col_proc[col_proc.find('_') + 1:]
                   # shapley_df_down_drivers_dict[shapley_df_down_driver_col] = col_proc
                #shapley_df_col = [k for k,v in shapley_df_down_drivers_dict.items() if v == down_driver]
                #if shapley_df_col != []:
                if max_min_df[max_min_df['index'] == shapley_df_down_driver_cols[0]]['max'].reset_index()['max'][0] > 0:
                    self.logger.info(f'down driver transf: {down_driver}')
                    self.shapley_df[shapley_df_down_driver_cols] = self.shapley_df[shapley_df_down_driver_cols] - max_min_df[max_min_df['index'] == shapley_df_down_driver_cols[0]]['max'].reset_index()['max'][0]
                    self.shapley_df[[col for col in self.shapley_df.columns if 'bias' in col]] = self.shapley_df[[col for col in self.shapley_df.columns if 'bias' in col]] + max_min_df[max_min_df['index'] == shapley_df_down_driver_cols[0]]['max'].reset_index()['max'][0]
        
        #self.logger.info(f'base drivers: {base_drivers}')
        #for base_driver in base_drivers:
         #   shapley_df_base_driver_cols = [col for col in self.shapley_df.columns if base_driver == col] 
          #  if shapley_df_base_driver_cols != []:
           #     self.logger.info(f'base driver transf: {base_driver}')
            #    self.shapley_df[[col for col in self.shapley_df.columns if 'bias' == col][0]] = self.shapley_df[[col for col in self.shapley_df.columns if 'bias' == col][0]] + self.shapley_df[shapley_df_base_driver_cols[0]]
             #   self.shapley_df = self.shapley_df.drop(columns=[shapley_df_base_driver_cols[0]], axis=1)

        #actual_sales_df = self.template_df[self.template_df['Mandatory'] == 'target'][[col for col in self.template_df.columns if col not in self._non_date_columns]].T
        actual_sales_df = self.raw_df[[self.target]]
        actual_sales_df.columns = ['actual']

        self.shapley_df['actual'] = actual_sales_df.reset_index()['actual']
        self.shapley_df['actual'] = self.shapley_df['actual'].astype(float)

        bias_col = [col for col in self.shapley_df.columns if 'bias' in col]
        self.shapley_df = self.shapley_df.rename(columns={bias_col[0]: 'base'})
            
        self.shapley_df['raw_predn'] = self.predictions_df['prediction']

        self.shapley_df['base'] = self.shapley_df['base'] + (self.shapley_df['actual'] - self.shapley_df['raw_predn'])

        return self.shapley_df
        