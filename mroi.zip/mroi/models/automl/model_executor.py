import re
import io

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from mroi.config import EXECUTION_BASE_PATH, PILOT_EXECUTION_BASE_PATH, json_config, AutoMLVariablesConfig,TEMPORARY_GCS_BUCKET
from mroi.utils import gcs_join, GCSUrl, upload_to_gcs, download_from_gcs
from mroi.exceptions import *

import mroi.logging as mroi_logging
from mroi.io.bigquery import ModelResultsFactory

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import SparkSession


class AutoMLOrchestrator:
    def __init__(self, model_config: dict, model_id: str):
        self.model_config = model_config
        self.results_table = ModelResultsFactory.get_results_table(model_id)

        self.logger = mroi_logging.getLogger(self.__class__.__name__)

        self._template_columns = ['Market', 'Region', 'Subregion', 'Brand', 'SubBrand', 'Segment', 'SubSegment',
                                  'Product',
                                  'PBI Group', 'Channel', 'Bucket_1', 'Bucket_2', 'Driver', 'Driver.Classification',
                                  'Metric', 'Media', 'Hierarchical_Y_N', 'Control_Y_N', 'Adstock_Y_N', 'Monotonic',
                                  'Mandatory']

    def delete_previous_execution(self, *args, **kwargs):
        # this function must be overridden by a child class
        pass

    def save_template_excel(self, template: pd.DataFrame, upload_location: str):
        """
        Create an updated regression excel file from regression data

        Args:
            template (pd.DataFrame): regression data with both raw and adstocked media features
            upload_location (str): GCS location for saving the excel file

        Returns:
            pd.DataFrame: Original dataframe with some transformations
        """
        template_df = template.copy()
        template_df["Driver"] = np.where(template_df["Feature_index"].str.endswith("_adstock"), "SEf." + template_df["Driver"], template_df["Driver"])
        template_df.drop(columns=["Feature_index"], inplace=True)

        with pd.ExcelWriter(upload_location, engine='openpyxl') as writer:
            template_df.to_excel(writer, sheet_name="Sheet1", index=False)
        return template_df

    def plot_adstocked_media_kpis(self, template_adstock_features: pd.DataFrame, upload_location: str):
        """
        Create a graph plot for adstocked media KPIs and upload it to specified path

        Args:
            template_adstock_features (pd.DataFrame): media adstocked data
            upload_location (str): GCS location for saving the image
        """
        date_columns = [col for col in template_adstock_features.columns if re.search(r"\d{4}-\d{2}-\d{2}", col)]
        adstocked_media = template_adstock_features[["Driver"] + date_columns]
        adstocked_media = adstocked_media.set_index("Driver")
        adstocked_media = adstocked_media.T
        n_media_kpis = len(adstocked_media.columns)
        if n_media_kpis == 0:
            raise InvalidMediaKPIsError("All media KPIs selected have zero variance. Please select atleast one media datasource with proper KPI data.")
        fig, axes = plt.subplots(nrows=n_media_kpis, ncols=1, figsize=(20, min(n_media_kpis*5, 650)))
        fig.set_facecolor('#ffffff')
        row_axis = 0
        for kpi in adstocked_media.columns:
            if n_media_kpis == 1:
                adstocked_media[[kpi]].plot(kind="line", ax=axes)
            else:
                adstocked_media[[kpi]].plot(kind="line", ax=axes[row_axis])
            row_axis += 1
        # Save image to bytestream to upload to GCS
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        buf.seek(0)
        image_in_buffer = buf.read()
        buf.close()
        upload_to_gcs(upload_location, image_in_buffer, content_type='image/png')

    def create_new_adstock(self, media: pd.DataFrame, adstocked_media: pd.DataFrame):
        """
        Create an updated adstock file from saturation data

        Args:
            media (pd.DataFrame): raw media data
            adstocked_media (pd.DataFrame): adstock data created from media file and transformed
            mapfile (pd.DataFrame): final mapfile after all  transformations
        """
        updated_adstock = adstocked_media.rename(columns={'Adstock': 'KPI'})
        updated_adstock['Limit'] = 10.55
        tv_drivers = updated_adstock[updated_adstock['KPI'].str.contains("TV") & (~updated_adstock['KPI'].str.contains("FIRESTICK"))]['KPI'].to_list()
        # Modify adstock based on Saturation flags and values
        for i in range(0, len(updated_adstock)):
            if (updated_adstock['KPI'][i] in tv_drivers) & (updated_adstock['Saturation'][i] < 0.5):
                updated_adstock.loc[i, 'SaturationFlag'] = 'T'
                updated_adstock.loc[i, 'Limit'] = 0.95
            elif (updated_adstock['KPI'][i] not in tv_drivers) & ((updated_adstock['Saturation'][i] == 0.1) |
                                                                (updated_adstock['Saturation'][i] == 0.05)):
                updated_adstock.loc[i, 'SaturationFlag'] = 'T'
                updated_adstock.loc[i, 'Limit'] = 0.95
            else:
                updated_adstock.loc[i, 'Limit'] = updated_adstock['Limit'][i]
        updated_adstock = updated_adstock.reset_index().drop('Saturation', axis=1)
        original_adstk = media.copy()
        updated_adstock['SL_Limit'] = original_adstk['SL_Limit']
        updated_adstock['SU_Limit'] = original_adstk['SU_Limit']
        updated_adstock = updated_adstock[['KPI', 'SL_Limit', 'SU_Limit', 'Factor', 'Limit', 'SaturationFlag']]
        return updated_adstock

    def generate_revenue_contributions(self, contrib: pd.DataFrame) -> pd.DataFrame:
        """
        Generate revenue contributions for drivers.

        Args:
            contrib (pd.DataFrame): Contributions

        Returns:
            pd.DataFrame: Original dataframe and dataframe with avgPrice calculated
        """
        contrib_revenue = contrib.copy()
        retail_margin_price = float(self.model_config.get("retail_margin_price", 0))
        cols = contrib_revenue.columns
        for k in cols:
            if k not in ['DATE', 'Segment', 'PBI Group', 'avgPrice_actual']:
                if retail_margin_price != 0.0:
                    contrib_revenue[k] = contrib_revenue[k] * retail_margin_price
                else:
                    contrib_revenue[k] = contrib_revenue[k] * contrib_revenue['avgPrice_actual']
        return contrib_revenue

    def calculate_pct_contributions(self, output: pd.DataFrame, template_df: pd.DataFrame,
                                    weak_features: list) -> pd.DataFrame:
        """
        Calculate pivot table with % contributions to actual

        Args:
            output (pd.DataFrame): raw output df with contributions per week date
            template_df (pd.DataFrame): raw input regression data
            weak_features (list): list of weak features calculated while training the model

        Returns:
            pd.DataFrame: Output Dataframe with % contributions calculated
        """
        driver_sums = output.sum(numeric_only=True, axis=0).to_frame()
        driver_sums = driver_sums.reset_index()
        driver_sums = driver_sums.rename(columns={0: 'Sum', 'index': 'Drivers'})
        driver_sums = driver_sums[~driver_sums.Drivers.str.contains("avgPrice_actual|raw_predn")]
        df_with_contributions = driver_sums
        df_with_contributions['Total_sum'] = df_with_contributions['Sum'][
            df_with_contributions.Drivers != 'actual'].sum()
        df_with_contributions['%Contribution_to_actual'] = (df_with_contributions['Sum'] / df_with_contributions[
            'Total_sum']) * 100
        df_with_contributions = df_with_contributions.drop(['Total_sum'], axis=1)

        driver_mapping = dict(template_df[['Driver', 'Driver.Classification']].values)
        # Add seasonality to the map since it's not available in the original template file
        if df_with_contributions['Drivers'].str.contains("seasonality").any():
            driver_mapping["seasonality"] = "seasonality"
        driver_mapping['base'] = 'base'
        df_with_contributions['Driver Classification'] = df_with_contributions.Drivers.map(driver_mapping)
        df_with_contributions['Prediction Strength'] = df_with_contributions['Drivers'].apply(
            lambda x: 'weak' if (x in weak_features) else 'strong')

        media_ind_df = template_df.loc[(template_df['Media'] == 'Y'), ['Driver', 'Media']]
        media_ind_df = media_ind_df.append(template_df.loc[template_df['Driver'].str.lower().str.contains(
            r'impression|click|reach|grp|trp'), ['Driver', 'Media']]).drop_duplicates()
        media_ind_df['Media'] = 'Y'
        df_with_contributions['Media_Indicator'] = df_with_contributions['Drivers'].map(dict(media_ind_df.values))

        spends_df = template_df[template_df['Metric'] == 'Spends']
        if 'Feature_index' in spends_df.columns:
            spends_df = spends_df[
                [col for col in spends_df.columns if col not in self._template_columns]].set_index(
                'Feature_index').sum(axis=1)
        else:
            spends_df = spends_df[[col for col in spends_df.columns if
                                   col == 'Driver' or col not in self._template_columns]].set_index(
                'Driver').sum(axis=1)
        spends_df.index = spends_df.index.str.replace('spends', 'spend').str.lower()
        df_with_contributions['spend_key'] = df_with_contributions['Drivers'].apply(lambda x: re.sub(
            r'viewable_impressions|viewable_impression|impressions|impression|views|view|clicks|click|reach|grps|grp|trps|trp',
            'spend', x.lower()))
        df_with_contributions['Spends'] = df_with_contributions['spend_key'].map(dict(spends_df))
        df_with_contributions = df_with_contributions.drop(columns='spend_key')
        return df_with_contributions

    def write_contributions_output(self, contributions: pd.DataFrame, template_df: pd.DataFrame, output_path: str, weak_features: list):
        """
        Write output data with contributions as an excel file to specified location

        Args:
            contributions (pd.DataFrame): raw output data with contribution per week date
            template_df (pd.DataFrame): raw input regression data
            output_path (str): GCS location to save the excel file
            weak_features (list): list of weak features calculated while training the model
        """
        pct_contributions = self.calculate_pct_contributions(contributions, template_df, weak_features)
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            contributions.to_excel(writer, sheet_name="Sheet1", index=True)
            pct_contributions.to_excel(writer, sheet_name="Sheet2", index=False)

    def combine_input_output(self, regression_data: pd.DataFrame, contrib: pd.DataFrame, revenue_contrib: pd.DataFrame,
                             features_dropped: list, output_file_path: str):
        """
        Combines ouput and merges with regression.xlsx, and saves regression_data.xlsx in output folder

        Args:
            regression_data (pd.DataFrame): regression data with adstocked media features
            contrib (pd.DataFrame): contribution dataframe
            revenue_contrib (pd.DataFrame): revenue contribution dataframe
            features_dropped (list): list of features dropped while training the model
            output_file_path (str): output file path
        """

        def get_required_structure(df: pd.DataFrame, revenue=False):
            """
            Converts structure of contrib and revenue contrib to match the regression output.

            Args:
                df (pd.DataFrame): contribution or revenue contribution dataframe
                revenue (bool): default value is False
            """
            df = df.drop(columns=[col for col in df.columns if col in ['PBI Group', 'Segment', 'avgPrice_actual']])
            df = df.T
            df = df.reset_index()
            df = df.rename(columns={'index': 'Driver'})
            df['Driver.Classification'] = df['Driver'].apply(
                lambda x: x.replace('_direct', '').replace('_indirect', ''))
            if revenue:
                metric = 'Revenue'
            else:
                metric = 'Sales'
            df['Metric'] = f'Contribution_{metric}'
            df.loc[df['Driver.Classification'].isin(['actual', 'raw_predn']), 'Metric'] = df[
                                                                                              'Driver.Classification'] + f'_{metric}'
            df['Channel'] = df['Driver.Classification'].apply(
                lambda x: re.sub(r"_[^_]*_impressions.*|_[^_]*_clicks.*", "", x))
            return df

        fill_cols = ['Market', 'Region', 'Subregion', 'Brand', 'SubBrand', 'Segment', 'SubSegment', 'Product',
                     'PBI Group', 'Bucket_2']
        pilot_drivers = list(
            set(regression_data.loc[regression_data['Bucket_1'] == 'Target', 'Driver.Classification'].values.tolist()))
        contrib_df = get_required_structure(contrib, revenue=False)
        revenue_contrib_df = get_required_structure(revenue_contrib, revenue=True)

        regression_alldata = pd.concat([regression_data, contrib_df], ignore_index=True)
        regression_alldata = pd.concat([regression_alldata, revenue_contrib_df], ignore_index=True)
        regression_alldata.loc[regression_alldata['Driver.Classification'].isin(pilot_drivers), 'Bucket_1'] = 'Target'
        regression_alldata.insert(regression_alldata.columns.get_loc('Driver') + 1, 'Driver_dropped', '')
        regression_alldata.loc[regression_alldata['Driver'].isin(features_dropped), 'Driver_dropped'] = 'Y'
        regression_alldata.loc[:, fill_cols] = regression_alldata.loc[:, fill_cols].ffill()
        regression_alldata.to_excel(output_file_path, index=False, engine='openpyxl')

    def generate_bq_output(self, budget_df: pd.DataFrame, region: str) -> pd.DataFrame:
        # this function must be overridden by a child class
        pass

    def orchestrate(self):
        # this function must be overridden by a child class
        pass

    def save_detailed_bq_output(self, variables_config):
        """
        Save the detailed output (weekly) on Big Query to be used by the Decomp Power BI report

        Args:
            variables_config: object of AutoMLVariablesConfig
        """

        def get_select_list(alias):
            return [F.col("Driver"), F.col("Date"), F.col("value").alias(alias)]

        def get_schema(df, convert_date=False):
            schema = []
            for column in df.columns:
                if column in ['value', 'Contribution', 'Sales', 'Spend', 'raw_predn', 'avgPrice_actual']:
                    schema.append(T.StructField(column, T.FloatType(), True))
                elif column == 'Date' and convert_date:
                    schema.append(T.StructField(column, T.DateType(), True))
                else:
                    schema.append(T.StructField(column, T.StringType(), True))
            return T.StructType(schema)

        spark = SparkSession.builder.getOrCreate()
        table_id = "AIDE_Results.AutoML_Weekly"
        join_columns = ['Driver', 'Date']
        self.logger.info(f"Uploading results to {table_id}")

        # Regression data
        regression_data = pd.read_excel(variables_config.COMBINED_OUTPUT_FILE, sheet_name="Sheet1").fillna(
            np.nan).replace([np.nan], [None])
        regression_data.drop(columns=["Driver_dropped"], inplace=True)

        # Output Sheet #1
        df_output_01 = pd.read_excel(variables_config.OUTPUT_FILE, sheet_name="Sheet1").fillna(np.nan).replace([np.nan],
                                                                                                               [None])
        df_output_01 = spark.createDataFrame(df_output_01, get_schema(df_output_01)).select("Date", "avgPrice_actual",
                                                                                            "raw_predn")

        # Output Sheet #2
        df_output = pd.read_excel(variables_config.OUTPUT_FILE, sheet_name="Sheet2").fillna(np.nan).replace([np.nan],
                                                                                                            [None])
        df_output = spark.createDataFrame(df_output, get_schema(df_output))
        df_output = (df_output.select(F.col('Drivers').alias('Driver'),
                                      F.col('Prediction Strength').alias('Prediction_Strength'),
                                      F.col('Media_Indicator')).where(~F.col('Driver').isin(['actual', 'avgPrice'])))

        # Unpivot dataframe
        columns = ['Market', 'Region', 'Subregion', 'Brand', 'SubBrand', 'Segment', 'SubSegment', 'Product',
                   'PBI Group', 'Channel', 'Bucket_1', 'Bucket_2', 'Driver', 'Driver.Classification',
                   'Driver.Group.Number', 'Metric', 'Media',
                   'Hierarchical_Y_N', 'Control_Y_N', 'Adstock_Y_N', 'Monotonic', 'Mandatory']
        regression_data = pd.melt(regression_data, id_vars=columns, var_name="Date", value_name="value")
        df_regression = spark.createDataFrame(regression_data, get_schema(regression_data))

        # Contribution,Sales, Spend
        df_contribution = df_regression.select(get_select_list('Contribution')).where(
            F.col("metric") == "Contribution_Revenue")
        df_spend = df_regression.where(F.col("Driver").contains("spend")).select(
            F.regexp_replace("Driver", "spend", "impressions").alias("Driver"), "Date", F.col("value").alias("Spend"))
        df_sales = df_regression.select(get_select_list('Sales')).where(F.col("metric") == "Contribution_Sales")

        # Combine dataframes
        df_automl_weekly = (df_regression.join(df_contribution, join_columns, "left")
                            .join(df_spend, join_columns, "left")
                            .join(df_sales, join_columns, "left")
                            .join(df_output_01, "Date", "left"))
        df_automl_weekly = df_automl_weekly.join(df_output, "Driver", "left").where(
            F.col('Metric') == 'Contribution_Revenue')

        df_automl_weekly = (df_automl_weekly.withColumn("Date", F.to_date(F.col("Date"), "yyyy-MM-dd"))
                            .withColumn('test_control_group',
                                        F.lit(variables_config.COMBINED_OUTPUT_FILE.split("/")[-2]))
                            .withColumnRenamed('PBI Group', 'PBI_Group')
                            .withColumnRenamed('Driver.Classification', 'Driver_Classification')
                            .withColumnRenamed('Driver.Group.Number', 'Driver_Group_Number')
                            .withColumn("run_id", F.lit(json_config["metadata"]["aide_id"]))
                            .drop("Media")
                            .drop("value"))

        # Save data
        df_results = spark.createDataFrame(df_automl_weekly.rdd, get_schema(df_automl_weekly, True))

        (df_results.write.format('bigquery')
         .mode("append")
         .option("temporaryGcsBucket", TEMPORARY_GCS_BUCKET)
         .option('table', table_id)
         .save())
        self.logger.info("Loaded {} rows and {} columns to {}".format(df_results.count(), len(df_results.columns), table_id))
