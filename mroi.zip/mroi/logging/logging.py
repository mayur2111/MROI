import logging

TYPE = 'auto'

def getLogger(name: str):
    return MROILogger(name, TYPE)

class MROILogger(object):
    def __init__(self, name: str=None, logger_type='auto') -> None:
        self.name = name
        try:
            from pyspark.sql import SparkSession
            spark = SparkSession.builder.getOrCreate()
            log4jLogger = spark.sparkContext._jvm.org.apache.log4j
            log4jLogger.LogManager.getLogger("org").setLevel(log4jLogger.Level.ERROR)
            log4jLogger.LogManager.getLogger("akka").setLevel(log4jLogger.Level.ERROR)
            self._logger = log4jLogger.LogManager.getLogger(self.name if self.name else self.__class__.__name__)
        except:
            self._logger = logging.getLogger(self.name if self.name else self.__class__.__name__)

        if logger_type == 'python':
            self._logger = logging.getLogger(self.name if self.name else self.__class__.__name__)

    def debug(self, msg: str):
        self._logger.debug(msg)

    def info(self, msg: str):
        self._logger.info(msg)

    def warn(self, msg: str):
        if type(self._logger) is logging.Logger:
            self._logger.warning(msg)
            return
        self._logger.warn(msg)

    def error(self, msg: str):
        self._logger.error(msg)

    def setLevel(self, level: int):
        self._logger.setLevel(level)