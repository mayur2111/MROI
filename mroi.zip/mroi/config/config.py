from pathlib import Path
import configparser
import google.auth
import json
import os


config = configparser.ConfigParser()
try:
    config.read("pipeline_constants.ini")
    with open("config.json") as f:
        json_config = json.load(f)
except:
    try:
        from pyspark import SparkFiles
        config.read(SparkFiles.get("pipeline_constants.ini"))
        with open(SparkFiles.get("config.json")) as f:
            json_config = json.load(f)
    except:
        config.read(os.path.join(Path(__file__).parents[2], "pipeline_constants.ini"))
        with open(os.path.join(Path(__file__).parents[2], "config.json")) as f:
            json_config = json.load(f)

ENV = config["ENV"]["MODE"]
ZONE = config["ENV"].get("ZONE")
SUBNET = config["ENV"].get("SUBNET")
APP = json_config["config"]["app_name"]
COSTCENTER = config["ENV"]["COSTCENTER"]

PUDDLE_SERVER_ADDRESS = config["PUDDLE"]["PUDDLE_SERVER_ADDRESS"]
PUDDLE_VM_NAME_AUTOML = config["PUDDLE"]["PUDDLE_VM_NAME_AUTOML"]
PUDDLE_VM_NAME_AUTOMLBUDGET = config["PUDDLE"]["PUDDLE_VM_NAME_AUTOMLBUDGET"]
PUDDLE_VM_NAME_SU = config["PUDDLE"]["PUDDLE_VM_NAME_SU"]
PUDDLE_VM_NAME_RBT = config["PUDDLE"]["PUDDLE_VM_NAME_RBT"]
PUDDLE_API_KEY_SECRET = config["PUDDLE"]["PUDDLE_API_KEY_SECRET"]
PUDDLE_API_SECRET_KEY_SECRET = config["PUDDLE"]["PUDDLE_API_SECRET_KEY_SECRET"]

NOTIFICATION_TOPIC = config["NOTIFICATION"]["NOTIFICATION_TOPIC"]
JOBSTATUS_TOPIC = config["NOTIFICATION"]["JOBSTATUS_TOPIC"]
RECEIVERS = json_config["metadata"]["aide_id"].split('_')[0]
AIDE_ID = json_config["metadata"]["aide_id"]
COUNTRY = json_config["config"]["country"]
BRAND = json_config["config"]["brand"]
SUB_BRAND = json_config["config"]["sub_brand"] if type(json_config["config"]["sub_brand"]) is str else ','.join(json_config["config"]["sub_brand"])
SEGMENT = json_config["config"]["segment"] if type(json_config["config"]["segment"]) is str else ','.join(json_config["config"]["segment"])
SUB_SEGMENT = json_config["config"]["sub_segment"] if type(json_config["config"]["sub_segment"]) is str else ','.join(json_config["config"]["sub_segment"])

EXECUTION_BASE_PATH = config["PATHS"]["BASE_PATH"]
PILOT_EXECUTION_BASE_PATH = config["PATHS"].get("PILOT_BASE_PATH")
RBT_EXECUTION_BASE_PATH = config["PATHS"].get("RBT_EXECUTION_BASE_PATH")

RESOURCE_KEY = config["DAG"]["RESOURCE_KEY"]
DAG_RUN_ID = config["DAG"]["DAG_RUN_ID"]

BQ_DATASET = config["BQ"]["BQ_DATASET"]
BQ_CREDS_SECRET = config["BQ"]["BQ_CREDS_SECRET"]
TEMPORARY_GCS_BUCKET = config["BQ"]["TEMPORARY_GCS_BUCKET"]

COUNTRY_ID = list(map(int, config["PARTITION_FILTERS"]["COUNTRY_ID"].split(',')))
COUNTRY_NAME = config["PARTITION_FILTERS"]["COUNTRY_NAME"].split(',')
LEGC = config["PARTITION_FILTERS"]["LEGC"].split(',')

class ModelControl(object):

    @classmethod
    def get_min_data_points(cls, model_id: str) -> int:
        """Get minimum data points required to execute the model

        Args:
            model_name: Name of the model
        Returns:
            int: minimum data points
        """
        return config.getint(model_id, "MINIMUM_DATA_POINTS")

    @classmethod
    def get_periodicity(cls, model_id: str) -> str:
        """Get Periodicity for the corresponding model

        Args:
            model_name: Name of the model to get periodicity for
        Returns:
            str: periodicity [MONTHLY/WEEKLY]
        """
        return config[model_id]["PERIODICITY"]

    @classmethod
    def get_week_start_day(cls, model_id: str) -> str:
        """Get week start day for the corresponding model

        Args:
            model_name: Name of the model to get week start day for
        Returns:
            str: week_day [SUNDAY|MONDAY...SATURDAY]
        """
        return config[model_id]["WEEK_START_DAY"]

PROJECT_ID = google.auth.default()[1]

class AutoMLVariablesConfig:
    def __init__(self, variables: dict=None):
        self._variables = dict()
        self._variables["METRIC"] = "RMSE"
        self._variables["TARGET"] = "DIST_SELLOUT_VOL"
        
        # inputs used to create training data
        self._variables["TEMPLATE_FILE_PATH"] = ""
        self._variables["ADSTOCK_FILE_PATH"] = ""
        
        # intermediate files
        self._variables["RAW_FILE"] = ""
        self._variables["CONSTRAINTS_FILE"] = ""
        self._variables["VARIABLE_MAPPING_FILE"] = ""
        
        # data for scoring/predictions
        self._variables["WIDE_SYNTH_OUT_FILE"] = ""
        self._variables["SYNTH_OUT_FILE"] = ""
        
        # h2o project details
        self._variables["PROJECT_ID"] = ""
        self._variables["PROJECT_NAME"] = ""

        # outputs
        self._variables["OUTPUT_FILE"] = ""
        self._variables["REVENUE_OUTPUT_FILE"] = ""
        self._variables["COMBINED_OUTPUT_FILE"] = ""

        # summary metrics
        self._variables["SUMMARY_METRICS_FILE"] = ""
        
        if variables:
            self._variables.update(variables)

    @property
    def METRIC(self):
        return self._variables["METRIC"]

    @METRIC.setter
    def METRIC(self, value):
        self._variables["METRIC"] = value

    @property
    def TARGET(self):
        return self._variables["TARGET"]

    @TARGET.setter
    def TARGET(self, value):
        self._variables["TARGET"] = value

    @property
    def TEMPLATE_FILE_PATH(self):
        return self._variables["TEMPLATE_FILE_PATH"]

    @TEMPLATE_FILE_PATH.setter
    def TEMPLATE_FILE_PATH(self, value):
        self._variables["TEMPLATE_FILE_PATH"] = value

    @property
    def ADSTOCK_FILE_PATH(self):
        return self._variables["ADSTOCK_FILE_PATH"]

    @ADSTOCK_FILE_PATH.setter
    def ADSTOCK_FILE_PATH(self, value):
        self._variables["ADSTOCK_FILE_PATH"] = value

    @property
    def RAW_FILE(self):
        return self._variables["RAW_FILE"]

    @RAW_FILE.setter
    def RAW_FILE(self, value):
        self._variables["RAW_FILE"] = value

    @property
    def CONSTRAINTS_FILE(self):
        return self._variables["CONSTRAINTS_FILE"]

    @CONSTRAINTS_FILE.setter
    def CONSTRAINTS_FILE(self, value):
        self._variables["CONSTRAINTS_FILE"] = value

    @property
    def VARIABLE_MAPPING_FILE(self):
        return self._variables["VARIABLE_MAPPING_FILE"]

    @VARIABLE_MAPPING_FILE.setter
    def VARIABLE_MAPPING_FILE(self, value):
        self._variables["VARIABLE_MAPPING_FILE"] = value

    @property
    def WIDE_SYNTH_OUT_FILE(self):
        return self._variables["WIDE_SYNTH_OUT_FILE"]

    @WIDE_SYNTH_OUT_FILE.setter
    def WIDE_SYNTH_OUT_FILE(self, value):
        self._variables["WIDE_SYNTH_OUT_FILE"] = value

    @property
    def SYNTH_OUT_FILE(self):
        return self._variables["SYNTH_OUT_FILE"]

    @SYNTH_OUT_FILE.setter
    def SYNTH_OUT_FILE(self, value):
        self._variables["SYNTH_OUT_FILE"] = value

    @property
    def PROJECT_ID(self):
        return self._variables["PROJECT_ID"]

    @PROJECT_ID.setter
    def PROJECT_ID(self, value):
        self._variables["PROJECT_ID"] = value

    @property
    def PROJECT_NAME(self):
        return self._variables["PROJECT_NAME"]

    @PROJECT_NAME.setter
    def PROJECT_NAME(self, value):
        self._variables["PROJECT_NAME"] = value

    @property
    def OUTPUT_FILE(self):
        return self._variables["OUTPUT_FILE"]

    @OUTPUT_FILE.setter
    def OUTPUT_FILE(self, value):
        self._variables["OUTPUT_FILE"] = value

    @property
    def REVENUE_OUTPUT_FILE(self):
        return self._variables["REVENUE_OUTPUT_FILE"]

    @REVENUE_OUTPUT_FILE.setter
    def REVENUE_OUTPUT_FILE(self, value):
        self._variables["REVENUE_OUTPUT_FILE"] = value

    @property
    def COMBINED_OUTPUT_FILE(self):
        return self._variables["COMBINED_OUTPUT_FILE"]

    @COMBINED_OUTPUT_FILE.setter
    def COMBINED_OUTPUT_FILE(self, value):
        self._variables["COMBINED_OUTPUT_FILE"] = value

    @property
    def SUMMARY_METRICS_FILE(self):
        return self._variables["SUMMARY_METRICS_FILE"]

    @SUMMARY_METRICS_FILE.setter
    def SUMMARY_METRICS_FILE(self, value):
        self._variables["SUMMARY_METRICS_FILE"] = value

    def to_json(self):
        return json.dumps(self._variables, indent=4)
