from functools import reduce
from operator import and_, or_
from typing import List, Dict, Union
from datetime import date

import pyspark
from pyspark.sql import functions as F

from mroi.logging import getLogger
from mroi.utils import access_secret_version
from mroi.config import PROJECT_ID, BQ_CREDS_SECRET, BQ_DATASET, COUNTRY_ID, COUNTRY_NAME, LEGC

class BQColumns(object):
    # period attributes
    date = "date"

    # region attributes
    country = "country"
    region = "region"

    # partition & clustering columns
    country_id = "country_id"
    partition_id = "partition_id"
    legc = "legc"
    
    # product attributes
    brand = "brand"
    sub_brand = "sub_brand"
    segment = "segment"
    sub_segment = "sub_segment"
    sku = "sku"
    manufacturer = "manufacturer"
    competitor = "competitor"
    competitor_for = "competitor_for"
    
    platform = "platform"
    duration = "duration"
    
    campaign_id = "campaign_id"
    source = "source"

    pos_store_sk = "pos_store_sk"
    
    # distribution measures
    num_stores = "num_stores"
    tdp = "tdp"
    acv_distribution = "acv_distribution"
    weighted_distribution = "weighted_distribution"
    numeric_distribution = "numeric_distribution"
    distribution = "distribution"
    
    # COVID measures
    new_cases = "new_cases"
    new_deaths = "new_deaths"
    new_lagged_deaths = "new_lagged_deaths"
    
    # sales measures
    sales_value = "sales_value"
    sales_units = "sales_units"
    sales_volume = "sales_volume"
    sales_value_promo = "sales_value_promo"
    sales_units_promo = "sales_units_promo"
    sales_volume_promo = "sales_volume_promo"
    sales_value_regular = "sales_value_regular"
    sales_units_regular = "sales_units_regular"
    sales_volume_regular = "sales_volume_regular"
    price_per_unit_promo = "price_per_unit_promo"
    price_per_volume_promo = "price_per_volume_promo"
    price_per_unit_regular = "price_per_unit_regular"
    price_per_volume_regular = "price_per_volume_regular"
    average_price = "average_price"

    # media kpis/measures
    clicks = "clicks"
    impressions = "impressions"
    viewable_impressions = "viewable_impressions"
    views = "views"
    reach = "reach"
    spend = "spend"
    revenue = "revenue"
    grp = "grp"
    trp = "trp"

    # macro measures
    population = "population"
    mobility_grocery_and_pharmacy = "mobility_grocery_and_pharmacy"
    mobility_retail_and_recreation = "mobility_retail_and_recreation"
    population_density = "population_density"
    human_development_index = "human_development_index"
    gdp_per_capita_usd = "gdp_per_capita_usd"
    human_capital_index = "human_capital_index"
    comorbidity_mortality_rate = "comorbidity_mortality_rate"
    minimum_temperature_celsius = "minimum_temperature_celsius"
    maximum_temperature_celsius = "maximum_temperature_celsius"
    average_temperature_celsius = "average_temperature_celsius"
    relative_humidity = "relative_humidity"

class Archetype(object):
    MACRO = "MACRO"
    MEDIA = "MEDIA"
    SALES = "SALES"
    CATEGORY = "CATEGORY"

# Filter Mixins
class PeriodFiltersMixin(object):
    def apply_period_filters(self, start_date: Union[str, date], end_date: Union[str, date]):
        self.df = self.df.filter(F.col(BQColumns.date).between(start_date, end_date))

class RegionFiltersMixin(object):
    def apply_region_filters(self, regions: List[str], include: bool=True):
        if not regions:
            return
        if include:
            self.df = self.df.filter(F.col(BQColumns.region).isin(regions))
        else:
            self.df = self.df.filter(~F.col(BQColumns.region).isin(regions))

class ProductFiltersMixin(object):
    def apply_product_filters(self, brand: str, sub_brand: List[str], **other_products: Dict[str, Union[str, List[str]]]):
        brand_condition = [F.col(BQColumns.brand).like(f"%{brand}%")] if brand else []
        sub_brands_condition = [reduce(or_, [F.col(BQColumns.sub_brand).like(f"%{product}%") for product in sub_brand])] if sub_brand else []
        
        other_products_conditions = []
        for product, value in other_products.items():
            if isinstance(value, str) and value:
                other_products_conditions.append((F.col(product) == value))
            elif isinstance(value, list) and value:
                other_products_conditions.append(F.col(product).isin(value))
        
        all_product_conditions = brand_condition + sub_brands_condition + other_products_conditions

        if not all_product_conditions:
            return

        self.df = self.df.filter(reduce(and_, all_product_conditions))

# Partition mixin
class CountryPartitionMixin(object):
    def filter_by_country(self, country_id: List[int], country_name: List[str]):
        self.df = self.df.filter(F.col(BQColumns.country_id).isin(country_id) & F.col(BQColumns.country).isin(country_name))

    def filter_by_legc(self, legc: List[str], country_name: List[str]):
        self.df = self.df.filter(F.col(BQColumns.legc).isin(legc) & F.col(BQColumns.country).isin(country_name))

class CMUPartitionMixin(object):
    def filter_by_cmu(self, cmu_id):
        self.df = self.df.filter(F.col(BQColumns.partition_id) == cmu_id)

# Datasource base classes
class DataSource(object):
    ARCHETYPE = None
    VIEW = None
    ID = None

    def __init__(
        self,
        spark: pyspark.sql.SparkSession,
        view_name: str=None,
        **kwargs
    ):
        self.view_name = self.VIEW or view_name
        # Always read data from the prod project
        self.qualified_name = f"consumer-data-hub.{BQ_DATASET}.{self.view_name}"

        self.spark = spark
        self.logger = getLogger(self.__class__.__name__)

        self.logger.info(f"Attempting to read from {self.qualified_name}")
        self.df = self.spark.read.format("bigquery").option(
                "project", "consumer-data-hub"
            ).option(
                "parentProject", "consumer-data-hub"
            ).option(
                "credentials", access_secret_version(project_id=PROJECT_ID, secret_id=BQ_CREDS_SECRET)
            ).option(
                "materializationDataset", "CDH_SparkTemp"
            ).option(
                "viewsEnabled", "true"
            ).load(self.qualified_name)
        
        self.rows = -1
    
    def count(self):
        self.rows = self.df.count()
        return self.rows
    
    def persist(self):
        self.df.persist()
    
    def unpersist(self, blocking=True):
        self.df.unpersist(True)

    @property
    def columns(self):
        return self.df.columns

    @property
    def schema(self):
        return self.df.schema

class PlatformDataSource(DataSource):
    IS_PLATFORM = True

class BYOODDataSource(DataSource):
    IS_PLATFORM = False

# Generic classes
class PlatformMediaDataSource(CountryPartitionMixin, PeriodFiltersMixin, RegionFiltersMixin, ProductFiltersMixin, PlatformDataSource):
    ARCHETYPE = Archetype.MEDIA

    def __init__(self, spark: pyspark.sql.SparkSession, view_name: str=None, **kwargs) -> None:
        super().__init__(spark, view_name, **kwargs)
        self.filter_by_country(COUNTRY_ID, COUNTRY_NAME)

class PlatformMacroEconomicDataSource(CountryPartitionMixin, PeriodFiltersMixin, RegionFiltersMixin, PlatformDataSource):
    ARCHETYPE = Archetype.MACRO

    def __init__(self, spark: pyspark.sql.SparkSession, view_name: str=None, **kwargs) -> None:
        super().__init__(spark, view_name, **kwargs)
        self.filter_by_country(COUNTRY_ID, COUNTRY_NAME)

class PlatformSalesDataSource(CountryPartitionMixin, PeriodFiltersMixin, RegionFiltersMixin, ProductFiltersMixin, PlatformDataSource):
    ARCHETYPE = Archetype.SALES

    def __init__(self, spark: pyspark.sql.SparkSession, view_name: str=None, **kwargs) -> None:
        super().__init__(spark, view_name, **kwargs)
        self.filter_by_country(COUNTRY_ID, COUNTRY_NAME)

    def get_competitor_data(self, competitor_for: List[str]):
        return self.df.filter(F.col(BQColumns.competitor_for).isin(competitor_for))

class PlatformCategoryDataSource(CMUPartitionMixin, PeriodFiltersMixin, RegionFiltersMixin, ProductFiltersMixin, PlatformDataSource):
    ARCHETYPE = Archetype.CATEGORY

    def get_competitor_data(self):
        return self.df.filter(F.col(BQColumns.competitor) == True)

class BYODMediaDataSource(CountryPartitionMixin, PeriodFiltersMixin, RegionFiltersMixin, ProductFiltersMixin, BYOODDataSource):
    ARCHETYPE = Archetype.MEDIA
    VIEW = "LOCAL_MEDIA_MEASURES"

    def __init__(self, spark: pyspark.sql.SparkSession, source: str, **kwargs) -> None:
        super().__init__(spark, **kwargs)
        self.filter_by_legc(LEGC, COUNTRY_NAME)
        self.df = self.df.filter(F.col(BQColumns.source) == source)

    def get_competitor_data(self, competitor_for: List[str]):
        return self.df.filter(F.col(BQColumns.competitor_for).isin(competitor_for))

class BYODMacroEconomicDataSource(CountryPartitionMixin, PeriodFiltersMixin, RegionFiltersMixin, BYOODDataSource):
    ARCHETYPE = Archetype.MACRO
    VIEW = "LOCAL_MACRO_MEASURES"

    def __init__(self, spark: pyspark.sql.SparkSession, source: str, **kwargs) -> None:
        super().__init__(spark, **kwargs)
        self.filter_by_legc(LEGC, COUNTRY_NAME)
        self.df = self.df.filter(F.col(BQColumns.source) == source)

class BYODSalesDataSource(CountryPartitionMixin, PeriodFiltersMixin, RegionFiltersMixin, ProductFiltersMixin, BYOODDataSource):
    ARCHETYPE = Archetype.SALES
    VIEW = "LOCAL_SALES_MEASURES"

    def __init__(self, spark: pyspark.sql.SparkSession, source: str, **kwargs) -> None:
        super().__init__(spark, **kwargs)
        self.filter_by_legc(LEGC, COUNTRY_NAME)
        self.df = self.df.filter(F.col(BQColumns.source) == source)

    def get_competitor_data(self, competitor_for: List[str]):
        return self.df.filter(F.col(BQColumns.competitor_for).isin(competitor_for))

class BYODCategoryDataSource(CMUPartitionMixin, PeriodFiltersMixin, RegionFiltersMixin, ProductFiltersMixin, BYOODDataSource):
    ARCHETYPE = Archetype.CATEGORY

    def __init__(self, spark: pyspark.sql.SparkSession, partition_id: int, **kwargs) -> None:
        super().__init__(spark, **kwargs)
        self.filter_by_cmu(partition_id)

    def get_competitor_data(self):
        return self.df.filter(F.col(BQColumns.competitor) == True)

# Specific concrete classes
class PlatformNielsen(PlatformCategoryDataSource):
    ID = "NIELSEN"
    # VIEW = "LOCALNIELSEN"

    def __init__(self, spark: pyspark.sql.SparkSession, **kwargs):
        self.country = kwargs['country']
        self.category = kwargs['category']
        self.periodicity = kwargs['periodicity']
        super().__init__(spark, view_name=self._get_view_name())

    def _get_view_name(self):
        return f'LOCALNIELSEN_{self.country.upper()}_{self.category.upper()}_{self.periodicity.upper()}'

class BYODNielsen(BYODCategoryDataSource):
    ID = "NIELSEN"
    VIEW = "LOCAL_NIELSEN_MEASURES"

# Factory base class
class DataSourceFactory(object):
    IS_PLATFORM = None
    ARCHETYPE = None

    def __init__(self, spark: pyspark.sql.SparkSession) -> None:
        self.spark = spark

    def get_datasource(self, datasource_id: str, **kwargs):
        ...

class PlatformDataSourceFactory(DataSourceFactory):
    IS_PLATFORM = True

class BYODDataSourceFactory(DataSourceFactory):
    IS_PLATFORM = False

# Platform Factories
class PlatformMediaFactory(PlatformDataSourceFactory):
    ARCHETYPE = Archetype.MEDIA
    
    def get_datasource(self, datasource_id: str, **kwargs):
        datasource_cls = PlatformMediaDataSource

        # Override with a specific implementation if found
        datasources = [cls for cls in PlatformMediaDataSource.__subclasses__() if datasource_id == cls.ID]
        if datasources:
            datasource_cls = datasources[0]

        return datasource_cls(self.spark, view_name=datasource_id)

class PlatformMacroEconomicFactory(PlatformDataSourceFactory):
    ARCHETYPE = Archetype.MACRO
    
    def get_datasource(self, datasource_id: str, **kwargs):
        datasource_cls = PlatformMacroEconomicDataSource

        # Override with a specific implementation if found
        datasources = [cls for cls in PlatformMacroEconomicDataSource.__subclasses__() if datasource_id == cls.ID]
        if datasources:
            datasource_cls = datasources[0]

        return datasource_cls(self.spark, view_name=datasource_id)

class PlatformSalesFactory(PlatformDataSourceFactory):
    ARCHETYPE = Archetype.SALES

    def get_datasource(self, datasource_id: str, **kwargs):
        datasource_cls = PlatformSalesDataSource

        # Override with a specific implementation if found
        datasources = [cls for cls in PlatformSalesDataSource.__subclasses__() if datasource_id == cls.ID]
        if datasources:
            datasource_cls = datasources[0]

        return datasource_cls(self.spark, view_name=datasource_id)

class PlatformCategoryFactory(PlatformDataSourceFactory):
    ARCHETYPE = Archetype.CATEGORY
    
    def get_datasource(self, datasource_id: str, **kwargs):
        datasource_cls = PlatformCategoryDataSource

        # Override with a specific implementation if found
        datasources = [cls for cls in PlatformCategoryDataSource.__subclasses__() if datasource_id == cls.ID]
        if datasources:
            datasource_cls = datasources[0]

        return datasource_cls(self.spark, view_name=datasource_id, **kwargs)

# BYOD Factories
class BYODMediaFactory(BYODDataSourceFactory):
    ARCHETYPE = Archetype.MEDIA
    
    def get_datasource(self, datasource_id: str, **kwargs):
        datasource_cls = BYODMediaDataSource

        # Override with a specific implementation if found
        datasources = [cls for cls in BYODMediaDataSource.__subclasses__() if datasource_id == cls.ID]
        if datasources:
            datasource_cls = datasources[0]

        return datasource_cls(self.spark, source=datasource_id)

class BYODMacroEconomicFactory(BYODDataSourceFactory):
    ARCHETYPE = Archetype.MACRO
    
    def get_datasource(self, datasource_id: str, **kwargs):
        datasource_cls = BYODMacroEconomicDataSource

        # Override with a specific implementation if found
        datasources = [cls for cls in BYODMacroEconomicDataSource.__subclasses__() if datasource_id == cls.ID]
        if datasources:
            datasource_cls = datasources[0]

        return datasource_cls(self.spark, source=datasource_id)

class BYODSalesFactory(BYODDataSourceFactory):
    ARCHETYPE = Archetype.SALES
    
    def get_datasource(self, datasource_id: str, **kwargs):
        datasource_cls = BYODSalesDataSource

        # Override with a specific implementation if found
        datasources = [cls for cls in BYODSalesDataSource.__subclasses__() if datasource_id == cls.ID]
        if datasources:
            datasource_cls = datasources[0]

        return datasource_cls(self.spark, source=datasource_id)

class BYODCategoryFactory(BYODDataSourceFactory):
    ARCHETYPE = Archetype.CATEGORY

    def get_datasource(self, datasource_id: str, **kwargs):
        datasource_cls = BYODCategoryDataSource

        # Override with a specific implementation if found
        datasources = [cls for cls in BYODCategoryDataSource.__subclasses__() if datasource_id == cls.ID]
        if datasources:
            datasource_cls = datasources[0]

        return datasource_cls(self.spark, view_name=datasource_id, **kwargs)

# Single builder class to instantiate any datasource
class DataSources(object):
    def __init__(self, spark: pyspark.sql.SparkSession, **kwargs) -> None:
        self.spark = spark

    def get_datasource(self, datasource_id: str, archetype: str, is_platform: bool=True, **kwargs):
        factory_cls = None
        if is_platform:
            factory_cls = [cls for cls in PlatformDataSourceFactory.__subclasses__() if cls.ARCHETYPE == archetype][0]
        else:
            factory_cls = [cls for cls in BYODDataSourceFactory.__subclasses__() if cls.ARCHETYPE == archetype][0]

        factory = factory_cls(self.spark)
        return factory.get_datasource(datasource_id, **kwargs)
