import datetime as dt
import copy
from itertools import chain
from typing import Union, List

import pyspark
from pyspark.sql import functions as F, Window

from mroi.datasources.data_models import (
    DataSources, 
    PlatformCategoryDataSource, PlatformSalesDataSource, PlatformMediaDataSource, PlatformMacroEconomicDataSource,
    BYODCategoryDataSource, BYODSalesDataSource, BYODMediaDataSource, BYODMacroEconomicDataSource,
    BQColumns, Archetype
)
from mroi.datasources.exceptions import KPINotAvailableError
from mroi.data_models.inputs import MROIColumns
from mroi.logging import getLogger
from mroi.config import ModelControl

class DataSourceConfigMixin(object):
    
    def datasource_id(self, datasource_config: dict):
        return datasource_config["pipeline_dataset_id"]

    def is_competitor(self, datasource_config: dict):
        datasource_id = self.datasource_id(datasource_config)
        return datasource_config.get("competitor", False) or "COMPETITOR" in datasource_id or datasource_id in ("NIELSEN_COMP", "TV_COMP")

    def is_platform(self, datasource_config: dict):
        return datasource_config.get("source", "PLATFORM").upper() == "PLATFORM"

    def archetype(self, datasource_config: dict):
        return datasource_config["type"].upper()

    def is_campaign(self, datasource_config: dict):
        return "campaign" in datasource_config.get("channel_granularity", "channel")
    
    def kpis(self, datasource_config: dict):
        return set(datasource_config["kpi_list"])

    def skus(self, datasource_config: dict):
        skus = []
        try:
            if datasource_config.get("sku", [])[0] == "ALL":
                skus = []
            else:
               skus = datasource_config.get("sku")
        except IndexError:
            skus = []
        
        return skus

class ModelTransformer(DataSourceConfigMixin, object):
    ID = None
    MIN_MEASURES = {BQColumns.minimum_temperature_celsius}
    MAX_MEASURES = {BQColumns.distribution, 
        BQColumns.acv_distribution, BQColumns.weighted_distribution, BQColumns.numeric_distribution,
        BQColumns.num_stores,
        BQColumns.population, BQColumns.maximum_temperature_celsius}
    AVG_MEASURES = {BQColumns.average_price,
        BQColumns.price_per_unit_promo, BQColumns.price_per_unit_regular,
        BQColumns.price_per_volume_promo, BQColumns.price_per_volume_regular,
        BQColumns.mobility_grocery_and_pharmacy, BQColumns.mobility_retail_and_recreation,
        BQColumns.gdp_per_capita_usd,
        BQColumns.human_capital_index,
        BQColumns.population_density, BQColumns.human_development_index,
        BQColumns.comorbidity_mortality_rate,
        BQColumns.average_temperature_celsius,
        BQColumns.relative_humidity}
    COUNT_DISTINCT_MEASURES = {BQColumns.pos_store_sk}
    
    def __init__(self, spark: pyspark.sql.SparkSession, global_config: dict, model_config: dict):
        self.spark = spark
        self.logger = getLogger(self.__class__.__name__)

        self.global_config = copy.deepcopy(global_config)
        self.model_config = copy.deepcopy(model_config)
        
        self.periodicity = ModelControl.get_periodicity(self.model_config['id'])
        self.week_start_day = ModelControl.get_week_start_day(self.model_config['id'])

        # Override these in the child class
        self.is_regional = True
        self.include = True
        self.regions = []

        self.brand = self.global_config["brand"]
        self.sub_brand = self.global_config["sub_brand"] if "ALL" not in self.global_config["sub_brand"] else []
        self.segment = self.global_config["segment"] if "ALL" not in self.global_config["segment"] else []
        self.sub_segment = self.global_config["sub_segment"] if "ALL" not in self.global_config["sub_segment"] else []

        # Override start_date & end_date if it doesn't meet minimum data point requirements
        min_weeks = 24 if self.periodicity == "WEEKLY" else 105
        self.start_date, self.end_date = (dt.date.today() - dt.timedelta(weeks=min_weeks)), dt.date.today()
        if self.global_config["historic_week_data"] != 0:
            self.start_date = min(self.end_date - dt.timedelta(weeks=self.global_config["historic_week_data"]), self.start_date)
        else:
            self.start_date, self.end_date = min(dt.datetime.strptime(self.global_config["start_date"], "%Y-%m-%d").date(), (dt.datetime.strptime(self.global_config["end_date"], "%Y-%m-%d") - dt.timedelta(weeks=min_weeks)).date()), dt.datetime.strptime(self.global_config["end_date"], "%Y-%m-%d").date()
        
        if self.periodicity == "MONTHLY":
            self.start_date = dt.datetime.strptime(self.start_date.strftime("%Y-%m-01"), "%Y-%m-%d").date()

    def fetch_data(self, datasource_config: dict):
        # datasource keys
        is_platform = self.is_platform(datasource_config)
        archetype = self.archetype(datasource_config)
        datasource_id = self.datasource_id(datasource_config).split("_COMP")[0]
        
        is_competitor = self.is_competitor(datasource_config)
        
        # Get an instance of the concrete datasource
        datasources = DataSources(self.spark)
        if archetype == Archetype.CATEGORY:
            category = datasource_config.get("category")
            if "NIELSEN" in datasource_id:
                datasource = datasources.get_datasource(
                    "NIELSEN",
                    archetype,
                    is_platform=is_platform,
                    country=datasource_config["nielsen_view"]["country"],
                    category=datasource_config["nielsen_view"]["category"],
                    periodicity=datasource_config["nielsen_view"]["periodicity"],
                    partition_id=datasource_config["nielsen_view"].get("partition_id")
                )
            else:
                datasource = datasources.get_datasource(
                    datasource_id,
                    archetype,
                    is_platform=is_platform,
                    category=category
                )
        else:
            datasource = datasources.get_datasource(
                    datasource_id,
                    archetype,
                    is_platform=is_platform
                )
        if is_competitor:
            if archetype == Archetype.CATEGORY:
                datasource.df = datasource.get_competitor_data()
            else:
                datasource.df = datasource.get_competitor_data(competitor_for=self.brand)
        return datasource

    def apply_period_filters(self, datasource: Union[PlatformCategoryDataSource, PlatformSalesDataSource, PlatformMediaDataSource, PlatformMacroEconomicDataSource,
    BYODCategoryDataSource, BYODSalesDataSource, BYODMediaDataSource, BYODMacroEconomicDataSource], datasource_config: dict=None, start_date: dt.date = None, end_date: dt.date = None):
        start_date = start_date or self.start_date
        end_date = end_date or self.end_date
        datasource.apply_period_filters(start_date, end_date)

    def apply_region_filters(self, datasource: Union[PlatformCategoryDataSource, PlatformSalesDataSource, PlatformMediaDataSource, PlatformMacroEconomicDataSource,
    BYODCategoryDataSource, BYODSalesDataSource, BYODMediaDataSource, BYODMacroEconomicDataSource], datasource_config: dict=None, regions: List[str]=None):
        if not self.is_regional and datasource.ID == "NIELSEN" and datasource.IS_PLATFORM:
            regions = ["NATIONAL"]
        datasource.apply_region_filters(regions or self.regions, include=self.include)

    def apply_product_filters(self, datasource: Union[PlatformCategoryDataSource, PlatformSalesDataSource, PlatformMediaDataSource, PlatformMacroEconomicDataSource,
    BYODCategoryDataSource, BYODSalesDataSource, BYODMediaDataSource, BYODMacroEconomicDataSource], datasource_config: dict=None):
        if datasource.ARCHETYPE == Archetype.MACRO:
            return
        sku = self.skus(datasource_config)
        product_attributes = {
            BQColumns.brand: self.brand,
            BQColumns.sub_brand: self.sub_brand,
            BQColumns.segment: self.segment,
            BQColumns.sub_segment: self.sub_segment,
            BQColumns.sku: sku
        }

        datasource.apply_product_filters(**product_attributes)

    def standardize_period(self, datasource: Union[PlatformCategoryDataSource, PlatformSalesDataSource, PlatformMediaDataSource, PlatformMacroEconomicDataSource,
    BYODCategoryDataSource, BYODSalesDataSource, BYODMediaDataSource, BYODMacroEconomicDataSource]):
        if self.periodicity == "WEEKLY":
            datasource.df = datasource.df.withColumn('Week_id', F.date_sub(F.next_day(BQColumns.date, f"{self.week_start_day.lower()}"), 7))
        else:
            datasource.df = datasource.df.withColumn('Week_id', F.trunc(BQColumns.date, "month"))

    def standardize_product(self, datasource: Union[PlatformCategoryDataSource, PlatformSalesDataSource, PlatformMediaDataSource, PlatformMacroEconomicDataSource,
    BYODCategoryDataSource, BYODSalesDataSource, BYODMediaDataSource, BYODMacroEconomicDataSource], datasource_config: dict=None):
        if datasource.ARCHETYPE == Archetype.MACRO:
            return
        for product_col in (BQColumns.brand, BQColumns.sub_brand, BQColumns.segment, BQColumns.sub_segment):
            datasource.df = datasource.df.withColumn(product_col, F.lit("PRODUCT"))

    def standardize_region(self, datasource: Union[PlatformCategoryDataSource, PlatformSalesDataSource, PlatformMediaDataSource, PlatformMacroEconomicDataSource,
    BYODCategoryDataSource, BYODSalesDataSource, BYODMediaDataSource, BYODMacroEconomicDataSource], datasource_config: dict=None):
        if not self.is_regional:
            datasource.df = datasource.df.withColumn("region", F.lit("national"))
    
    def aggregate_by_region(self, datasource: Union[PlatformCategoryDataSource, PlatformSalesDataSource, PlatformMediaDataSource, PlatformMacroEconomicDataSource, BYODCategoryDataSource, BYODSalesDataSource, BYODMediaDataSource, BYODMacroEconomicDataSource], datasource_config: dict):
        is_platform = self.is_platform(datasource_config)
        datasource_id = self.datasource_id(datasource_config)
        is_competitor = self.is_competitor(datasource_config)
        is_campaign = self.is_campaign(datasource_config)
        kpis = self.kpis(datasource_config)

        # For RBT/SU add num_stores if the kpi is available in the data
        if self.ID in ("REGRESSION_BUDGET", "SALES_UPLIFT") and datasource.ARCHETYPE in (Archetype.SALES, Archetype.CATEGORY) and BQColumns.num_stores in datasource.columns:
            kpis.add(BQColumns.num_stores)

        # For AUTOML/AUTOML_BUDGET we need to make sure average_price is added
        if self.ID in ("AUTOML", "AUTOML_BUDGET") and datasource.ARCHETYPE in (Archetype.SALES, Archetype.CATEGORY):
            kpis.add(BQColumns.average_price)

        # Add KPIs required to derive the price KPIs
        if BQColumns.average_price in kpis:
            kpis.remove(BQColumns.average_price)
            kpis.add(BQColumns.sales_value)
            if not (BQColumns.sales_units in kpis or BQColumns.sales_volume in kpis):
                if BQColumns.sales_units in datasource.columns:
                    kpis.add(BQColumns.sales_units)
                elif BQColumns.sales_volume in datasource.columns:
                    kpis.add(BQColumns.sales_volume)
                else:
                    raise KPINotAvailableError(f"Could not find both {BQColumns.sales_units} and {BQColumns.sales_volume} in the datasource. One of {BQColumns.sales_units} or {BQColumns.sales_volume} should be available to calculate {BQColumns.average_price}")
        
        promo_regular_error_template = "Could not find both {} and {} in the datasource. Both should be available to calculate {}"
        if BQColumns.price_per_unit_promo in kpis:
            kpis.remove(BQColumns.price_per_unit_promo)
            kpis.update({BQColumns.sales_value_promo, BQColumns.sales_units_promo})
            if not (BQColumns.sales_value_promo in datasource.columns and BQColumns.sales_units_promo in datasource.columns):
                raise KPINotAvailableError(promo_regular_error_template.format(BQColumns.sales_value_promo, BQColumns.sales_units_promo, BQColumns.price_per_unit_promo))
        if BQColumns.price_per_volume_promo in kpis:
            kpis.remove(BQColumns.price_per_volume_promo)
            kpis.update({BQColumns.sales_value_promo, BQColumns.sales_volume_promo})
            if not (BQColumns.sales_value_promo in datasource.columns and BQColumns.sales_volume_promo in datasource.columns):
                raise KPINotAvailableError(promo_regular_error_template.format(BQColumns.sales_value_promo, BQColumns.sales_volume_promo, BQColumns.price_per_volume_promo))
        
        if BQColumns.price_per_unit_regular in kpis:
            kpis.remove(BQColumns.price_per_unit_regular)
            kpis.update({BQColumns.sales_value_regular, BQColumns.sales_units_regular})
            if not (BQColumns.sales_value_regular in datasource.columns and BQColumns.sales_units_regular in datasource.columns):
                raise KPINotAvailableError(promo_regular_error_template.format(BQColumns.sales_value_regular, BQColumns.sales_units_regular, BQColumns.price_per_unit_regular))
        if BQColumns.price_per_volume_regular in kpis:
            kpis.remove(BQColumns.price_per_volume_regular)
            kpis.update({BQColumns.sales_value_regular, BQColumns.sales_volume_regular})
            if not (BQColumns.sales_value_regular in datasource.columns and BQColumns.sales_volume_regular in datasource.columns):
                raise KPINotAvailableError(promo_regular_error_template.format(BQColumns.sales_value_regular, BQColumns.sales_volume_regular, BQColumns.price_per_volume_regular))

        product_columns = [BQColumns.brand, BQColumns.sub_brand, BQColumns.segment, BQColumns.sub_segment]
        if is_campaign:
            product_columns.append(BQColumns.campaign_id)
        
        aggregation_columns = [MROIColumns.date, MROIColumns.region]
        if datasource.ARCHETYPE != Archetype.MACRO:
            aggregation_columns += product_columns
        
        # Customize the aggregation logic for POS
        if is_platform and datasource_id == "POS" and not is_competitor:
            aggregated_df = datasource.df.groupby(aggregation_columns).agg(
                F.sum(BQColumns.sales_units).alias(BQColumns.sales_units),
                F.sum(F.when(F.col(BQColumns.sales_value) > 0, F.col(BQColumns.sales_units)).otherwise(F.lit(0))).alias("non_zero_sales_units"),
                F.sum(F.when(F.col(BQColumns.sales_value) > 0, F.col(BQColumns.sales_value)).otherwise(F.lit(0))).alias("non_zero_sales_value"),
                F.countDistinct(F.when(F.col(BQColumns.sales_units) > 0, F.col(BQColumns.pos_store_sk)).otherwise(F.lit(0))).alias(BQColumns.num_stores)
            ).withColumn(
                BQColumns.distribution, F.col(BQColumns.num_stores)
            ).withColumn(
                BQColumns.average_price, F.col("non_zero_sales_value") / F.col("non_zero_sales_units")
            ).withColumn(
                BQColumns.sales_value, F.col(BQColumns.average_price) * F.col(BQColumns.sales_units)
            )
            
            aggregated_df = aggregated_df.select(aggregation_columns + list(kpis))
        else:
            kpis_min = set([kpi for kpi in kpis if kpi in self.MIN_MEASURES])
            kpis_max = set([kpi for kpi in kpis if kpi in self.MAX_MEASURES])
            kpis_avg = set([kpi for kpi in kpis if kpi in self.AVG_MEASURES])
            kpis_count_distinct = set([kpi for kpi in kpis if kpi in self.COUNT_DISTINCT_MEASURES])
            kpis_sum = kpis - kpis_max - kpis_min - kpis_avg - kpis_count_distinct
            kpis_exprs = [F.sum(kpi).alias(kpi) for kpi in kpis_sum] + \
                [F.min(kpi).alias(kpi) for kpi in kpis_min] + \
                [F.max(kpi).alias(kpi) for kpi in kpis_max] + \
                [F.avg(kpi).alias(kpi) for kpi in kpis_avg] + \
                [F.countDistinct(kpi).alias(kpi) for kpi in kpis_count_distinct]
            aggregated_df = datasource.df.groupby(aggregation_columns).agg(*kpis_exprs)
        
        return aggregated_df

class AutoMLModelTransformer(ModelTransformer):
    ID = "AUTOML"

    def __init__(self, spark: pyspark.sql.SparkSession, global_config: dict, model_config: dict):
        super().__init__(spark, global_config, model_config)

        self.derive_halo = bool(self.segment)
        
        self.is_regional = self.model_config['config']['region_granularity']['type'].upper() == 'REGIONAL'
        if self.is_regional:
            test_regions = list(chain(*(cell['regions'] for cell in self.model_config['config']['region_granularity']['test_control_regions']['test'].values())))
            control_regions = list(chain(*(cell['regions'] for cell in self.model_config['config']['region_granularity']['test_control_regions']['control'].values())))
            self.regions = test_regions + control_regions
    
    def apply_period_filters(self, datasource: Union[PlatformCategoryDataSource, PlatformSalesDataSource, PlatformMediaDataSource, PlatformMacroEconomicDataSource,
    BYODCategoryDataSource, BYODSalesDataSource, BYODMediaDataSource, BYODMacroEconomicDataSource], datasource_config: dict=None, start_date: dt.date = None, end_date: dt.date = None):
        start_date = start_date or self.start_date
        end_date = end_date or self.end_date
        if datasource.ARCHETYPE in (Archetype.SALES, Archetype.CATEGORY):
            # For sales source get last 3 years of data so that we can detect seasonality in data science codes
            start_date = end_date - dt.timedelta(weeks=156)
        datasource.apply_period_filters(start_date, end_date)

    def apply_product_filters(self, datasource: Union[PlatformCategoryDataSource, PlatformSalesDataSource, PlatformMediaDataSource, PlatformMacroEconomicDataSource,
    BYODCategoryDataSource, BYODSalesDataSource, BYODMediaDataSource, BYODMacroEconomicDataSource], datasource_config: dict=None):
        if datasource.ARCHETYPE == Archetype.MACRO:
            return
        
        sku = self.skus(datasource_config)
        product_attributes = {
            BQColumns.brand: self.brand,
            BQColumns.sub_brand: self.sub_brand,
            BQColumns.segment: self.segment,
            BQColumns.sub_segment: self.sub_segment,
            BQColumns.sku: sku
        }
        if self.is_competitor(datasource_config):
            # Only apply segment & sub_segment filters
            product_attributes.update({BQColumns.brand: None, BQColumns.sub_brand: [], BQColumns.sku: []})
        elif datasource.ARCHETYPE == Archetype.MEDIA and self.derive_halo:
            # If segment is selected, then only apply brand, sub_brand & sub_segment filters, we need data for all segments to derive halo KPIs
            product_attributes.update({BQColumns.segment: []})

        datasource.apply_product_filters(**product_attributes)
        
    def standardize_product(self, datasource: Union[PlatformCategoryDataSource, PlatformSalesDataSource, PlatformMediaDataSource, PlatformMacroEconomicDataSource, BYODCategoryDataSource, BYODSalesDataSource, BYODMediaDataSource, BYODMacroEconomicDataSource], 
        datasource_config: dict = None):
        if datasource.ARCHETYPE == Archetype.MACRO:
            return

        is_campaign = self.is_campaign(datasource_config)

        # Standardize brand
        if self.brand and BQColumns.brand in datasource.columns:
            # Only standardize the brand selected, other brands should be untouched for competition
            datasource.df = datasource.df.withColumn(BQColumns.brand, F.when(F.col(BQColumns.brand).like(f"%{self.brand}%"), F.lit("PRODUCT")).otherwise(F.col(BQColumns.brand)))
        
        # Standardize sub_brand
        datasource.df = datasource.df.withColumn(BQColumns.sub_brand, F.lit('PRODUCT'))
        
        # Standardize segment
        if self.segment:
            if BQColumns.segment in datasource.columns:
                # Only standardize the segments selected, other segments should be untouched for halo
                datasource.df = datasource.df.withColumn(BQColumns.segment, F.when(F.col(BQColumns.segment).isin(self.segment), F.lit("PRODUCT")).otherwise(F.col(BQColumns.segment)))
        else:
            datasource.df = datasource.df.withColumn(BQColumns.segment, F.lit('PRODUCT'))

        # Standardize sub_segment
        datasource.df = datasource.df.withColumn(BQColumns.sub_segment, F.lit('PRODUCT'))

        # Standardize campaign
        if is_campaign:
            campaigns = [campaign["campaignid"] for campaign in datasource_config["target_campaigns"]]
            datasource.df = datasource.df.withColumn(BQColumns.campaign_id, F.when(~F.col(BQColumns.campaign_id).isin(campaigns), F.lit("non-target")).otherwise(F.col(BQColumns.campaign_id)))
        
    def standardize_region(self, datasource: Union[PlatformCategoryDataSource, PlatformSalesDataSource, PlatformMediaDataSource, PlatformMacroEconomicDataSource, BYODCategoryDataSource, BYODSalesDataSource, BYODMediaDataSource, BYODMacroEconomicDataSource], datasource_config: dict = None):
        if self.is_regional:
            test_control_mapping = {f'test_{cell}': config['regions'] for cell, config in self.model_config['config']['region_granularity']['test_control_regions']['test'].items()}
            test_control_mapping.update({f'control_{cell}': config['regions'] for cell, config in self.model_config['config']['region_granularity']['test_control_regions']['control'].items()})
            when_conditions = [F.when(F.col(BQColumns.region).isin(regions), F.lit(conv_region)) for conv_region, regions in test_control_mapping.items()]
            datasource.df = datasource.df.withColumn(MROIColumns.region, F.coalesce(*when_conditions))
        else:
            datasource.df = datasource.df.withColumn(MROIColumns.region, F.lit("national"))
    
    def aggregate_by_cell(self, datasource: Union[PlatformCategoryDataSource, PlatformSalesDataSource, PlatformMediaDataSource, PlatformMacroEconomicDataSource, BYODCategoryDataSource, BYODSalesDataSource, BYODMediaDataSource, BYODMacroEconomicDataSource], datasource_config: dict):
        is_campaign = self.is_campaign(datasource_config)

        product_columns = [BQColumns.brand, BQColumns.sub_brand, BQColumns.segment, BQColumns.sub_segment]
        if is_campaign:
            product_columns.append(BQColumns.campaign_id)
        
        aggregation_columns = [MROIColumns.date, MROIColumns.region]
        if datasource.ARCHETYPE != Archetype.MACRO:
            aggregation_columns += product_columns

        if datasource.ARCHETYPE in (Archetype.SALES, Archetype.CATEGORY):
            distribution_measures = {BQColumns.distribution, BQColumns.acv_distribution, BQColumns.weighted_distribution, BQColumns.numeric_distribution}
            total_sales = datasource.df.groupby(aggregation_columns).agg(F.sum(BQColumns.sales_value).alias(BQColumns.sales_value))
            datasource.df = datasource.df.join(total_sales, on=aggregation_columns).select(datasource.df['*'], (datasource.df[BQColumns.sales_value] / total_sales[BQColumns.sales_value]).alias("weight"))

            kpis = set([col for col in datasource.columns if col not in aggregation_columns])
            kpis_avg = set([kpi for kpi in kpis if kpi in self.AVG_MEASURES])
            kpis_weighted_average = set([kpi for kpi in kpis if kpi in distribution_measures])
            kpis_sum = kpis - kpis_avg - kpis_weighted_average

            kpis_exprs = [F.sum(kpi).alias(kpi) for kpi in kpis_sum] + [F.avg(kpi).alias(kpi) for kpi in kpis_avg] + [F.sum(F.col(kpi) * F.col("weight")).alias(kpi) for kpi in kpis_weighted_average]
        else:
            kpis = set([col for col in datasource.columns if col not in aggregation_columns])
            kpis_min = set([kpi for kpi in kpis if kpi in self.MIN_MEASURES])
            kpis_max = set([kpi for kpi in kpis if kpi in self.MAX_MEASURES])
            kpis_avg = set([kpi for kpi in kpis if kpi in self.AVG_MEASURES])
            kpis_sum = kpis - kpis_max - kpis_min - kpis_avg
            kpis_exprs = [F.sum(kpi).alias(kpi) for kpi in kpis_sum] + \
                [F.min(kpi).alias(kpi) for kpi in kpis_min] + \
                [F.max(kpi).alias(kpi) for kpi in kpis_max] + \
                [F.avg(kpi).alias(kpi) for kpi in kpis_avg]
        
        aggregated_df = datasource.df.groupby(aggregation_columns).agg(*kpis_exprs).drop("weight")

        # Only select the KPIs that we received in the config
        kpis = self.kpis(datasource_config)

        # Calculate price measures after aggregation
        if datasource.ARCHETYPE in (Archetype.SALES, Archetype.CATEGORY):
            
            # Calculate average_price from sales_value & sales_units
            kpi_units = BQColumns.sales_units if BQColumns.sales_units in aggregated_df.columns else BQColumns.sales_volume
            aggregated_df = aggregated_df.withColumn(BQColumns.average_price, F.col(BQColumns.sales_value) / F.col(kpi_units))

            # Calculate promo price
            if BQColumns.price_per_unit_promo in kpis:
                aggregated_df = aggregated_df.withColumn(BQColumns.price_per_unit_promo, F.col(BQColumns.sales_value_promo) / F.col(BQColumns.sales_units_promo))
            if BQColumns.price_per_volume_promo in kpis:
                aggregated_df = aggregated_df.withColumn(BQColumns.price_per_volume_promo, F.col(BQColumns.sales_value_promo) / F.col(BQColumns.sales_volume_promo))
            
            # Calculate regular price
            if BQColumns.price_per_unit_regular in kpis:
                aggregated_df = aggregated_df.withColumn(BQColumns.price_per_unit_regular, F.col(BQColumns.sales_value_regular) / F.col(BQColumns.sales_units_regular))
            if BQColumns.price_per_volume_regular in kpis:
                aggregated_df = aggregated_df.withColumn(BQColumns.price_per_volume_regular, F.col(BQColumns.sales_value_regular) / F.col(BQColumns.sales_volume_regular))
                    
        return aggregated_df.select(*aggregation_columns, *list(kpis))

    def derive_halo_kpis(self, datasource: Union[PlatformCategoryDataSource, PlatformSalesDataSource, PlatformMediaDataSource, PlatformMacroEconomicDataSource, BYODCategoryDataSource, BYODSalesDataSource, BYODMediaDataSource, BYODMacroEconomicDataSource], datasource_config: dict):
        kpis = self.kpis(datasource_config)
        halo_products = datasource.df.filter(F.col(BQColumns.segment) != "PRODUCT")
        exprs = [F.sum(kpi).alias(f"halo_{kpi}") for kpi in kpis]
        
        if len(kpis) == 1:
            halo_products = halo_products.withColumn(BQColumns.segment, F.concat_ws('_', F.col(BQColumns.segment), F.lit(list(kpis)[0])))
        
        halo_products = halo_products.groupby([MROIColumns.date, MROIColumns.region]).pivot(BQColumns.segment).agg(*exprs)

        return halo_products

    def derive_competitor_kpis(self, datasource: Union[PlatformCategoryDataSource, PlatformSalesDataSource, PlatformMediaDataSource, PlatformMacroEconomicDataSource, BYODCategoryDataSource, BYODSalesDataSource, BYODMediaDataSource, BYODMacroEconomicDataSource], datasource_config: dict, limit: int=5):
        kpis = self.kpis(datasource_config)

        if datasource.ARCHETYPE in (Archetype.SALES, Archetype.CATEGORY):
            rank_window_spec = Window.partitionBy([MROIColumns.date, MROIColumns.region]).orderBy(F.desc(BQColumns.sales_value))
        else:
            # Dynamic ordering for Media competition
            orderBy_clause = []
            if BQColumns.viewable_impressions in kpis:
                orderBy_clause.append(F.desc(BQColumns.viewable_impressions))
            elif BQColumns.impressions in kpis:
                orderBy_clause.append(F.desc(BQColumns.impressions))
            elif BQColumns.clicks in kpis:
                orderBy_clause.append(F.desc(BQColumns.clicks))
            if BQColumns.spend in kpis:
                orderBy_clause.append(F.desc(BQColumns.spend))
            rank_window_spec = Window.partitionBy([MROIColumns.date, MROIColumns.region]).orderBy(*orderBy_clause)
        
        top_n_competitors = datasource.df.withColumn("rank", F.row_number().over(rank_window_spec)).filter(F.col('rank') < limit).drop('rank')

        if datasource.ARCHETYPE in (Archetype.SALES, Archetype.CATEGORY):
            kpis.difference_update({BQColumns.sales_value, BQColumns.sales_units, BQColumns.sales_volume,
            BQColumns.sales_value_regular, BQColumns.sales_units_regular, BQColumns.sales_volume_regular})
        
        if len(kpis) == 1:
            top_n_competitors = top_n_competitors.withColumn(BQColumns.brand, F.concat_ws('_', F.col(BQColumns.brand), F.lit(list(kpis)[0])))

        top_n_competitors = top_n_competitors.groupby([MROIColumns.date, MROIColumns.region]).pivot(BQColumns.brand).agg(*[F.sum(kpi).alias(f"competitor_{kpi}") for kpi in kpis])

        return top_n_competitors

class AutoMLBudgetModelTransformer(AutoMLModelTransformer):
    ID = "AUTOML_BUDGET"

class DiffNDiffModelTransformer(ModelTransformer):
    ID = "DIFF&DIFF"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        test_cities_list = list(chain(*(cell['regions'] for cell in self.model_config['config']['region_granularity']['test_control_regions']['test'].values())))
        control_cities_list = list(chain(*(cell['regions'] for cell in self.model_config['config']['region_granularity']['test_control_regions']['control'].values())))
        self.regions = test_cities_list + control_cities_list

class RegressionBudgetModelTransformer(ModelTransformer):
    ID = "REGRESSION_BUDGET"
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        test_cities_list = list(chain(*(cell['regions'] for cell in self.model_config['config']['region_granularity']['test_control_regions']['test'].values())))
        control_cities_list = list(chain(*(cell['regions'] for cell in self.model_config['config']['region_granularity']['test_control_regions']['control'].values())))
        self.regions = test_cities_list + control_cities_list

class SalesUpliftModelTransformer(ModelTransformer):
    ID = "SALES_UPLIFT"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        min_weeks = 24 if self.periodicity == "WEEKLY" else 105
        
        # Find oldest pilot start date
        pilot_start_dates = []
        for test_cell in self.model_config["config"]["region_granularity"]["test_control_regions"]["test"].values():
            pilot_start_dates.append(dt.datetime.strptime(test_cell["test_group_parameters"]["pilot_start"], '%Y-%m-%d'))
        oldest_pilot_start_date = min(pilot_start_dates).date()
        
        self.start_date = min(self.start_date, oldest_pilot_start_date - dt.timedelta(weeks=min_weeks))

        if self.periodicity == "MONTHLY":
            self.start_date = dt.datetime.strptime(self.start_date.strftime("%Y-%m-01"), "%Y-%m-%d").date()

        test_cities_list = list(chain(*(cell['regions'] for cell in self.model_config['config']['region_granularity']['test_control_regions']['test'].values())))
        control_cities_list = list(chain(*(cell['regions'] for cell in self.model_config['config']['region_granularity']['test_control_regions']['control'].values())))
        self.regions = test_cities_list + control_cities_list

class MMTModelTransformer(ModelTransformer):
    ID = "MMT"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.regions = self.model_config["config"]["region_filters"].get("regions", [])
        self.include = self.model_config["config"]["region_filters"].get("regionFilterType", "include") == "include"

    def apply_region_filters(self, datasource: Union[PlatformCategoryDataSource, PlatformSalesDataSource, PlatformMediaDataSource, PlatformMacroEconomicDataSource,
    BYODCategoryDataSource, BYODSalesDataSource, BYODMediaDataSource, BYODMacroEconomicDataSource], datasource_config: dict=None, regions: List[str]=None):
        datasource.apply_region_filters(regions or self.regions, include=self.include)
        datasource.apply_region_filters(['--', 'NATIONAL'], include=False)

class ModelTransformerFactory(object):
    # Since AutoMLBudgetModelTransformer is not a direct subclass of ModelTransformer, add it explicitly
    MAPPING = {**{cls.ID: cls for cls in ModelTransformer.__subclasses__()}, **{AutoMLBudgetModelTransformer.ID: AutoMLBudgetModelTransformer}}
    
    def __init__(self, spark: pyspark.sql.SparkSession, global_config: dict):
        self.spark = spark
        self.global_config = global_config

    def get_model_transformer(self, model_config: dict):
        if model_config["id"] not in self.MAPPING:
            raise ValueError(f'Invalid model id. Found {model_config["id"]}, but expected one of {list(self.MAPPING.keys())}')
        return self.MAPPING[model_config["id"]](self.spark, self.global_config, model_config)
