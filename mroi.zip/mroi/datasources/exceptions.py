class UnexpectedDatasourceError(Exception):
    """Raise when the datasource in the request is not recognized by the Factory class"""

class DataNotFoundError(Exception):
    """Raise when no data is found for a specific data source"""

class KPINotAvailableError(Exception):
    """Raise when a specific KPI is not available in the datasource"""
