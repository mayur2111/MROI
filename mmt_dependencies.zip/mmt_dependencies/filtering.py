"""Executes clustering for different regions on all KPIs provided in input file"""
import re
import traceback
import warnings
from ntpath import basename
from typing import Tuple

import pandas as pd
import numpy as np

from google.cloud import storage

from mmt_dependencies.exceptions import ComparisonFilesLoadError, SalesKPIError
from mroi.utils import gcs_join, GCSUrl
from mroi.logging import getLogger


class FilterMMTData:
    """
    Class to filter for different regions on all KPIs provided in input file

    Args:
        model_intermediate_path (str): intermediate folder path on gcs
        merged_df (pd.DataFrame): combined df containing statistical test info on all region combinations
        kpi_list (list): list of KPIs identified in input file
        model_config (dict): model config dictionary
    """
    def __init__(self, model_intermediate_path: str, merged_df: pd.DataFrame, kpi_list: list, model_config: dict):
        self.logger = getLogger(self.__class__.__name__)

        self.model_intermediate_url = GCSUrl(model_intermediate_path)
        self.cluster_output_path = gcs_join(self.model_intermediate_url.url, "filtered_output_MMT.csv")
        
        self.KPI_list = kpi_list
        self.model_config = model_config
          
        self.stat_measure = self.model_config['statistical_measure'].upper()
        self.KPI_stat = [kpi+f'__{self.stat_measure}' for kpi in self.KPI_list]
        self.KPI_mean = [kpi+f'__MEAN' for kpi in self.KPI_list]
        
        self.correlation_threshold = 0.95
        self.storage_client = storage.Client()
        
        self.sales_kpi = [x for x in self.KPI_list if self.model_config.get('preferred_sales_dataset').lower() in x.lower() and 'sales' in x.lower() and 'promo' not in x.lower()]
        self.sales_kpi_mean = [kpi+f'__MEAN' for kpi in self.sales_kpi]
        self.input_df = merged_df
        self.n_regions = self.input_df.REGION_A.nunique()
        self.distortions = []
   

    def filter_regions_conditions(self, corr_dtw_threshold, corr_diff_threshold):
        """
        Remove regions with low mean(kpi1, kpi2, kpi3....) to bring Region A, Region B pairs to 100,000 or less and also apply statistical test conditions based on number of regions
        
        Args:
            corr_dtw_threshold (float): threshold to use on correlation after DTW
            corr_diff_threshold (float): threshold to use to filter on change in correlation pre DTW and after DTW
        """
        self.filtered_df = self.input_df[~((self.input_df.REGION_A == "NOT AVAILABLE") | (self.input_df.REGION_B == "NOT AVAILABLE"))].copy()
        self.logger.info(f'Filtering regions on Correlation DTW and Correlation difference.')
        self.logger.info(f"Number of regions pairs before filtering: {self.filtered_df.shape[0]}")
        
        exclusion_KPIs = []
        for KPI in self.KPI_list:
            if KPI in self.sales_kpi:
                continue
            if self.filtered_df[self.filtered_df[f"{KPI}__Correlation_dtw"] >= 0.6].shape[0] == 0:
                exclusion_KPIs.append(KPI)
        if len(exclusion_KPIs) > 0:
            self.logger.warn(f"Excluding {exclusion_KPIs} from analysis as Correlation DTW is insignificant for these KPIs.")
            
        self.filtered_df = self.filtered_df.query(' & '.join([f"""`{KPI}__Correlation_dtw` > {corr_dtw_threshold}""" for KPI in self.KPI_list if KPI not in exclusion_KPIs]))
        self.filtered_df = self.filtered_df.query(' & '.join([f"""`{KPI}__Correlation_dtw` - {KPI}__Correlation < {corr_diff_threshold}""" for KPI in self.KPI_list if KPI not in exclusion_KPIs]))
        
        self.logger.info(f"Number of regions pairs after applying filters: {self.filtered_df.shape[0]}")
        
        self.filtered_df = self.filtered_df.reset_index(drop=True)
        return self.filtered_df
        

    def main(self) -> list:
        """
        Orchestrator to filter comparison data 

        Returns:
            list: list of tests to use for filtering based on number of unique regions
        """
        return self.filtered_df