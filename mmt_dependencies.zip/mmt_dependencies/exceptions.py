class InputKPIsError(Exception):
    ...


class InputStatError(Exception):
    ...


class ComparisonFilesLoadError(Exception):
    ...
    

class SalesKPIError(Exception):
    ...

class DataFilterError(Exception):
    ...