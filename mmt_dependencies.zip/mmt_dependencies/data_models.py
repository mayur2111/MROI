class MROIColumns:
    date = "Week_id"
    region = "region"