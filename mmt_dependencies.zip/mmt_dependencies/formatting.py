"""Perform network analysis and pairwise comparison to obtain similar regions"""
import math
import traceback
import io
import shutil
import os
from typing import Tuple, Generator
from copy import deepcopy
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from itertools import combinations, product

from statsmodels.distributions.empirical_distribution import ECDF
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.preprocessing import MinMaxScaler
import igraph as ig
import leidenalg as la

from google.cloud import storage

from mroi.utils import gcs_join, GCSUrl
from mroi.logging import getLogger
from mmt_dependencies.data_models import MROIColumns
from mmt_dependencies.exceptions import SalesKPIError, DataFilterError


class Format:
    """
    Class to perform network analysis and pairwise comparison to obtain similar regions

    Args:
        input_df (pd.DataFrame): input dataframe
        filtered_df (pd.DataFrame): dataframe after filtering on correlation
        kpi_var (list): list of KPIs obtained from input file
        model_intermediate_path (str): intermediate folder path on gcs
        model_output_path (str): output folder path on gcs
        stat_measure (str): statistical measure to use
        sales_kpi (list): list of sales KPI that is used for filtering to identify top sales regions
        model_config (dict): model config provided in the UI for MMT
    """
    def __init__(self, input_df: pd.DataFrame, filtered_df: pd.DataFrame, kpi_var: list, model_intermediate_path: str, model_output_path: str, stat_measure: str, sales_kpi: list, model_config: dict):
        self.logger = getLogger(self.__class__.__name__)
        self.input_df = input_df
        self.KPI = kpi_var
        self.model_intermediate_path = model_intermediate_path
        self.model_output_path = model_output_path
        self.STAT_MEASURE = stat_measure
        self.sales_kpi = sales_kpi
        self.model_config = model_config
        
        self.KPI_stat = [kpi+f'_{self.STAT_MEASURE}' for kpi in self.KPI]
        self.storage_client = storage.Client()
        self.model_output_file_path = gcs_join(model_output_path, 'output_MMT.xlsx')
        self.output_bucket = self.storage_client.bucket(GCSUrl(self.model_output_file_path).bucket)
        
        self.output_df = filtered_df
        #self.output_df = pd.read_csv(gcs_join(model_intermediate_path, 'filtered_output_MMT.csv'))
        #self.corr_df = self.get_all_corr_df(self.output_df)
        self.IDX = ['REGION_A', 'REGION_B']
        self.similar_region_sheets = 5 # constant. nb_dfs    

    def get_all_corr_df(self, df: pd.DataFrame, kpi_suffix: str):
        """
        Generates correlation table between all regions of a community
        
        Args:
            df (pd.DataFrame): filtered output df
            kpi_suffix (str): Correlation or Correlation_dtw
        """
        corr_df = df[['REGION_A', 'REGION_B', f'{self.sales_kpi[0]}__{kpi_suffix}']].copy()
        self_regions = pd.concat([df[['REGION_A']], df[['REGION_B']].rename(columns={'REGION_B':'REGION_A'})]).drop_duplicates()
        self_regions['REGION_B'] = self_regions['REGION_A']
        self_regions[f'{self.sales_kpi[0]}__{kpi_suffix}'] = 1.0
        corr_df = pd.concat([corr_df, self_regions]).reset_index(drop=True)
        return corr_df
    
    def get_cliques(self, df: pd.DataFrame, IDX: list) -> dict:
        """
        Build a graph, extract all cliques from it.

        Args:
            df (pd.DataFrame): input dataframe
            IDX (list): a list of columns names ['REGION_A', 'REGION_B']

        Returns:
            dict: dictionary containing similar regions output for each key from network analysis
        """
        dedup_df = df[~pd.DataFrame(np.sort(df[['REGION_A','REGION_B']], axis=1)).duplicated()].reset_index(drop=True)
        ulim_ptile = (float(self.model_config.get('sales_filter', {}).get('sales_filter_max', 100))/100)
        llim_ptile = (float(self.model_config.get('sales_filter', {}).get('sales_filter_min', 0))/100)
        
        filtered_regions_a = dedup_df[['REGION_A', 'agg_sales_kpi_REGION_A']].rename(columns={'REGION_A': 'REGION', 'agg_sales_kpi_REGION_A': 'agg_sales_kpi'})
        filtered_regions_b = dedup_df[['REGION_B', 'agg_sales_kpi_REGION_B']].rename(columns={'REGION_B': 'REGION', 'agg_sales_kpi_REGION_B': 'agg_sales_kpi'})
        filtered_regions_df = pd.concat([filtered_regions_a, filtered_regions_b]).drop_duplicates().reset_index(drop=True)
        
        ulim_sales = filtered_regions_df['agg_sales_kpi'].quantile(ulim_ptile)
        llim_sales = filtered_regions_df['agg_sales_kpi'].quantile(llim_ptile)
        filter_regions_list = filtered_regions_df[(filtered_regions_df['agg_sales_kpi'] >= llim_sales) & (filtered_regions_df['agg_sales_kpi'] <= ulim_sales)]['REGION'].tolist()
        
        dedup_df = dedup_df[(dedup_df['REGION_A'].isin(filter_regions_list)) & (dedup_df['REGION_B'].isin(filter_regions_list))].reset_index(drop=True)
        
        top_nb_region_pairs = len(dedup_df)
        
        self.logger.info(f"Selected regions between {int(ulim_ptile*100)}% and {int(llim_ptile*100)}%.")
        # Get graph with full data
        self.logger.info(f"Generating graph")
        ig_graph = ig.Graph.TupleList(dedup_df[['REGION_A', 'REGION_B']].itertuples(index=False), weights=False)
        all_nodes = ig_graph.vs()["name"]
        self.logger.info("Obtaining leiden communities from graph")
        leiden_comms = la.find_partition(ig_graph, la.SignificanceVertexPartition, n_iterations=15, seed=1234)
        list_kpi = []
        list_similar_cities = []
        self.logger.info(f'Ignoring communities with less than 2 regions')
        for k, community in enumerate(leiden_comms):
            if len(community)<2:
                continue
            self.logger.info(f'Community {k} has {len(community)} regions')
            
            list_kpi.append(len(community)) 
            list_similar_cities.append([all_nodes[city_idx] for city_idx in community])
        valid_communities = len(list_similar_cities)
        if valid_communities == 0:
            self.logger.info(f'No communities containing atleast 2 similar regions, skipping to next threshold.')
            return {0: pd.DataFrame()}
        else:
            self.logger.info(f'Obtained 5 largest communities containing atleast 2 similar regions')
            nb_dfs = min(self.similar_region_sheets, valid_communities)
        output = self.get_final_output(nb_dfs, list_kpi, list_similar_cities)
        self.logger.info('Finished network comparison successfully.')
        return output
        
    def calc_agg_sales_kpi(self) -> dict:
        """
        Calculate kpi value to sort based on list of KPIs. All KPI values are scaled to 0, 1 range.

        Returns:
            dict: dictionary containing aggregated scaled sales KPIs for each region 
        """
        new_input_df = pd.DataFrame(self.input_df.groupby(MROIColumns.region)[self.sales_kpi].mean())
        # Scale values
        x = new_input_df.values
        standardscaler = MinMaxScaler()
        x_scaled = standardscaler.fit_transform(x)
        new_input_df = pd.DataFrame(x_scaled, columns=new_input_df.columns, index=new_input_df.index)
        # mean across scaled kpis per region
        new_input_df = pd.DataFrame(new_input_df.mean(axis=1))
        new_input_df.reset_index(level=0, inplace=True)
        agg_sales_kpi_dict = dict(zip(new_input_df[MROIColumns.region].str.upper(), new_input_df[0]))
        return agg_sales_kpi_dict

    def calculate_KPI(self, clique: list, kpi_dict: dict) -> float:
        """
        Get aggregate kpi value for each region in clique using kpi_dict.

        Args:
            clique (list): each maximal clique in iteration
            kpi_dict (dict): lookup containing mapping for aggregated scaled kpi and region

        Returns:
            float: average of the aggregated sales KPI for each region in maximum clique
        """
        sort_kpi = np.mean([kpi_dict[region] for region in clique])
        return sort_kpi
    
    def get_final_output(self, nb_dfs: int, list_kpi: list, list_interconnected_regions: list) -> dict:
        """
        Add the required columns to the output from network comparison and return output similar cities dfs with number
        of similar cities dfs

        Args:
            nb_dfs (int): number of similar cities sheets to generate. Max of 3 apart from pairwise
            list_kpi (list): aggregated interconnected regions KPIs for each clique
            list_interconnected_regions (list): list of interconnected region lists

        Returns:
            dict: dictionary containing similar regions output for each key from network analysis
        """
        sort_index_interconnected_regions = np.argsort(list_kpi)[::-1]
        self.logger.info('Identified largest communities consisting of similar regions. Obtaining KPI and statistics information.')
        list_sorted = list(sort_index_interconnected_regions)
        final_list = [list_interconnected_regions[i] for i in list_sorted]
        col_names = ['Regions']
        for kpi in self.KPI:
            col_names = col_names + [f'{kpi}_IQR', f'{kpi}_MAX', f'{kpi}_MIN', f'{kpi}_RANGE', f'{kpi}_MEAN']
        output = {}
        for i in range(0, nb_dfs):
            output[i] = pd.DataFrame(columns=col_names)
            output[i]['Regions'] = final_list[i]
            for kpi in self.KPI:
                iqr_dict = dict(zip(self.output_df['REGION_A'], self.output_df[f'{kpi}__IQR']))
                max_dict = dict(zip(self.output_df['REGION_A'], self.output_df[f'{kpi}__MAX']))
                min_dict = dict(zip(self.output_df['REGION_A'], self.output_df[f'{kpi}__MIN']))
                range_dict = dict(zip(self.output_df['REGION_A'], self.output_df[f'{kpi}__RANGE']))
                mean_dict = dict(zip(self.output_df['REGION_A'], self.output_df[f'{kpi}__MEAN']))
                output[i][f'{kpi}_IQR'] = output[i]['Regions'].map(iqr_dict)
                output[i][f'{kpi}_MAX'] = output[i]['Regions'].map(max_dict)
                output[i][f'{kpi}_MIN'] = output[i]['Regions'].map(min_dict)
                output[i][f'{kpi}_RANGE'] = output[i]['Regions'].map(range_dict)
                output[i][f'{kpi}_MEAN'] = output[i]['Regions'].map(mean_dict)
        return output

    def similar_cities(self) -> dict:
        """
        Identify similar regions in data and output similar cities sheets based on number of regions present in data.

        Returns:
            dict: dictionary containing similar regions output for each key from network analysis and pairwise comparison
        """
        self.logger.info(f"Performing network comparison.")
        output = self.get_cliques(self.output_df, self.IDX)
        return output

    
    def stats_function(self) -> pd.DataFrame:
        """
        Present general info about the analysis

        Returns:
            pd.DataFrame: dataframe containing overall statistics for the data and model
        """
        self.logger.info('Computing general statistics on data.')
        stats = pd.DataFrame.from_dict(dict({'Number_of_regions': self.input_df[MROIColumns.region].nunique(),
                                             'Min_Date': pd.to_datetime(self.input_df[MROIColumns.date], format='%Y-%m-%d').min(),
                                             'Max_Date': pd.to_datetime(self.input_df[MROIColumns.date], format='%Y-%m-%d').max(),
                                             'Conditions_KPI': self.KPI,
                                             'Conditions_Checks': 'Correlation DTW and Correlation Change'}))
        return stats
    
    def calc_cluster(self, combined_df: pd.DataFrame) -> dict:
        """
        Assign Regions to a cluster based on given KPI(s)
        
        Args:
                combined_df (pd.DataFrame): similar cities df for each community
        
        Returns:
            dict: dictionary containing region, cluster mapping for each community
        """
        proc_df = combined_df[['Regions'] + self.KPI_stat].drop_duplicates()
        total_kpis = len(self.KPI_stat)
        for kpi in self.KPI_stat:
            if proc_df[kpi].std() == 0:
                proc_df[f'{kpi}_norm'] = 0
            elif self.sales_kpi[0] in kpi:
                proc_df[f'{kpi}_norm'] = ((proc_df[kpi]-proc_df[kpi].mean())/proc_df[kpi].std())*0.75
            else:
                proc_df[f'{kpi}_norm'] = ((proc_df[kpi]-proc_df[kpi].mean())/proc_df[kpi].std())*0.25/(total_kpis-1)
        
        KPI_norm = [f'{kpi}_norm' for kpi in self.KPI_stat]
        
        kmeans_final = KMeans(n_clusters=3)
        proc_df['CLUSTER'] = kmeans_final.fit_predict(proc_df[KPI_norm])
        
        sorted_cluster_mapping = dict(zip(np.argsort(proc_df.groupby('CLUSTER').mean().mean(axis=1).tolist()), [0, 1, 2]))
        proc_df['CLUSTER'] = proc_df['CLUSTER'].map(sorted_cluster_mapping)
        proc_df = proc_df[['Regions', 'CLUSTER']].set_index('Regions')
        cluster_dict = proc_df.to_dict()['CLUSTER']
        return cluster_dict
    
    def generate_test_control_suggestions(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Generates test/control column that contains suggested flag to use for a particular region
        
        Args:
            df (pd.DataFrame): clustered similar cities community 
        
        Returns:
            pd.DataFrame: df containing similar cities community with test/control suggestions
        """
        total_kpis = len(self.KPI_stat)
        # Scale to ensure sum of values are consistent across KPIs
        for kpi in self.KPI_stat:
            if self.sales_kpi[0] in kpi:
                df[f'{kpi}_scaled'] = ((df[kpi]-df[kpi].min())/(df[kpi].max() - df[kpi].min()))*0.75
            else:
                df[f'{kpi}_scaled'] = ((df[kpi]-df[kpi].min())/(df[kpi].max() - df[kpi].min()))*0.25/(total_kpis-1)
        
        KPI_scaled = [f'{kpi}_scaled' for kpi in self.KPI_stat]
        df['all_KPI_scaled'] = df[KPI_scaled].sum(axis=1)
        df = df.sort_values(by=['CLUSTER', 'all_KPI_scaled'], ascending=False).reset_index(drop=True)
        df['test/control'] = 'undefined'
        df_new = df.copy()
        # Identify outliers
        q1 = df_new.all_KPI_scaled.quantile(0.25)
        q2 = df_new.all_KPI_scaled.quantile(0.75)
        iqr = q2 - q1
        u_lim = q2 + 1.5*iqr
        l_lim = q1 - 1.5*iqr
        df_new.loc[(df_new['all_KPI_scaled']>u_lim) | (df_new['all_KPI_scaled']<l_lim), 'test/control'] = 'outlier'
        
        # Assign test/control alternatively
        prev = 'control'
        for idx in range(df_new.shape[0]):
            if df_new.loc[idx, 'test/control']=='outlier':
                pass
            else:
                if prev == 'control':
                    df_new.loc[idx, 'test/control'] = 'test'
                    prev = 'test'
                else:
                    df_new.loc[idx, 'test/control'] = 'control'
                    prev = 'control'
        """df_new.loc[0, 'test/control'] = 'test'
        df_new.loc[1, 'test/control'] = 'control'
        for idx in range(df.shape[0]):
            if idx <=1:
                continue
            if df_new.groupby('test/control')['all_KPI_scaled'].sum()['test'] > df_new.groupby('test/control')['all_KPI_scaled'].sum()['control']:
                df_new.loc[idx, 'test/control'] = 'control'
            else:
                df_new.loc[idx, 'test/control'] = 'test'
                
        
        df_with_test_control = pd.DataFrame()
        df_extra = pd.DataFrame()
        cluster_list = list(df['CLUSTER'].unique())
        cluster_list.sort(reverse=True)
        total_kpis = len(KPI_stat)
        for kpi in KPI_stat:
            if sales_kpi[0] in kpi:
                df[f'{kpi}_scaled'] = ((df[kpi]-df[kpi].min())/(df[kpi].max() - df[kpi].min()))*0.75
            else:
                df[f'{kpi}_scaled'] = ((df[kpi]-df[kpi].min())/(df[kpi].max() - df[kpi].min()))*0.25/(total_kpis-1)
        KPI_scaled = [f'{kpi}_scaled' for kpi in KPI_stat]
        df['all_KPI_scaled'] = df[KPI_scaled].sum(axis=1)
        df = df.sort_values(by=['CLUSTER', 'all_KPI_scaled'], ascending=False).reset_index(drop=True)
        for cluster in cluster_list:
            df_cluster = df[df['CLUSTER'] == cluster][['Regions', 'CLUSTER']]
            df_cluster = df_cluster.append(df_extra)
            df_cluster = df_cluster.reset_index()
            df_cluster['test/control'] = 'undefined'
            column_loc = df_cluster.columns.get_loc('test/control')
            if len(df_cluster) % 2 == 0:
                df_cluster.iloc[::2, column_loc] = 'test'
                df_cluster.iloc[1::2, column_loc] = 'control'
                df_extra = pd.DataFrame()
            else:
                df_cluster.iloc[::2, column_loc] = 'test'
                df_cluster.iloc[1::2, column_loc] = 'control'
                df_cluster.iloc[-1, column_loc] = 'undefined'
                df_extra = df_cluster[df_cluster['test/control']=='undefined']
                df_cluster = df_cluster[df_cluster['test/control']!='undefined']
                df_extra = df_extra.drop(['index'], axis=1)
            df_cluster = df_cluster.drop(['index'], axis=1)
            df_with_test_control = df_with_test_control.append(df_cluster)
        df_new = df.merge(df_with_test_control, on=['Regions', 'CLUSTER'], how='left')
        new_column_loc = df_new.columns.get_loc('test/control')
        if not df_extra.empty:
            control_mean = df_new[df_new['test/control']=='control']['all_KPI_scaled'].mean()
            test_mean = df_new[df_new['test/control']=='test']['all_KPI_scaled'].mean()
            if control_mean > test_mean:
                df_new.iloc[~df_new['test/control'].isin(['test', 'control']), new_column_loc] = 'test'
            else:
                df_new.iloc[~df_new['test/control'].isin(['test', 'control']), new_column_loc] = 'control'
        """
                
        df_new = df_new.drop(columns=KPI_scaled + ['all_KPI_scaled'])
        #reorder columns
        cols_ordered = ['Regions', 'CLUSTER', 'CLUSTER_LABEL', 'test/control'] + [col for col in df_new.columns if col not in ['Regions', 'CLUSTER', 'CLUSTER_LABEL', 'test/control']]
        df_new = df_new[cols_ordered]
        return df_new 

    def upload_blob(self, url: str, buffer: bytes, content_type='text/plain'):
        """
        Write files to results location in GCS.

        Args:
            url (str): path to file on GCS
            buffer (bytes): data to upload/ filename of file to be uploaded
            content_type (str, optional): Type of file. Defaults to 'text/plain'.
        """
        url = GCSUrl(url)
        storage_client = storage.Client()
        bucket = storage_client.bucket(url.bucket)
        blob = bucket.blob(url.path)
        if content_type=='application/zip':
            blob.upload_from_filename(buffer, content_type=content_type)
        else:
            blob.upload_from_string(buffer, content_type=content_type)
        self.logger.info(f'Uploaded file successfully to {url}')
        
    def write_output(self, stats_df: pd.DataFrame, similar_cities_dfs: dict, corr_dfs: dict):
        """
        Construct a united excel view and upload to gcs.

        Args:
            stats_df (pd.DataFrame): returned output from stats_function
            similar_cities_dfs (dict): returned output from similar_cities function
            corr_dfs (dict): dictionary containing all correlation dfs
        """
        url = GCSUrl(self.model_output_file_path)
        self.logger.info(f'Creating output buffer to upload to {url}')
        blob = self.output_bucket.blob(url.path)
        #drop unnecessary cols
        cols_to_drop = [col for col in self.output_df.columns 
                    if ('DickeyFuller' in col) | ('KullbackLeibler' in col) | ('KullbackLeibler' in col) | 
                       ('ANOVA' in col) | ('Levene' in col) | ('All_KPIs__Kolmogorov-Smirnov_Check' in col) |
                       ('All_KPIs__all_conditions_Check' in col) | ('agg_sales_kpi_REGION_A' in col) | 
                       ('agg_sales_kpi_REGION_B' in col) | ('mean_agg_sales_kpi' in col) | 
                       (('Correlation' in col) & (self.sales_kpi[0] not in col))]
        self.output_df = self.output_df.drop(columns=cols_to_drop)
        # Use the BytesIO object as the filehandle.
        with io.BytesIO() as output:
            writer = pd.ExcelWriter(output, engine='xlsxwriter')
            # Write the data frame to the BytesIO object.
            stats_df.to_excel(writer, sheet_name='GeneralInfo')
            for df_name, df in similar_cities_dfs.items():
                df.to_excel(writer, sheet_name=f'Community_{df_name}', index=False)
            writer.save()
            output.seek(0)
            blob.upload_from_file(output, content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        self.logger.info(f'Successfully saved output to file {url}')
        
    def identify_communities(self) -> dict:
        """
        Orchestrator function to identify communities
        
        Returns:
            dict: a dictionary of dataframes containing the 5 largest communities
        """
        self.agg_sales_kpi_dict = self.calc_agg_sales_kpi()
        self.output_df['agg_sales_kpi_REGION_A'] = self.output_df['REGION_A'].map(self.agg_sales_kpi_dict)
        self.output_df['agg_sales_kpi_REGION_B'] = self.output_df['REGION_B'].map(self.agg_sales_kpi_dict)
        self.output_df['mean_agg_sales_kpi'] = (self.output_df['agg_sales_kpi_REGION_A'] + self.output_df['agg_sales_kpi_REGION_B'])/2
        base_similar_dfs = self.similar_cities()
        n_communities = len(base_similar_dfs)
        self.logger.info("Obtained communities using leiden algorithm.")
        return base_similar_dfs
        
    def format_output(self, community_dfs_dict: dict) -> dict:
        """
        Identifies high, medium, low clusters for each community. Plots correlation plots and generates output in the required format.
        
        Args:
            community_dfs_dict (dict): a dictionary of dataframes containing the 5 largest communities
        
        Returns:
            dict: a dictionary of dataframes containing the 5 largest communities with all information required in output
        """
        output_powerbi = self.input_df.replace(0, np.nan)
        clustered_similar_cities_dfs = {}
        corr_dfs = {}
        corr_dtw_dfs = {}
        for community_id, df in community_dfs_dict.items():  
            self.logger.info(f'Calculating low, medium, high clusters for community: {community_id}')
            df = df.fillna(0)
            if df.shape[0]>=3:  
                df['CLUSTER'] = df['Regions'].map(self.calc_cluster(df))
                df['CLUSTER_LABEL'] = df['CLUSTER'].map({0:'low', 1:'medium', 2:'high'})
            else:
                df['CLUSTER'] = ''
                df['CLUSTER_LABEL'] = ''
            output_powerbi.loc[output_powerbi['region'].isin(df['Regions'].tolist()), 'Community'] = f'Community_{community_id}'
            self.logger.info(f'Obtained low, medium, high clusters for community: {community_id}')
            df = self.generate_test_control_suggestions(df)
            self.logger.info(f'Obtained recommended test and control regions for community: {community_id}')
            clustered_similar_cities_dfs[community_id] = df
            comm_corr_df = self.corr_df[self.corr_df['REGION_A'].isin(df.Regions.to_list()) & self.corr_df['REGION_B'].isin(df.Regions.to_list())]
            comm_corr_df = comm_corr_df.reset_index(drop=True)
            comm_corr_df = comm_corr_df.pivot(index='REGION_A', columns='REGION_B', values=f'{self.sales_kpi[0]}__Correlation').fillna(0)
            
            comm_corr_dtw_df = self.corr_dtw_df[self.corr_dtw_df['REGION_A'].isin(df.Regions.to_list()) & self.corr_dtw_df['REGION_B'].isin(df.Regions.to_list())]
            comm_corr_dtw_df = comm_corr_dtw_df.reset_index(drop=True)
            comm_corr_dtw_df = comm_corr_dtw_df.pivot(index='REGION_A', columns='REGION_B', values=f'{self.sales_kpi[0]}__Correlation_dtw').fillna(0)

            corr_dfs[community_id] = comm_corr_df
            n_regions = comm_corr_df.shape[0]
            fig, ax = plt.subplots(1, 1, figsize=(min(768, n_regions), min(768, n_regions)))
            fig.set_facecolor('#ffffff')
            sns.heatmap(comm_corr_df, 
                        xticklabels=comm_corr_df.columns.values,
                        yticklabels=comm_corr_df.columns.values, cmap="mako", square=True, ax=ax)
            ax.set_title(f"Correlation heat map - Community {community_id}")
            buf = io.BytesIO()
            fig.savefig(buf, format='png', bbox_inches='tight')
            buf.seek(0)
            image_in_buffer = buf.read()
            buf.close()
            self.upload_blob(gcs_join(self.model_output_path, f'community_{community_id}/correlation_plots_community_{community_id}.png'), image_in_buffer, 'image/png')
            comm_corr_df.to_csv(gcs_join(self.model_output_path, f'community_{community_id}/correlation_table_community_{community_id}.csv'))

            corr_dtw_dfs[community_id] = comm_corr_dtw_df
            n_regions = comm_corr_dtw_df.shape[0]
            fig, ax = plt.subplots(1, 1, figsize=(min(768, n_regions), min(768, n_regions)))
            fig.set_facecolor('#ffffff')
            sns.heatmap(comm_corr_dtw_df, 
                        xticklabels=comm_corr_dtw_df.columns.values,
                        yticklabels=comm_corr_dtw_df.columns.values, cmap="mako", square=True, ax=ax)
            ax.set_title(f"Correlation_dtw heat map - Community {community_id}")
            buf = io.BytesIO()
            fig.savefig(buf, format='png', bbox_inches='tight')
            buf.seek(0)
            image_in_buffer = buf.read()
            buf.close()
            self.upload_blob(gcs_join(self.model_output_path, f'community_{community_id}/correlation_dtw_plots_community_{community_id}.png'), image_in_buffer, 'image/png')
            comm_corr_dtw_df.to_csv(gcs_join(self.model_output_path, f'community_{community_id}/correlation_dtw_table_community_{community_id}.csv'))
            
            self.logger.info(f'Generated correlation table for community: {community_id}')
        self.write_output(
            #self.pivot_function(), 
            self.stats_function(),
            clustered_similar_cities_dfs, corr_dfs)
        output_powerbi = output_powerbi.fillna(value={'Community': 'Unassigned'})
        return clustered_similar_cities_dfs, output_powerbi