"""Executes regression model on H2O to be used for budget calculations"""
import sys
import os
import re
import io
import json
import time
import traceback
import requests
from ntpath import basename
from typing import Tuple

import pandas as pd
import numpy as np
import datetime as dt
from zipfile import ZipFile

import driverlessai

from google.cloud import storage

from rbt_dependencies.exceptions import (
    ColumnHeadersError, IncompatiblePythonVersionError, AuthenticationError, 
    DownloadError, DateFormatError, TooManyDateNullError
)

from mroi.utils import gcs_join, GCSUrl, PuddleDAIVM, retry
from mroi.config import (PUDDLE_SERVER_ADDRESS, PUDDLE_VM_NAME_RBT, PUDDLE_API_KEY_SECRET, 
    PUDDLE_API_SECRET_KEY_SECRET)
from mroi.notification import default_notification_handler
from mroi.logging import getLogger

class Regression:
    """
        Executes regression model on H2O to be used for budget calculations

        Args:
            project_id (str): current project id on GCP
            input_file_path (str): full path to input file on gcs
            model_intermediate_path (str): intermediate folder path on gcs
        """
    def __init__(self, project_id: str, input_file_path: str, model_intermediate_path: str):
        self.logger = getLogger(self.__class__.__name__)
        
        self.PROJECT_ID = project_id
        self.input_file_url = GCSUrl(input_file_path)
        self.model_intermediate_url = GCSUrl(model_intermediate_path)
        
        self.puddle_vm = PuddleDAIVM(self.PROJECT_ID, PUDDLE_SERVER_ADDRESS, PUDDLE_VM_NAME_RBT, PUDDLE_API_KEY_SECRET, PUDDLE_API_SECRET_KEY_SECRET)
        self.dataframe = pd.read_csv(input_file_path)
        self.storage_client = storage.Client()

    def check_py_version(self):
        """
        Check python version to ensure compatibility with h2o ai. Checks if python version is 3.6 or above.

        Raises:
            IncompatiblePythonVersionError: Raised when python version is <3.6
        """
        if not sys.version_info.major == 3 and sys.version_info.minor >= 6:
            self.logger.error("Python 3.6 or higher is required.")
            self.logger.error("You are using Python {}.{}.".format(sys.version_info.major, sys.version_info.minor))
            raise IncompatiblePythonVersionError('The current Python version is not compatible with H2O AI module.')

    def check_columns_headers(self):
        """
        Test if required column headers exist.

        Raises:
            ColumnHeadersError: Raised when column headers don't match expected column headers: Week_id, ctrl_sales/store, delta_lag, test_sales/store, test_stores
        """
        # List of sorted columns
        sorted_columns = sorted(list(self.dataframe.columns))
        self.logger.info('Checking if columns in data match the requirements.')
        # Check if columns are 'Week_id', 'ctrl_sales/store', 'delta_lag', 'test_sales/store', 'test_stores'.
        if sorted_columns != ['Week_id', 'ctrl_sales/store', 'delta_lag', 'test_sales/store', 'test_stores']:
            self.logger.error(
                f'''Invalid column headers in input file(s). 
                Require the following columns: Week_id, ctrl_sales/store, delta_lag, test_sales/store, test_stores.
                The input file has {sorted_columns}''')
            raise ColumnHeadersError('Invalid column headers in input file. Possibly due to Data corruption/change in Schema.')
        self.logger.info('Column check passed.')
        
    def check_date_format(self):
        """
        Test if date format is 'yyyy-mm-dd'.

        Raises:
            DateFormatError: Raised when date format is in yyyy-mm-dd format
        """
        try:
            self.logger.info('Checking date format.')
            # Try setting Week_id format to '%Y-%m-%d' which is expected
            self.dataframe['Week_id'] = pd.to_datetime(self.dataframe['Week_id'], format='%Y-%m-%d', errors='raise')
        except Exception:
            raise DateFormatError('Week_id has incorrect date format. Expected format is yyyy-mm-dd.')
        self.logger.info('Date format check passed.')

    def drop_duplicates(self, change_counter: int) -> int:
        """
        Drop duplicate rows in df

        Args:
            change_counter (int): Count of changes until this validation step

        Returns:
            int: total count of changes after this validation step
        """
        # Calculate total number of duplicates
        duplicates_count = self.dataframe.duplicated().sum()
        if duplicates_count > 0:
            self.logger.warn(f'Found {duplicates_count} duplicates in input data.')
            # Drop duplicates
            self.dataframe = self.dataframe.drop_duplicates()
            self.logger.info(f'Dropped {duplicates_count} duplicates.')
            change_counter += 1
        self.logger.info('No duplicates found.')
        return change_counter

    def handle_na(self, change_counter: int) -> int:
        """
        Test for null values and backfill. Log warning for null values and na

        Args:
            change_counter (int): Count of changes until this validation step

        Raises:
            TooManyDateNullError: Raised when more than half of the rows in input file are null in date column

        Returns:
            int: total count of changes after this validation step
        """
        # Add datetime format to Week_id using the output format from DE
        self.dataframe.replace([np.inf, -np.inf], np.nan)
        total_rows = self.dataframe.shape[0]
        # For each column in dataframe
        for column in self.dataframe.columns:
            nans_in_column = self.dataframe[column].isnull().sum()
            # Check if number of nans > 0
            if nans_in_column > 0 and column != 'Week_id':
                self.logger.warn(f'Found {nans_in_column} null values in column: {column}.')
                # Backfill nulls first
                self.dataframe[column].fillna(method='bfill', inplace=True)
                # Forwardfill nulls to fill the nulls at the end if any
                self.dataframe[column].fillna(method='ffill', inplace=True)
                self.logger.warn(f'Filled {nans_in_column} null values in column: {column}.')
                change_counter += 1
            elif column == 'Week_id':
                date_null = nans_in_column
                # Check if 50% of date values are nulls
                if nans_in_column / total_rows > 0.5:
                    # Raise exception
                    raise TooManyDateNullError(
                        f'Too many null values in date column. Found {nans_in_column} nulls out of {total_rows} rows. Possibly due to poor data quality. Please check input data sources.')
        if date_null > 0:
            # Drop all data null rows
            self.dataframe.dropna(inplace=True)
            self.logger.warn(f'Found {date_null} null values in column: Week_id.')
            self.logger.warn(f'Dropped {date_null} rows corresponding to null values in column: Week_id.')
            change_counter += 1
        return change_counter

    def check_data_consistency(self):
        """
        Test if dtypes are as expected and check if delta_lag is consistent
        """
        for column in self.dataframe.columns:
            if column != 'Week_id':
                # Check if all columns except Week_id are int or float
                if self.dataframe[column].dtype not in ['int', 'float']:
                    # Try to set to float if not
                    self.dataframe[column].astype('float')
                    self.logger.error('Data type consistency check passed.')
    
    @retry(Exception)
    def run_experiment(self, puddle_vm: PuddleDAIVM, source_path: str): 
    #-> Tuple[Model, str]:
        """
        Connect to DAI system and run experiment. Saves experiment summary on a local directory.

        Args:
            puddle_vm (PuddleDAIVM): PuddleDAIVM class object used to start vm and get system details
            source_path (str): Local path to input files

        Returns:
            Tuple[Model, str]: Model experiment object, experiment url
        """
        system = puddle_vm.start_dai_vm()
        # Connect to DAI system.
        h2oai = driverlessai.Client(address=system.default_url, username=system.username, password=system.password, verify=False)

        #h2oai = Client(address=system.default_url, username=system.username, password=system.password)
        self.logger.info('Creating a h2oai client.')
        # Upload data to the system.
        data_dai = h2oai.datasets.create(data=source_path, data_source='gcs', name='Data_DAI_'+time.strftime("%Y%m%d-%H%M%S"))

        #data_dai = h2oai.create_dataset_from_gcs_sync(source_path)
        self.logger.info(f'Uploaded data to h2o dai from {source_path}.')
        # Run experiment.
        self.logger.info(f'Running experiment.')
        experiment = h2oai.experiments.create_async(train_dataset=data_dai,
                                                    target_column='test_sales/store',
                                                    task='regression',
                                                    accuracy=7,
                                                    time=1,
                                                    interpretability=8,
                                                    scorer='R2',
                                                    reproducible=True,
                                                    drop_columns=[
                                                        'Week_id',
                                                        'test_stores'
                                                    ],
                                                    config_overrides='''min_num_rows = 20 \n
                                                                    included_models = ["GLM"] \n
                                                                    fixed_ensemble_level=0 \n
                                                                    target_transformer='identity_noclip'\n
                                                                    included_transformers = ["OriginalTransformer"] \n
                                                                    make_mojo_scoring_pipeline = "off" \n
                                                                    make_python_scoring_pipeline = "off" \n
                                                                    seed = 1729 \n
                                                                    fixed_num_folds_evolution = 3 \n
                                                                    drop_id_columns = false \n
                                                                    ''',
                                                    name = 'RBT_'+dt.datetime.now().strftime("%Y%m%d-%H%M%S")
        ).result(silent=True)       
        self.logger.info(f'Successfully executed experiment with ID: {experiment.key}.')
        experiment_ui = f'{system.default_url}/#experiment?key={experiment.key}'
        self.logger.info(f'Experiment UI link: {experiment_ui}.')
        return experiment, experiment_ui

    @retry(Exception)    
    def download_experiment_results(self, puddle_vm: PuddleDAIVM, experiment_key: str) -> requests.Response:
        """
        Downloads experiment summary zip into a response object and returns it.

        Args:
            puddle_vm (PuddleDAIVM): PuddleDAIVM object used to start vm and get system details
            experiment_key (str): experiment key of the experiment

        Returns:
            requests.Response: Response object containing experiment results
        """
        system = puddle_vm.start_dai_vm()
        h2oai = driverlessai.Client(address=system.default_url, username=system.username, password=system.password, verify=False)
        model = h2oai.experiments.get(experiment_key)
        response = h2oai._get_file(model._get_raw_info().entity.summary_path)
        return response
    
    def read_response(self, response: requests.Response, experiment_key: str) -> Tuple[dict, dict, str, str]:
        """
        Reads response and saves files to GCS. 
        Reads ensemble_glm_coefs_scalers.json and ensemble_model_params.json into coefs_scalers and params and returns them to be used in Budget.

        Args:
            response (requests.Response): Response object containing the experiment summary
            experiment_key (str): experiment key of experiment

        Returns:
            Tuple[dict, dict, str, str]: scalar coefs dict, params dict, coefs_scalars file path, params file path
        """
        summary_zip = ZipFile(io.BytesIO(response.content))
        results_location = gcs_join(self.model_intermediate_url.url, f'experiment_results_{experiment_key}')
        self.logger.info(f'Uploading output to {results_location}')
        for file_name in summary_zip.namelist():
            self.logger.info(f'Attempting to write {file_name}')
            self._write_to_landing(gcs_join(results_location, file_name), summary_zip.read(file_name))
            self.logger.info(f'Write successful for {file_name}')
            if file_name == 'ensemble_glm_coefs_scalers.json':
                coefs_scalers = json.loads(summary_zip.read(file_name))
                coefs_scalers_path = gcs_join(results_location, file_name)
            if file_name == 'ensemble_model_params.json':
                params = json.loads(summary_zip.read(file_name))
                params_path = gcs_join(results_location, file_name)
        self.logger.info('Return coefs_scalers and params objects')
        return coefs_scalers, params, coefs_scalers_path, params_path
    
    def _write_to_landing(self, url: str, file_bytes: bytes, content_type='text/plain'):
        """
        Write files to results location in GCS.

        Args:
            url (str): path to file on GCS
            file_bytes (bytes): data to upload
            content_type (str, optional): Type of file. Defaults to 'text/plain'.
        """
        url = GCSUrl(url)
        bucket = self.storage_client.bucket(url.bucket)
        blob = bucket.blob(url.path)
        blob.upload_from_string(file_bytes, content_type=content_type)


    def main(self) -> Tuple[str, str, pd.DataFrame, dict, dict]:
        """
        Orchestrator method for regression module to run regression model

        Returns:
            Tuple[str, str, pd.DataFrame, dict, dict]: Experiment results folder, experiment url, input file as dataframe, scalar coefs dict, params dict
        """
        self.check_py_version()
        self.check_columns_headers()
        self.check_date_format()
        changes_count = 0
        changes_count = self.drop_duplicates(changes_count)
        changes_count = self.handle_na(changes_count)
        self.check_data_consistency()
        if changes_count > 0:
            validated_input_file_location = self.input_file_url.url.replace(basename(self.input_file_url.url), f'validated_{basename(self.input_file_url.url)}')
            self.dataframe.to_csv(validated_input_file_location, index=False)
            self.run_config = {"INPUT_DATA_PATH": validated_input_file_location}
            experiment, experiment_ui = self.run_experiment(self.puddle_vm, validated_input_file_location)
        else:
            self.run_config = {"INPUT_DATA_PATH": self.input_file_url.url}
            experiment, experiment_ui = self.run_experiment(self.puddle_vm, self.input_file_url.url)
        experiment_key = experiment.key
        with self.download_experiment_results(self.puddle_vm, experiment_key) as response:
            coefs_scalers, params, coefs_scalers_path, params_path = self.read_response(response, experiment_key)
        results_folder = gcs_join(self.model_intermediate_url.url, f'experiment_results_{experiment_key}')
        self.logger.info('Finished executing Regression module.')
        self.run_config.update({"EXPERIMENT_RESULTS_FOLDER": results_folder, "EXPERIMENT_UI": experiment_ui, "COEFS_FILE_PATH": coefs_scalers_path, "PARAMS_FILE_PATH": params_path})
        self._write_to_landing(gcs_join(self.model_intermediate_url.url, 'model_run_config.json'), json.dumps(self.run_config), content_type='application/json')
        return results_folder, experiment_ui, self.dataframe, coefs_scalers, params