"""Calculates budget and other metrics using regression model results"""
import re
import io
import traceback
from ntpath import basename
from typing import Tuple

import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.tsa.api as smt
import matplotlib.pyplot as plt
from scipy import stats
from pyspark.sql import SparkSession

import google.auth
from google.cloud import storage

from rbt_dependencies.threshold import Threshold
from mroi.utils import gcs_join, GCSUrl
from mroi.logging import getLogger

class Budget:
    """
        Calculates budget and other metrics using regression model results

        Args:
            project_id (str): current project id on GCP
            experiment_folder_path (str): path to experiment folder 
            experiment_ui (str): experiment url
            input_df (pd.DataFrame): input dataframe
            coefs_scalers (dict): coefs scalars dict from experiment results
            params (dict): params dict from experiment results
            config (dict): config json obtained from UI
            comb_conf (dict): combinations parameters provided by user
            model_output_path (str): output folder path on gcs
            test_group (int): test group/cell number starting from 0
        """
    def __init__(self, project_id: str, experiment_folder_path: str, experiment_ui: str, input_df: pd.DataFrame, coefs_scalers: dict, params: dict, config: dict, model_config: dict, model_output_path: str, test_group: int):
        self.logger = getLogger(self.__class__.__name__)
        
        self.PROJECT_ID = project_id
        self.experiment_folder_path = experiment_folder_path
        self.experiment_ui_link = experiment_ui
        self.input_dataframe = input_df
        self.coefs_scalers = coefs_scalers
        self.params = params
        self.config = config
        self.model_config = model_config
        self.combinations = model_config['combinations']
        self.model_output_path = model_output_path
        self.test_group = test_group
        self.plots_file_path = gcs_join(model_output_path, f'regression_plots_REGRESSION_BUDGET_{self.test_group}.png')
        self.output_file_path = gcs_join(model_output_path, f'output_REGRESSION_BUDGET_{self.test_group}.csv')

    def build_coefs(self, coefs_scalers: dict, params: dict) -> dict:
        """
        Create and return coefs dictionary which will be used to make predictions and plot graphs.

        Args:
            coefs_scalers (dict): coefs_scalers dictionary created from ensemble_glm_coefs_scalers.json
            params (dict): params dictionary created from ensemble_model_params.json

        Returns:
            dict: coefs dictionary containing intercept and other required columns for budget calculation
        """
        coefs = {}
        # Calculating coefficients from regression.
        for i in self.coefs_scalers['Features']:
            field = re.sub('^([^_]+_)', '', self.coefs_scalers['Features'][i])
            coefs[field] = self.coefs_scalers['Coefficients'][i]
        # coefs['intercept'] = self.params['base_score']['0']
        coefs['intercept'] = self.coefs_scalers['Biases']['0']
        for i in self.coefs_scalers['Features']:
            field = re.sub('^([^_]+_)', '', self.coefs_scalers['Features'][i])
            coefs['intercept'] = coefs['intercept'] - coefs_scalers['Means'][i]* coefs[field]/coefs_scalers['Scales'][i]
            # coefs['intercept'] = coefs['intercept'] - coefs_scalers['Means'][i]* coefs[field]/coefs_scalers['Scales'][i] + coefs_scalers['Biases'][i]
            coefs[field] = coefs[field] / self.coefs_scalers['Scales'][i]
        for col in ['ctrl_sales/store', 'delta_lag']:
            if col not in coefs.keys():
                coefs[col] = 0
        self.logger.info('Created coefs DF.')
        return coefs

    def create_dataframe(self, input_df: pd.DataFrame, coefs: dict) -> pd.DataFrame:
        """
        Read input data, create fields to be used for visualization and return data dataframe.
        
        Args:
            input_df (pd.DataFrame): Input dataframe
            coefs (dict): coefs dictionary containing intercept and other required columns for budget calculation

        Returns:
            pd.DataFrame: updated dataframe containing predictions and residuals
        """
        data = input_df
        #data.head()
        # Predictions and making checks
        data['pred'] = data['ctrl_sales/store'] * coefs['ctrl_sales/store'] + data['delta_lag'] * coefs['delta_lag'] + coefs['intercept']
        data['resid'] = data['test_sales/store'] - data['pred']
        # d,f used to plot regression line for scatterplot of residuals vs predicted values
        d = np.polyfit(data['pred'],data['resid'],1)
        f = np.poly1d(d)
        data['reg'] = f(data['pred'])
        data['total_resid'] = data['resid'] * data['test_stores']
        data['total_actual'] = data['test_sales/store'] * data['test_stores']
        data['Week_id'] = pd.to_datetime(data['Week_id'], format='%Y-%m-%d')
        data = data.sort_values('Week_id')
        self.logger.info('Created data DF with predictions and residuals.')
        return data

    def generate_plots(self, df: pd.DataFrame) -> io.BytesIO:
        """
        Generate the plots using the input dataframe.
        
        Args:
            df (pd.DataFrame): Dataframe imported and modified using model results

        Returns:
            io.BytesIO: Image stored in buffer
        """
        # Plot the analysis of regression
        fig, axes = plt.subplots(nrows=2, ncols=3, figsize=(20, 12))
        fig.set_facecolor('#ffffff')
        self.logger.info('Generating plots.')
        df.set_index('Week_id')[['test_sales/store', 'pred']].plot(ax=axes[0, 0])
        axes[0, 0].set_title('Actual vs. Predicted Sales')
        df['resid'].plot.bar(ax=axes[0, 1])
        axes[0, 1].set_title('Residual Plot')
        df['resid'].plot(kind='kde', ax=axes[0, 2])
        axes[0, 2].set_title('Residual Distribution')
        df.plot.scatter('pred', 'resid', ax=axes[1, 0])
        df.plot('pred', 'reg', color='red', legend=False, ax = axes[1, 0])
        axes[1, 0].set_title('Residual vs. Fitted')
        sm.qqplot(df['resid'], stats.t, fit=True, line="45", ax=axes[1, 1])
        axes[1, 1].set_title('Residual QQ-plot')
        smt.graphics.plot_acf(df['resid'], lags=10, alpha=0.05, ax=axes[1, 2])
        axes[1, 2].set_title('Residual Autocorrelation Function')
        self.logger.info(f'Generated plots.')
        # Save image to bytestream to upload to GCS
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        buf.seek(0)
        image_in_buffer = buf.read()
        buf.close()
        self.logger.info(f'Stored plot in buffer for upload to GCS.')
        return image_in_buffer

    def create_output_combinations(self, combinations_conf: dict) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Read input combinations file from . Create a template of output file from input with all the required columns filled with nans.

        Args:
            combinations_conf (dict): config dictionary containing combinations info

        Returns:
            Tuple[pd.DataFrame, pd.DataFrame]: input combinations, output combinations with all required fields
        """
        # Initiate combinations
        try:
            input_combinations = pd.DataFrame.from_dict(combinations_conf)
        except ValueError:
            input_combinations = pd.DataFrame.from_dict([combinations_conf])
        input_combinations.columns = [x.upper() for x in input_combinations.columns]
        for column in input_combinations.columns:
            if column == 'WEEKS_PILOT':
                input_combinations[column] = input_combinations[column].astype(int)
            else:
                input_combinations[column] = input_combinations[column].astype(float)
        self.logger.info('Generating template for output.')
        output_combinations = input_combinations[['WEEKS_PILOT', 'MIN_CI', 'EXPECTED_ROAS', 'SALES_COVERAGE']].copy()
        fields = [
            'Training Start Date',
            'Training End Date',
            'Weeks in training',
            'R-Squared',
            'Degrees of Freedom',
            'Weekly sales noise (for 1 wk pilot)',
            'Weekly sales noise (adj. for pilot length)',
            'Average weekly test sales',
            'perc error per week (adj. for pilot length)',
            'Critical t-score',
            'Weekly sales lift required',
            'Minimum weekly spend',
            'Total lift required during pilot',
            'Total expected spend'
        ]
        for f in fields:
            output_combinations[f] = np.nan
        self.logger.info('Created template for output.')
        return input_combinations, output_combinations

    def generate_output(self, input_combinations: pd.DataFrame, output_combinations: pd.DataFrame, data: pd.DataFrame, params: dict) -> pd.DataFrame:
        """
        Generate output file with all the required metrics from Threshold module

        Args:
            input_combinations (pd.DataFrame): input_combinations dataframe created from input file
            output_combinations (pd.DataFrame): output_combinations dataframe template created using _create_output_combinations function
            data (pd.DataFrame): data dataframe created using create_dataframe function
            params (dict): params dictionary from ensemble_model_params.json

        Returns:
            pd.DataFrame: output dataframe containing all required metrics and columns
        """
        # Iterate over all combinations
        self.logger.info('Generating output.')
        for idx, row in input_combinations.iterrows():
            t = Threshold(
                row['WEEKS_PILOT'],
                row['MIN_CI'],
                row['EXPECTED_ROAS'],
                row['SALES_COVERAGE'],
                data,
                params)
            t.main()
            output_combinations.loc[idx, 'Training Start Date'] = t.TRAINING_START.date()
            output_combinations.loc[idx, 'Training End Date'] = t.TRAINING_END.date()
            output_combinations.loc[idx, 'Weeks in training'] = t.TRAINING_WEEKS
            output_combinations.loc[idx, 'R-Squared'] = t.RSQ
            output_combinations.loc[idx, 'Degrees of Freedom'] = t.DF
            output_combinations.loc[idx, 'Weekly sales noise (for 1 wk pilot)'] = t.NOISE
            output_combinations.loc[idx, 'Weekly sales noise (adj. for pilot length)'] = t.NOISE_WEEKLY
            output_combinations.loc[idx, 'Average weekly test sales'] = t.ACTUAL_SALES
            output_combinations.loc[idx, 'perc error per week (adj. for pilot length)'] = t.PERC_ERROR
            output_combinations.loc[idx, 'Critical t-score'] = t.T_SCORE
            output_combinations.loc[idx, 'Weekly sales lift required'] = t.SALES_LIFT
            output_combinations.loc[idx, 'Minimum weekly spend'] = t.MIN_WEEKLY_SPEND
            output_combinations.loc[idx, 'Total lift required during pilot'] = t.TOTAL_SALES_LIFT
            output_combinations.loc[idx, 'Total expected spend'] = t.TOTAL_EXPECTED_SPEND
        output_combinations['Experiment UI Link'] = self.experiment_ui_link
        self.logger.info('Generated output.')
        return output_combinations

    def upload_blob(self, url: str, buffer: bytes, content_type='text/plain'):
        """
        Write files to results location in GCS.

        Args:
            url (str): path to file on GCS
            buffer (bytes): data to upload
            content_type (str, optional): Type of file. Defaults to 'text/plain'.
        """
        url = GCSUrl(url)
        storage_client = storage.Client()
        bucket = storage_client.bucket(url.bucket)
        blob = bucket.blob(url.path)
        blob.upload_from_string(buffer, content_type=content_type)
        self.logger.info(f'Uploaded file successfully to {url}')
        
    def upload_results_gbq(self, df: pd.DataFrame):
        """
        Upload results to GBQ

        Args:
            df (pd.DataFrame): output table results
        """
        table_id = f"AIDE_Results.Regression_Budget" 
        self.logger.info(f"Uploading results to {self.PROJECT_ID}.{table_id}")
        columns = [re.sub('[^A-Za-z0-9_]+', '_', x) for x in df.columns]
        df.columns = columns
        df['run_id'] = f"{self.config['metadata']['aide_id']}"
        df['country'] = self.config['config']['country']
        df['country_code'] = self.config['config']['country_code']
        df['brand'] = self.config['config']['brand']
        df['sub_brand'] = ", ".join(self.config['config']['sub_brand'])
        df['segment'] = ", ".join(self.config['config']['segment'])
        df['sub_segment'] = ", ".join(self.config['config']['sub_segment'])
        df['granularity'] = self.model_config['region_granularity']['type']
        df['test_group'] = f"test_{self.test_group}"
        df['test_regions'] = ", ".join(self.model_config['region_granularity']['test_control_regions']['test'][str(self.test_group)]['regions'])
        df['control_regions'] = ", ".join(self.model_config['region_granularity']['test_control_regions']['control']['0']['regions'])
        df = df[['run_id', 'country', 'country_code', 'brand', 'sub_brand', 'segment', 'sub_segment', 'granularity', 'test_group', 'test_regions', 'control_regions'] + columns]
        df.to_gbq(table_id, project_id=self.PROJECT_ID, if_exists="append", credentials=google.auth.default()[0])
        self.logger.info("Loaded {} rows and {} columns to {}".format(df.shape[0], len(df.columns), table_id))

    def main(self):
        """
        Orchestrator method to execute all required functions in budget module
        """
        coefs = self.build_coefs(self.coefs_scalers, self.params)
        data = self.create_dataframe(self.input_dataframe, coefs)
        image_in_buffer = self.generate_plots(data)
        input_combinations, output_combinations = self.create_output_combinations(self.combinations)
        output_df = self.generate_output(input_combinations, output_combinations, data, self.params)
        output_df.to_csv(self.output_file_path, index=False)
        self.upload_blob(self.plots_file_path, image_in_buffer, 'image/png')
        self.upload_results_gbq(output_df)