class ColumnHeadersError(Exception):
    ...


class IncompatiblePythonVersionError(Exception):
    ...


class AuthenticationError(Exception):
    ...


class DownloadError(Exception):
    ...


class DateFormatError(Exception):
    ...


class TooManyDateNullError(Exception):
    ...
