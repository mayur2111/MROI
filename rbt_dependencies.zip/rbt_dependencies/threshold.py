"""Class used to calculate budget and other metrics"""
import numpy as np
import pandas as pd

from sklearn.metrics import r2_score
from scipy import stats

class Threshold:
    """
        Class used to calculate budget and other metrics

        Args:
            weeks (int): number of weeks pilot
            min_ci (float): minimum confidence interval
            exp_roas (float): expected return on advertising spend
            sales_cov (float): sales coverage
            data_df (pd.DataFrame): dataframe containing predictions
            model_params (dict): model params obtained from experiment results
        """
    # Calculate the threshold
    def __init__(self, weeks: int, min_ci: float, exp_roas: float, sales_cov: float, data_df: pd.DataFrame, model_params: dict):
        self.WEEKS_PILOT = weeks
        self.MIN_CI = min_ci
        self.EXPECTED_ROAS = exp_roas
        self.SALES_COVERAGE = sales_cov
        self.data = data_df.copy()
        self.TRAINING_START = self.data['Week_id'].min()
        self.TRAINING_END = self.data['Week_id'].max()
        self.TRAINING_WEEKS = (self.TRAINING_END - self.TRAINING_START).days / 7
        self.RSQ = r2_score(self.data['test_sales/store'], self.data['pred'])
        self.DF = model_params['train_shape']['0'][0] - 1

    def _calculate_stats(self):
        """
        Calculate required statistics
        """
        self.SSD = np.sum(self.data['total_resid'] ** 2)
        self.NOISE = np.sqrt(self.SSD / self.DF)
        self.NOISE_WEEKLY = self.NOISE / np.sqrt(self.WEEKS_PILOT)
        self.ACTUAL_SALES = np.mean(self.data['total_actual'])
        self.PERC_ERROR = self.NOISE_WEEKLY / self.ACTUAL_SALES

    def _calculate_budget(self):
        """
        Calculate budget metrics
        """
        self.T_SCORE = stats.t.ppf((1 + self.MIN_CI) / 2, self.DF)
        self.SALES_LIFT = self.T_SCORE * self.NOISE_WEEKLY / self.SALES_COVERAGE
        self.MIN_WEEKLY_SPEND = self.SALES_LIFT / self.EXPECTED_ROAS
        self.TOTAL_SALES_LIFT = self.SALES_LIFT * self.WEEKS_PILOT
        self.TOTAL_EXPECTED_SPEND = self.TOTAL_SALES_LIFT / self.EXPECTED_ROAS

    def main(self):
        """
        Orchestrator class to obtain statistics and budget metrics
        """
        self._calculate_stats()
        self._calculate_budget()
